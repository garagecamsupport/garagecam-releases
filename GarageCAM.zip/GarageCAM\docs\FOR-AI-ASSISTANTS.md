# For AI assistants: setting GarageCAM up for a machine

You are reading this because someone wants your help making GarageCAM write
programs for their machine. GarageCAM is a CAD/CAM program. Two kinds of
plain JSON files decide what it writes:

- A **post processor** (`.gcpost`) says how programs are written for one
  control: the G-codes, the tool change, the start and end. The full reference
  is in [POST-PROCESSORS.md](POST-PROCESSORS.md).
- A **machine definition** (`.gcmachine`) says what the machine can do:
  rates, travels, spindle range, tool changer and coolant. The reference is in
  [MACHINE-DEFINITIONS.md](MACHINE-DEFINITIONS.md).

Read both references before writing anything. This page adds the rules that
keep what you write safe to run. A wrong post can crash a machine. Treat every
line you write as something a spindle will act on.

## What to ask for first

Don't guess any of these. Ask the person:

1. **The control**: make, model and software version (for example "Haas NGC",
   "LinuxCNC 2.9", "Mach4 with an ESS", "grblHAL on a SuperLongBoard sent
   from gSender", "Centroid Acorn").
2. **A program that has already run right on this machine**, from any source
   (another CAM program, the machine maker's examples, a program they wrote by
   hand). This is the best evidence there is. Copy its start, tool change and
   end as closely as you can.
3. The **manual's pages** for anything you aren't sure the control takes:
   - how it changes tools;
   - how it sends Z home (G28, G53, or something else);
   - whether it reads `X1` as 1 or as 0.0001 (if the latter, it needs
     `alwaysDecimalPoint`);
   - arcs: I/J or R, and whether I/J are incremental;
   - canned drill cycles;
   - cutter compensation;
   - tool length offsets;
   - G93 inverse time;
   - comment style;
   - program numbers and `%`.
4. For a machine definition: the travels, the fastest rate of each axis, the
   spindle's speed range, how many tool changer pockets, which coolant, and
   whether it has a rotary axis.

## How to write the post

1. **Start from the closest built-in post.** Its settings are listed in
   POST-PROCESSORS.md:
   - grblHAL: grbl and grblHAL routers;
   - Grbl 1.1: no tool changer;
   - LinuxCNC;
   - Mach3 / Mach4;
   - Fanuc / Haas: most industrial machining centres.

   Set only what differs from it.
2. **Use settings before blocks.** If a setting does it (`arcsAsRadius`,
   `toolLengthOffset`, `semicolonComments`, ...), use the setting. Use a block
   only for what no setting can say: the control's own Z home, its own tool
   change sequence, extra lines around the spindle.
3. **Copy, don't invent.** Every G or M code you put in a block must come from
   the person's known-good program or their control's manual. If you can't
   point to where a code came from, leave GarageCAM's default for that block
   and say so.
4. **Words** in blocks are only the ones listed in POST-PROCESSORS.md, in
   capitals in braces: `{T}`, `{NEXT_T}`, `{S}`, `{HOME_Z}`, and so on. A word
   GarageCAM doesn't know is written into the program literally, so a typo
   shows up there.
5. **Write blocks as lists of lines**, one G-code line per string:

   ```json
   "toolChange": ["T{T} M6", "G43 H{H}"]
   ```

   An empty list `[]` writes nothing.

## Rules that keep it safe

- **Z clear before X and Y.** After a tool change, GarageCAM moves over the
  start point in X and Y, then down to clearance. Your `toolChange` block must
  leave Z at or above where it found it (home). Never move Z down in a block.
- **Length offset before going down.** On a control that keeps tool lengths in
  a table, `G43 H{H}` (or the control's equivalent) belongs in `toolChange`,
  after the change and before anything moves Z down. GarageCAM's own
  `toolChange` already does this when `toolLengthOffset` is on.
- **No motion in blocks except moves out of the way.** Only `homeZ`, `homeXY`,
  `toolChange` (moving to a change position) and `index` (turning the rotary)
  should hold moves, and only moves away from the work: Z up first, then X/Y.
- **Units come from `{UNITS}`.** Don't write G20 or G21 into a block yourself.
  The file's lengths (`parkX`, `homeX`, ...) are always millimetres.
- **Never set `provenOn`.** Leave it `""`. Only the person who ran a program
  from the post, and saw it come out right, fills it in.
- **Don't break grbl.** On grbl and grblHAL an `O` word is flow control, not a
  program number. Leave `programNumber` at 0 and `percentSigns` off for them.
- **Keep the setting names exact.** GarageCAM ignores keys it doesn't know,
  so a misspelt key silently loses the setting. Check every key against the
  table in POST-PROCESSORS.md.
- The file must be **valid JSON**, with `"garagecamPost": 1` and a `name`.

## Lathes, tilted planes and 5-axis

- **A lathe post** is written for turning programs. Start from Fanuc Lathe,
  LinuxCNC Lathe or grblHAL Lathe, and set the `lathe...` settings (diameter
  mode, feed a revolution, how G96 gets its top rpm, the thread code, T0101 or
  T1 M6). Rewrite `latheStart`, `latheHome`, `latheToolChange`,
  `latheToolStart`, `latheConstantSpeed` and `latheSpindleOn` only as the
  control's manual says.
  - Points go out as the tool's touch-off point: an insert's imaginary tip.
    Check the person touches their tools off the same way.
  - A boring insert (Rough or Finish cutting inside) points out from the
    centre, so its imaginary tip is a nose radius above the nose's centre,
    not below it. Grooving blades and threading tools go out as their own
    point, inside or out.
  - Check whether their lathe has its tools in front of the centreline or
    behind it, and whether G2 and G3 come out the right way round on it.
  - `latheThreadCycle` and `latheRoughCycle` hand threads (G76) and roughing
    (G71) to the control's own cycles. Only set them for a control whose
    manual has those cycles in the form docs/POST-PROCESSORS.md describes
    (the two-line Fanuc G76 and G71, or the one-line LinuxCNC/grblHAL G76);
    an older one-line Fanuc G76 or a control without them must keep every
    pass written out. `latheRoughCycle` 2 also writes G71 type II, which
    only some Fanuc controls have: ask before setting it.
- **`tiltedWorkPlane`** is only for a control that has a tilted work plane
  (Fanuc G68.2, Haas G268, Siemens CYCLE800, Heidenhain PLANE).
  - The `tiltOn` block gets the plane's origin and its Euler angles: Z, then
    the new X, then the new Z.
  - A control whose angles mean something else needs `tiltOn` written to
    match.
  - Never turn it on for a control that has no tilted work plane.
- **`fiveAxisTcp`** is only for a control with tool centre point control
  (G43.4, TCPM, RTCP), set up for the machine's real kinematics.
  - Without it, GarageCAM only posts 5-axis for machines whose rotaries are
    all on the table, turned about each axis where it runs: through the work
    zero, or where the axis's `centre` (mm from the work zero, every axis at
    0) puts it.
  - Ask how the person sets that zero, and measure the centres from it.

## What a post cannot change

GarageCAM writes these itself. Don't try to change them with blocks:

- the moves themselves (G0/G1/G2/G3 and their words);
- canned cycle lines;
- cutter compensation on and off;
- wrapped (rotary) moves and their feeds;
- the heading comments and the list of tools.

Settings change some of how they are written:

- arcs as R instead of I/J;
- canned cycles on or off;
- inverse time;
- decimals;
- comment style;
- modal words.

If the control needs something no setting or block can give, tell the person
to send it with **Help > Send a Suggestion**, so GarageCAM can grow to cover
it.

## A template

```json
{
    "garagecamPost": 1,
    "name": "My Machine",
    "description": "What it is for, and what it was made from.",
    "provenOn": "",
    "options": {
        "units": "inch",
        "toolLengthOffset": true,
        "cutterComp": true,
        "cannedDrillCycles": true,
        "blocks": {
            "homeZ": ["G53 G0 Z0"],
            "toolChange": ["T{T} M6", "G43 H{H}"]
        }
    }
}
```

## Handing it over

Tell the person to do the following, in order:

1. **Import it**: **Settings > Post Processors > Import...**, pick the file.
2. **Read the preview**: select it, then **Edit... > Program Blocks...**. The
   bottom half shows a whole program from a made-up job (two tools, the part
   turned to 90 degrees, holes, a contour). Read it line by line against their
   known-good program.
3. **Use it**: **Use for This Job**, or set it as the post in their machine
   definition.
4. **Post a simple job** (a facing pass, or one contour) and read the program
   in GarageCAM's NC Editor with **Show in Graphics** on.
5. **Prove it**:
   - Run the program in the air first, with the work offset raised well clear
     or using the control's dry run.
   - Then run it on the part with single block on, the feed and rapid
     overrides turned down, and a hand on feed hold.
6. **Report**: use **Help > Report How a Program Ran**, whether it ran right or
   not. A post that ran right is marked proven for them, and can become a
   built-in post for everyone with that control.

Give the person the file and these steps, and point out every line you weren't
sure of.

## A machine definition

Write a `.gcmachine` file from the person's answers, as shown in
MACHINE-DEFINITIONS.md:

- Rates in mm/min, the rotary in degrees/min. Travels in mm. Spindle speeds in
  rpm.
- Leave anything not known at 0. GarageCAM skips checks it has no number for,
  rather than checking against a guess.
- `post` is the name of the post processor exactly as it appears in
  GarageCAM's list.
- `rotaries` lists the rotary axes from the machine's base outwards: letter,
  the axis it turns about, `"table"` or `"head"`, limits, and `reversed`.
  - Ask which way a positive angle turns, and check it against the usual way
    in MACHINE-DEFINITIONS.md.
  - A wrong `reversed` turns the part the wrong way, so say plainly that the
    first turned program must be run in the air.
  - Wrapped (rotary) operations have their own "Way round" (A turns with or
    against Y). On a machine turning the usual way, "against Y" reads as
    drawn; tell the owner to check a wrapped line of text in the air too.
  - Omit `rotaries` (and set `rotary: false`) for a 3-axis machine.
- They read it in with **Settings > Machine Definitions > Import**.
