# Third-party licenses

Every dependency GarageCAM ships or links must be listed here with its license and
how it is linked. Only MIT, BSD, Apache, or LGPL-linked-dynamically are allowed.
No GPL.

| Dependency | Version | License | Linkage | Notes |
|---|---|---|---|---|
| Qt 6 | 6.x | LGPL-3.0 | Dynamic | Open-source Qt only. Must stay dynamically linked; ship the Qt DLLs unmodified and allow relinking. Do not use Qt modules under GPL-only terms (e.g. Qt Charts under open source). |
| Open CASCADE Technology (OCCT) | 8.0.x (built against 8.0.1) | LGPL-2.1 with OCCT exception | Dynamic | The OCCT exception permits linking without imposing LGPL on GarageCAM's own code. |
| vcpkg | tooling | MIT | Build tool only | Not shipped. |
| CMake | tooling | BSD-3-Clause | Build tool only | Not shipped. |
| Clipper2 | 2.0.x (built against 2.0.1) | Boost Software License 1.0 | Static | Polygon offsets for pocket, V carve and profile passes where the kernel's offset of a spline comes out wrong or gives up. The licence allows static linking with no notice in the binary; its text goes with the source. |

### Pulled in transitively by OCCT (shipped as DLLs)

| Dependency | License | Notes |
|---|---|---|
| FreeType | FTL **or** GPL-2.0-or-later | GarageCAM elects the FTL (BSD-style) option. The GPL option is never exercised. Ship the FTL text. |
| zlib | Zlib | Permissive. |
| libpng | libpng-2.0 | Permissive. |
| bzip2 | bzip2-1.0.6 | BSD-style. |
| Brotli | MIT | Permissive. |

## Planned, not yet added

| Dependency | License | Decision |
|---|---|---|
| OpenCAMLib | LGPL-2.1 | Allowed only if linked dynamically. Verify before adding. |

## Rules

- Record a dependency here in the same commit that adds it to `vcpkg.json`.
- LGPL components stay in separate shared libraries. The build fails if Qt is
  detected as a static library (see `CMakeLists.txt`).
- GarageCAM's own code, icons, and UI layouts are original. No assets from other CAM software.
