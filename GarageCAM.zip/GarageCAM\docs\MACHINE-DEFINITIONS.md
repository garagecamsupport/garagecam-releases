# GarageCAM machine definitions

A **machine definition** says what one machine is and what it can do:

- its travels and fastest feeds;
- its spindle's speed range;
- whether it has a rotary axis, a tool changer and coolant;
- which post its programs are written with.

GarageCAM uses it to check every program before writing it. If a feed is
faster than an axis can go, a cut runs past the travel, or a tool number has
no slot in the rack, you are told before the file exists.

The definitions are plain text files, and every value in them is yours to
change.

If you are an **AI assistant** setting up a machine for someone, read
[FOR-AI-ASSISTANTS.md](FOR-AI-ASSISTANTS.md) as well.

## Where they live

- **Settings > Machine Definitions**, or double-click **Machine** in the
  manager's Machine Group. **New**, **Delete**, **Import** and **Export** make,
  drop, read and write them.
- Each one is a `.gcmachine` file in `%APPDATA%\GarageCAM\GarageCAM\Machines`.
- A job keeps the name of the machine it is for. Opening the job makes that
  machine the current one.

## The file

```json
{
    "garagecamMachine": 1,
    "name": "Sienci AltMill",
    "description": "AltMill 4x4 with the tool changer and the Vortex rotary",
    "post": "grblHAL",
    "rotary": true,
    "automaticToolChanger": true,
    "toolSlots": 12,
    "flood": false,
    "mist": false,
    "simOffsetX": 0,
    "simOffsetY": 0,
    "simModel": "",
    "rotaries": [
        { "letter": "A", "about": "X", "on": "table", "min": 0, "max": 0, "reversed": false }
    ],
    "grblSettings": {
        "$110": 15000, "$111": 15000, "$112": 6000, "$113": 8000,
        "$130": 1260, "$131": 1248, "$132": 170,
        "$30": 24000, "$31": 7500
    }
}
```

| Key | What it is |
|---|---|
| `name` | The machine's name, as jobs refer to it |
| `description` | Anything worth knowing about it |
| `kind` | `"mill"` or `"lathe"`. A lathe turns, with X across and Z along the spindle; give it a lathe post |
| `post` | The name of the post processor its programs are written with (see [POST-PROCESSORS.md](POST-PROCESSORS.md)) |
| `rotary` | It has a rotary axis. Operations that turn or wrap round it are flagged on a machine without one. With no `rotaries` list it means an A axis along X turning the part |
| `rotaries` | Its rotary axes, base first (see [Rotary axes](#rotary-axes-31-and-32)) |
| `automaticToolChanger` | Tools are changed by the machine, not by hand |
| `toolSlots` | How many tools the changer holds (0: not checked) |
| `flood`, `mist` | It has that coolant. Asking for coolant it hasn't got is flagged |
| `simOffsetX`, `simOffsetY` | Where the work sits on the table in machine simulation, from the table's middle (mm) |
| `simModel` | The machine's own 3D model for simulation, read in with **Load Model**: the name of its `.gcsim` file beside the definitions |
| `grblSettings` | Rates, accelerations, travels and spindle range, under the grbl setting numbers |

The `grblSettings` numbers are the ones grbl and grblHAL use. On those
controls, type `$$` in the sender's console, copy what it lists, and use
**Read from $$**. For any other control, type the same values in by hand:

| Setting | Meaning | Unit |
|---|---|---|
| `$110`, `$111`, `$112` | X, Y, Z fastest rate | mm/min |
| `$113` | A (rotary) fastest rate | degrees/min |
| `$120`, `$121`, `$122` | X, Y, Z acceleration: with all three, run times are planned as the control plans them | mm/s² |
| `$123` | A (rotary) acceleration | degrees/s² |
| `$11` | Junction deviation: how far a corner may be rounded to keep speed (not set: 0.010) | mm |
| `$130`, `$131`, `$132` | X, Y, Z travel | mm |
| `$30`, `$31` | Spindle maximum and minimum speed | rpm |

A value left at **0** means "not known". Anything that depends on it isn't
checked, rather than checked against a guess.

## Machines other than grbl routers

A definition works for any milling machine, including an industrial
machining centre:

1. Pick the post for its control (Fanuc / Haas, LinuxCNC, Mach3 / Mach4, or
   one of your own).
2. Type in its rates, travels and spindle range.
3. Say whether it has a tool changer and how many pockets, and whether it has
   coolant.

For machine simulation, **Load Model** reads the machine's own CAD model (a
STEP file) and asks what moves each part:

- the table, which may move in X, Y or both;
- the column;
- the head;
- the rotary.

Gantry routers, moving-table mills and bed mills all simulate correctly.
On a trunnion table (A or B tilting, C turning on it) the simulation draws
the table under the work: uprights, a cradle on the tilt and a round table
on it, each about its centre as **Rotary axes** sets it. The work stays
still on screen and the machine turns round it; the cradle and round table
turn as the program does (3+2 at each operation's angles, 5-axis as the
tool leans), and the tool or head running into them is a collision.
A head that tilts the spindle (head B with a turning table C, or a head
turning C and tilting A or B) tilts in the simulation too: the spindle under
the pivot leans with the tool, a fork round the pivot turns with C, and the
linear axes carry the pivot where the leaning tool needs it. A head-table
machine's turning table (its C) is drawn as a round table under the work.
The pivot is the tilt axis's **pivot above the spindle nose** in Rotary axes
(120 mm when it is left at 0).

## Rotary axes: 3+1 and 3+2

**Rotary axes** in Machine Definitions sets how the machine turns the part,
or its head:

| Layout | Axes | Machines built so |
|---|---|---|
| 3 axes | none | Routers, bed mills, most machining centres |
| 4th axis along X (A) | A about X, table | The Sienci Vortex, most hobby 4th axes, a machining centre's 4th |
| 4th axis along Y (B) | B about Y, table | A rotary lying front to back |
| Trunnion table, A tilts and C turns | A about X, then C about Z, both table | Most table-table 5-axis machines |
| Trunnion table, B tilts and C turns | B about Y, then C about Z, both table | |
| Tilting head B, turning table C | C about Z (table), B about Y (head) | Many large head-table machines |
| Head turns C and tilts A or B | C about Z, then A or B (head) | Gantry 5-axis routers |

Each axis has its **limits** (both 0 for one that turns for ever) and can be
**Reversed** for a machine wired the other way. In the file, `rotaries` lists
them from the machine's base outwards:

```json
"rotaries": [
    { "letter": "A", "about": "X", "on": "table", "min": -120, "max": 120 },
    { "letter": "C", "about": "Z", "on": "table" }
]
```

| Key | Values | What it is |
|---|---|---|
| `letter` | `"A"`, `"B"`, `"C"` | What the control calls it |
| `about` | `"X"`, `"Y"`, `"Z"` | The machine axis it turns about |
| `on` | `"table"`, `"head"` | It turns the part, or moves the head |
| `min`, `max` | degrees | Its limits; both 0 for none |
| `reversed` | true/false | A positive angle turns it the other way to the usual |
| `centre` | `[x, y, z]` mm | Where a table axis runs with every axis at 0, from the work zero; left out for 0, 0, 0 |

**The usual way round.** A positive angle turns the tool right-handed about
the axis, measured against the part. A table turns the part the other way, so
"A90" tips the part's front face up to the spindle. If your machine turns the
other way, tick **Reversed**: indexed, 5-axis and wrapped paths are all told
the other way. To check, index a program to A90 and run it in the air: the
part's front face (the side towards you, -Y) should come up. Then a wrapped
operation set to **A turns against Y** reads as drawn (one left turning A with
Y, as GarageCAM always has, comes out as its mirror image).

### What GarageCAM does with them

An operation drawn on a turned **Tplane** is cut with the part turned to face
the spindle:

- **3+1**: on a 4th axis, any operation, 2D or 3D, on a plane square to the
  rotary axis. The AltMill's A axis along X works exactly as it always has.
- **3+2**: on a trunnion table, any plane the table can turn square to the
  spindle, a plane leaning two ways included. GarageCAM finds the angles. If
  there are two ways to get there, it takes the one that turns least, inside
  every axis's limits. A plane past the limits is refused, saying so.

The program turns every axis at once (`G0 A-54.7356 C-45`) after Z goes home.
It turns back to 0 before an operation on Top, and at the end. The setup sheet
says which axes turn and to what.

**Where the work zero goes.** The program's coordinates are measured from the
point where the rotary axes cross:

- on a 4th axis, the centreline;
- on a trunnion, where the tilt axis meets the turning table's axis.

Set the work offset there, and put the job's WCS at the same point on the part.

Or put the work zero where suits the part (on its top, say), and tell each
table axis where it runs from there, with every axis at 0: **its centre from
the work zero** in Machine Definitions, `centre` in the file. A trunnion
whose tilt axis is 50 mm below the part's top is `"centre": [0, 0, -50]` on
its A. The part is then turned about the axes where they really are. Only
programs that turn the part themselves (TCP off) need it. On a 4th axis,
wrapped and rotary toolpaths are always measured from the axis itself, so
leave its centre at 0. A head's tilt axis has its **pivot above the spindle
nose** instead (`centre` Z in the file), which only machine simulation uses.

**Tilting heads** (head-table and head-head machines), and any control that
can tilt its own work plane: tick **3+2: the control tilts the work plane**
in Post Options. Then an operation on a turned plane is written in the plane's
own coordinates, and the control is told the plane:

```
G68.2 X Y Z I J K
G53.1
...
G69
```

Here X Y Z is the plane's origin, and I J K are its Euler angles: turned about
Z, then about the new X, then about the new Z. The control turns its own
rotaries, whatever its layout. The `tiltOn` and `tiltOff` program blocks hold
those lines, so a control that says it differently (CYCLE800, PLANE SPATIAL,
G268) can be given its own. Without the tick, a plane only the head could face
is refused, saying so.

## 5-axis simultaneous

5-axis operations (**Toolpaths > 5-Axis**) tilt the tool as they cut:

- **Swarf** cuts a drafted or twisted wall with the side of the tool. Pick the
  wall's top chain, then its foot. The tool leans along the wall so its side
  lies on the wall all the way, on the side asked, past the foot by as much as
  asked.
- **Curve 5-Axis** runs the tip along a chain on the part with the tool square
  to the solid under it, leaning forward if asked: for engraving or deburring
  round a curved face.

Any **3D toolpath** can be cut 5-axis too: set **Output format** to 5-axis
on its **Tool Axis Control** page. With a ball end mill, the tool is leant to
the cutting direction (lead and side tilt), away from or towards a point, or
along a fixed direction, capped by a most lean from upright. The ball's
centre stays where the 3-axis path put it, so it touches the part just where
it did.

Each point is turned into the machine's own rotaries: the way that turns
least from where they were, inside their limits, with an endless C carrying on
past 180 instead of winding back. A move the rotaries swing far through is
cut into 2 degree steps, so the tip runs straight.

How the program is written depends on **5-axis: the control keeps the tool's
tip (TCP)** in Post Options:

- **TCP on.** X Y Z are the tip on the part, with the rotaries beside them,
  between `G43.4 H#` and `G49` (the `tcpOn` and `tcpOff` blocks). This works
  for any layout, and is fed a minute.
- **TCP off.** GarageCAM works out where the turned table carries the tip,
  for machines whose rotaries are all on the table, turning about each axis
  where its centre is (the work zero unless it says otherwise). Moves are fed
  in inverse time (G93), so the tip's feed is right however far the table
  turns.

Before posting, the machine check makes sure the rotaries can point the tool
every way the path asks, and that where the turned table puts the axes fits
the travels. The backplot shows the tool leaning, and Verify cuts with it
leaning (seen from above, so an overhanging wall can't show).

A machine with one rotary can run a 5-axis operation whose tool only ever
leans about that axis. On a 4th axis along X (like the Vortex), a Swarf on a
wall running along X is 4-axis simultaneous: A leans the part.

**Not proven yet.** Nobody has run a 3+2 program from GarageCAM on a real
trunnion or 4th-along-Y machine. Until someone does, posting one brings up
**Not Proven Yet**. Run the first program slowly, then use **Help > Report How
a Program Ran**.

## Lathes

Set **Kind** to **Lathe**, and pick a lathe post: Fanuc Lathe, LinuxCNC
Lathe, grblHAL Lathe, or one of your own. Give its spindle range, and its
travels if you know them.

Turning is drawn the way a lathe drawing is read:

- **The bar** is the job's round stock. It lies along X, its end at the
  largest X, the chuck towards -X.
- **The profile** is the part's top half, drawn on Top. Model X runs along the
  spindle (the lathe's Z), and model Y is the radius.

**Profile From Solid** draws the profile off the part's solid. A part
modelled standing up (a puck turned about Z, say) or off the centreline is
offered laid along X first: centred on Y0 Z0, its top end at X0. With the
part along X, **Stock Setup** starts a new stock as a bar round it.

The **Turning** tab holds the operations:

| Operation | What it does |
|---|---|
| Face | Squares the bar's end |
| Rough | Turns down to the profile in passes, then evens out what is left; or bores out a hole the same way, inside |
| Finish | Runs the insert's nose round the profile, outside or inside a bore |
| Groove | Plunges a groove between two walls, outside or in a bore |
| Thread | Cuts a thread in passes along the flank, outside or in a bore |
| Drill | Drills on the centreline |
| Cut Off | Parts the piece off the bar |

Lathe tools are made in the Tool Manager:

- a **turning insert** (its corner radius is the nose, its angle the
  insert's included angle: 80, 55, 35 or 60);
- a **grooving blade** (its diameter is the blade's width);
- a **threading insert**;
- a **drill** for drilling.

A job with no lathe tools is offered a starter set (a turning insert, a
boring bar, a grooving blade and a threading insert) the first time a
turning operation is started; change them to match your own. **Drill**
finds the hole in the part's end on the centreline: it drills to the
hole's bottom (its point past the end of the wall) or right through, with
a drill that size, offered when the job has none.

Switching a definition's **Kind** to Lathe picks the same control's lathe
post (grblHAL to grblHAL Lathe), or Fanuc Lathe; back to a mill, its mill
post.

The backplot shows the insert in the turning plane. Verify turns the bar to
what the program leaves, compared with the part (threads left out). A
turning job on a machine whose Kind is Mill is flagged before posting.

### Coming next

- More 5-axis operations (multiaxis roughing).
- Turning: a holder's own lead angle (now the usual one for the insert), a
  boring bar's size in Verify, and face grooving.
