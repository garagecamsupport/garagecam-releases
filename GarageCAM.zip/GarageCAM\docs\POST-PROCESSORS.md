# GarageCAM post processors

A **post processor** ("post") decides how GarageCAM writes a program for one
control: which G-codes it uses, how a tool change looks, how the program starts
and ends. GarageCAM's posts are plain text files you can read, copy, share and
edit, in GarageCAM or in any text editor. Nothing about them is locked.

If you are an **AI assistant** asked to write or fix a post, read
[FOR-AI-ASSISTANTS.md](FOR-AI-ASSISTANTS.md) as well. It has the rules and a
checklist for doing it safely.

## Where posts live

- **Settings > Post Processors** lists every post. **Open Folder** shows the
  files, **How Posts Work...** opens this guide.
- Each post is a `.gcpost` file in GarageCAM's settings folder,
  `%APPDATA%\GarageCAM\GarageCAM\Posts` on Windows.
- **Built-in posts** are written into GarageCAM itself: grblHAL, Grbl 1.1,
  LinuxCNC, Mach3 / Mach4, and Fanuc / Haas. They can't be changed or deleted,
  so there is always a known starting point to go back to. **Edit** on a
  built-in post offers to make a copy, and you edit the copy.
- A **machine definition** names the post it is posted with. A job takes its
  post settings from that post, and **Post Options** (in the job) adjusts them
  for that one job.

## Control definition and post in one file

Some CAM systems keep a "control definition" (what the controller
understands) apart from the post (how the program is laid out). GarageCAM
keeps both in the one `.gcpost` file:

- **What the control understands** (the control definition):
  - arcs as I/J or R;
  - canned drill cycles;
  - cutter compensation;
  - tool length offsets;
  - inverse-time feed;
  - a decimal point on every number;
  - dwell units;
  - comment style;
  - the rotary axis letter.
- **How the program is laid out** (the post): every **program block**, such as
  the start, Z home, the tool change and the end, plus line numbers, the
  program number, `%` signs, and lines of your own at the start and end.

One file per control is easier to share: "here is the post for my Haas" is a
single file.

## Making a post for your control

1. Start from the built-in post closest to your control: grblHAL for grbl
   machines, LinuxCNC, Mach3 / Mach4, or Fanuc / Haas for most industrial
   machining centres. Select it and click **Copy...**, or **Edit...** (which
   copies a built-in post first).
2. **Edit...** opens Post Options:
   - **The control** group holds what the controller understands.
   - **Program Blocks...** opens the blocks. Each one can be written your
     control's way, and a live preview shows a whole program from a made-up
     job as you type.
3. Compare the preview with a program you know runs on your machine, such as
   one from the machine maker, another CAM program or the control's own
   examples. Make the blocks match it.
4. Post a real job, read it in the NC Editor, then prove it: run it in the air
   first, then on the part with single block and the overrides turned down.
5. Once it has run right, mark it **Proven On...** and say what machine and
   control. Use **Help > Report How a Program Ran** so it is proven for
   everyone with that control.

## Proven and not proven

GarageCAM only knows a post is right once someone has run its programs on a
real machine. The built-in **grblHAL** post is proven on a Sienci AltMill with
its tool changer and the Vortex rotary. The other built-in posts follow their
controls' usual layout, but have not been run on one yet.

Posting with a post that isn't proven shows a **Not Proven Yet** warning that
says how to run the first program safely. At a later start, GarageCAM asks how
it ran. Saying "It ran right" sends a test result to GarageCAM's makers, and
stops the warning on that computer. A post of your own records what it was
proven on. Changing a proven post makes it unproven again, because it's no
longer the post that was proven.

## The file

A `.gcpost` file is JSON. Here is a complete example: a copy of the Fanuc /
Haas post that sends Z home with `G53` and puts the tool's name in a comment at
each change.

```json
{
    "garagecamPost": 1,
    "name": "Haas VF-2",
    "description": "Our Haas VF-2: G53 Z home, tool name at each change.",
    "provenOn": "",
    "options": {
        "units": "inch",
        "workOffset": 54,
        "percentSigns": true,
        "programNumber": 1000,
        "sequenceNumbers": true,
        "alwaysDecimalPoint": true,
        "dwellMilliseconds": true,
        "prestageNextTool": true,
        "toolLengthOffset": true,
        "cutterComp": true,
        "cannedDrillCycles": true,
        "rotaryInverseTime": true,
        "blocks": {
            "homeZ": ["G53 G0 Z0."],
            "toolChange": [
                "(T{T} - {TOOL})",
                "T{T} M6",
                "T{NEXT_T}",
                "G43 H{H}"
            ],
            "homeXY": ["G53 G0 Y0."]
        }
    }
}
```

Rules:

- `"garagecamPost": 1` marks the file as a GarageCAM post. `name` must be
  given.
- Anything left out takes its default (see the table below). A file only needs
  what is different.
- **Lengths in the file are always millimetres**, whatever units the program
  is written in. GarageCAM converts on the way out.
- `provenOn` is empty until the post's programs have run right. Write the
  machine and control there, such as `"Haas VF-2, NGC control"`.
- A block is a list of lines, as above. One string with `\n` line breaks is
  read too.

### The settings

| Key | Values | Default | What it does |
|---|---|---|---|
| `units` | `"inch"`, `"mm"` | `"inch"` | G20 or G21; what the file is written in |
| `workOffset` | 54 to 59 | 54 | The work offset, G54 to G59 |
| `coolantOn` | `""`, `"M7"`, `"M8"` | `""` | Coolant for operations that don't say |
| `emitToolChange` | true/false | true | Write tool changes at all |
| `emitSpindle` | true/false | true | Write M3/M5 at all (some senders run the spindle themselves) |
| `spindleWarmUp` | seconds | 0 | A G4 dwell after the spindle starts |
| `arcFitTolerance` | mm | 0.005 | Fit arcs to runs of short moves within this (0: never); it adds to the operation's own tolerance, so kept small |
| `modalWords` | true/false | true | Leave out words that haven't changed (X alone when only X moves) |
| `sequenceNumbers` | true/false | false | N numbers on every command line |
| `sequenceStart`, `sequenceStep` | whole numbers | 10, 10 | Where N numbers start and how they step |
| `optionalStopAtToolChange` | true/false | false | M1 before each tool change after the first |
| `parkForToolChange` | true/false | false | Go to a tool change position first (G53, machine coordinates) |
| `parkX`, `parkY`, `parkZ` | mm | 0 | That position |
| `returnHome` | true/false | false | At the end, go to `homeX`/`homeY` instead of homing X and Y |
| `endHome` | 0 to 4 | 0 (1 in grblHAL) | At the end, after Z home: X and Y home together (0), X home then Y home, clear of a tool rack at Y home (1), Y home then X home (2), X home only (3), Y home only (4) |
| `homeX`, `homeY` | mm | 0 | Where to end |
| `cannedDrillCycles` | true/false | false | Drilling as G81/G82/G83/G73/G85/G89 |
| `filePerTool` | true/false | false | A file for each tool, for changing tools by hand between files |
| `toolChangeStyle` | 0, 1, 2 | 0 | 0: `T# M6`. 1: stop with M0 and say which tool to put in. 2: nothing |
| `arcsAsRadius` | true/false | false | Arcs with R instead of I/J (long arcs split in pieces) |
| `semicolonComments` | true/false | false | `; comment` instead of `(comment)` |
| `decimals` | 0 to 6 | 0 | Places after the point (0: the usual 4) |
| `rotaryLetter` | `"A"`, `"B"`, `"C"` | `"A"` | The rotary axis letter |
| `headerLines` | text | `""` | Lines after the program start block, as typed |
| `footerLines` | text | `""` | Lines before the program end block, as typed |
| `toolLengthOffset` | true/false | false | G43 H# with each tool, G49 at the end |
| `cutterComp` | true/false | false | The control does G41/G42 D#, so wear compensation is posted |
| `percentSigns` | true/false | false | `%` on the first and last line |
| `programNumber` | 0 to 99999 | 0 | `O` number at the top (0: none). Never for grblHAL, where O is flow control |
| `alwaysDecimalPoint` | true/false | false | `X1.` not `X1`: a Fanuc-style control reads `X1` as 0.0001 inch |
| `dwellMilliseconds` | true/false | false | G4 P in milliseconds (Fanuc) instead of seconds |
| `prestageNextTool` | true/false | false | Call the next tool after each change, for a carousel |
| `rotaryInverseTime` | true/false | false | Moves that turn the rotary in G93 inverse time |
| `blocks` | object | none | The program blocks written your way (below) |
| `tiltedWorkPlane` | true/false | false | 3+2 by the control: operations on turned planes in the plane's own coordinates, the control told the plane (`tiltOn`/`tiltOff`) |
| `fiveAxisTcp` | true/false | false | 5-axis: the control keeps the tool's tip (G43.4); off, GarageCAM works out where a turned table carries it and feeds in G93 |
| `latheDiameter` | true/false | true | Lathe: X on the diameter (off: on the radius) |
| `latheDiameterCode` | text | `""` | Lathe: what puts the control in diameter mode first (`G7` on LinuxCNC and grblHAL) |
| `latheFeedPerRev` | true/false | true | Lathe: feeds a revolution (G95/G99) instead of a minute |
| `latheSpeedStyle` | 0, 1 | 0 | Lathe: constant surface speed as 0: `G50 S max` then `G96 S` (Fanuc); 1: `G96 D max S` (LinuxCNC, grblHAL) |
| `latheThreadCode` | `"G33"`, `"G32"` | `"G33"` | Lathe: a thread pass, `G33 Z K pitch` or Fanuc's `G32 Z F pitch` |
| `latheThreadCycle` | 0, 1, 2 | 0 | Lathe: a thread as 0: every pass written out (with `latheThreadCode`); 1: Fanuc's two-line `G76 P(passes)(pull-out)(angle) Q(least cut) R(last cut)` / `G76 X(root) Z(end) P(depth) Q(first cut) F(pitch)`, depths in microns; 2: the one-line `G76 P(pitch) Z(end) I(peak) J(first cut) R2 K(depth) Q(infeed) H(spring passes)` of LinuxCNC and grblHAL, I, J and K across as X is |
| `latheRoughCycle` | 0, 1, 2 | 0 | Lathe: roughing along the spindle as 0: every pass written out; 1: Fanuc's `G71 U(depth of cut) R(retract)` / `G71 P Q U(stock across, less than nothing in a bore) W(stock along) F`, the part's outline (the tip's path to finish it) on the lines from P to Q; a Finish over the same outline after it (same nose radius, nothing left) becomes `G70 P Q` on those lines, its feed on the first of them; an outline that dips back is still written out pass by pass, unless 2 lets it go as type II (`W0.`, X and Z on its first line) |
| `latheToolOffsetPair` | true/false | false | Lathe: tools as `T0101` (tool and offset) instead of `T1 M6` |

## Program blocks

A block is one piece of the program that GarageCAM writes in several places.
Replace a block and your text goes in every place that block goes, with each
`{WORD}` filled in. Any block you don't replace stays GarageCAM's own, built
from the settings above. **Program Blocks...** in Post Options shows each
block's default text and the words it can use.

| Block | Where it goes | GarageCAM's own (usual settings) |
|---|---|---|
| `programStart` | At the top, after the heading comments and tool list | `G90 G94` / `G17` / `{UNITS}` / `{HOME_Z}` |
| `homeZ` | Z clear of everything: start, before each tool change, before turning the part, the end | `G28 G91 Z0` / `G90` |
| `toolChange` | Each new tool, the first one too, after the old tool's coolant and spindle are off and Z is home | `T{T} M6` (plus the park move, `T{NEXT_T}` and `G43 H{H}` when those settings are on) |
| `spindleOn` | The spindle starting for a cut | `S{S} M3` |
| `spindleSpeed` | The same tool carrying on at another speed | `S{S}` |
| `toolStart` | After each new tool and spindle start: modes said again so a restart at the change runs the same | `G17 G90 G94` / `{WCS}` |
| `index` | The part turned to an operation's angles (Z is home first), and back to 0 at the end | `G0 {ANGLES}` |
| `coolantOff` | Coolant going off | `M9` |
| `spindleOff` | The spindle stopping | `M5` |
| `homeXY` | At the end, after Z is home | by `endHome`: `G28 G91 X0 Y0` / `G90` (0), `G28 G91 X0` / `G90` / `G28 G91 Y0` / `G90` (1, clear of a tool rack: the grblHAL post's), Y then X (2), X only (3), Y only (4); `G0 X{HOME_X} Y{HOME_Y}` with `returnHome` |
| `programEnd` | The very end, after the end lines | `M30` (`G49` / `M30` with tool length offsets) |

### Tilted plane and 5-axis blocks

| Block | Where it goes | GarageCAM's own |
|---|---|---|
| `tiltOn` | Before an operation on a turned plane, with `tiltedWorkPlane` on (Z home first) | `G68.2 X{X} Y{Y} Z{Z} I{I} J{J} K{K}` / `G53.1` |
| `tiltOff` | After it | `G69` |
| `tcpOn` | Before a 5-axis operation, with `fiveAxisTcp` on | `G43.4 H{H}` |
| `tcpOff` | After it | `G49` |

`tiltOn`'s words:

- `{X}`, `{Y}` and `{Z}`: the plane's origin in the work offset.
- `{I}`, `{J}` and `{K}`: its Euler angles, turned about Z, then the new X,
  then the new Z.

For other controls, for example:

- a Siemens 840D: `CYCLE800(...)`;
- a Heidenhain: `PLANE SPATIAL SPA{I} SPB{J} SPC{K} TURN`.

Check the angle convention in the control's manual.

The 5-axis moves themselves are written by GarageCAM:

- `G1 X Y Z` with each rotary's letter and angle;
- fed in inverse time (G93 ... G94) when GarageCAM works the table out (TCP
  off), or with `rotaryInverseTime`;
- otherwise fed a minute.

### Lathe blocks

A program with turning in it is written as a lathe program. It uses the
`spindleOff`, `coolantOff` and `programEnd` blocks above, plus these:

| Block | Where it goes | GarageCAM's own |
|---|---|---|
| `latheStart` | The top of a turning program | `G18 G90 G40` / `{UNITS}` / the diameter code / `{LATHE_HOME}` |
| `latheHome` | The turret clear: before each tool change and at the end | `G53 G0 X0` / `G53 G0 Z0` (X out first) |
| `latheToolChange` | Each new tool | `T{TT}{TT}` with `latheToolOffsetPair`, else `T{T} M6` |
| `latheToolStart` | After each new tool | `{WCS} {FEED_MODE}` |
| `latheConstantSpeed` | The spindle for an operation at a surface speed | `G50 S{MAX}` / `G96 S{SPEED} M3`, or `G96 D{MAX} S{SPEED} M3` |
| `latheSpindleOn` | The spindle for an operation at the tool's rpm | `G97 S{S} M3` |

Their words:

- `{TT}`: the tool number in two figures (`01`).
- `{SPEED}`: the surface speed, m/min, or ft/min in an inch program.
- `{MAX}`: the most rpm allowed.
- `{FEED_MODE}`: `G95` or `G94`.
- `{LATHE_HOME}`: the `latheHome` block.

How a lathe program is written:

- **Axes.** X is across: on the diameter, or on the radius if the post says
  so. Z runs along the spindle.
- **Arcs.** I is always on the radius, K is along Z, in G18.
- **Reference point.** Each point is where the tool was touched off:
  - a turning insert's imaginary tip (a nose radius in front of the nose's
    centre, and a nose radius below it);
  - a grooving blade's front corner;
  - a threading insert's point;
  - a drill's point.
- **Feeds** go out a revolution (the move's rate divided by the tool's rpm),
  or a minute.

The built-in lathe posts:

| Post | Tool change | Turret home | Surface speed | Threads | Other |
|---|---|---|---|---|---|
| Fanuc Lathe | `T0101` | `G28 U0.` / `G28 W0.` | `G50` cap | `G32` | `G99` feeds, `%` and an O number |
| LinuxCNC Lathe | `T1 M6 G43` | | `G96 D` | `G33 K` | `G7` diameter mode |
| grblHAL Lathe | `T1 M6` | | `G96 D` | `G33 K` | `G7` diameter mode |

None of them has run on a lathe yet.

### Words

Every block can use these:

| Word | Filled in with |
|---|---|
| `{PROGRAM}` | The program's name (the file's name, in capitals) |
| `{O}` | The program number, four figures (nothing when there is none) |
| `{UNITS}` | `G20` or `G21` |
| `{WCS}` | The work offset in use, `G54` to `G59` |
| `{AXIS}` | The rotary axis letter |
| `{POST}` | The post's name |
| `{DATE}` | The day it was posted, `2026-10-21` |
| `{HOME_Z}` | The lines of the `homeZ` block |

The blocks that belong to a tool (`toolChange`, `spindleOn`, `spindleSpeed`,
`toolStart`) can also use these:

| Word | Filled in with |
|---|---|
| `{T}` | The tool number |
| `{NEXT_T}` | The next tool the program calls for, or nothing after the last |
| `{TOOL}` | The tool's name |
| `{DIA}` | The tool's diameter, in the program's units |
| `{H}`, `{D}` | The length and diameter offset numbers (the tool number) |
| `{S}` | The spindle speed, rpm |

A few words belong to one block only:

- `toolChange` also has `{PARK_X}`, `{PARK_Y}` and `{PARK_Z}`, the tool change
  position.
- `index` has:
  - `{ANGLES}`, every rotary turned as the program says it: `A90`, or
    `A-54.7356 C-45` on a trunnion table;
  - `{ANGLE}`, the first one's angle alone (and `{AXIS}` is its letter);
  - `{ANGLE_A}`, `{ANGLE_B}` and `{ANGLE_C}`, each axis's angle, with nothing
    for an axis that doesn't turn.
- `homeXY` has `{HOME_X}` and `{HOME_Y}`.

For example, a control that wants each rotary on a line of its own:

```json
"index": ["G0 A{ANGLE_A}", "G0 B{ANGLE_B}", "G0 C{ANGLE_C}"]
```

A line whose axis doesn't turn is left out.

Rules for filling in words:

- A word with nothing to say (`{NEXT_T}` after the last tool) takes the space
  in front of it with it.
- A line whose words all have nothing to say is left out. `T{NEXT_T}` on a
  line of its own disappears after the last tool change.
- An empty block writes nothing. In the file that's `"spindleOff": []`.
- A word GarageCAM doesn't know stays exactly as typed, so a typo shows in the
  program instead of hiding.
- Comment style (`;`) and N numbers are applied after the blocks are written,
  so block lines get them too.

## The order of a program

```
%                              percentSigns
O1000                          programNumber
(PROGRAM NAME)
(Posted by GarageCAM with the ... post on ...)
(T1 D=0.25 CR=0 - ZMIN=-0.5 - flat end mill)    one line per tool
[programStart]
start lines                    headerLines

(Operation - Kind)             for each operation:
G55                              its own work offset, if it has one
                                 a new tool:
[coolantOff] [spindleOff] [homeZ]   the old tool done (not before the first)
M1                                  optionalStopAtToolChange (not the first)
[toolChange]
[spindleOn]  G4 P..              or [spindleSpeed] for the same tool
[toolStart]                      after a new tool
M8 / M7                          coolant, when it changes
(Index the A axis to 90 degrees) turning the part
  or (Turn the part: A30 C45)      (on other layouts):
[homeZ] [index]
G0 X.. Y..  G0 Z..               over the start, then down to clearance
...the cut...
[spindleOff]                     unless the next operation uses the same tool

[coolantOff]                   the end
[homeZ]
(A axis back to 0) [index]     if the part was left turned
[homeXY]
[spindleOff]
end lines                      footerLines
[programEnd]
%
```

## Examples

The examples below follow what those controls usually take. Check them
against your own machine's manual and a program you know runs, then prove the
post.

**Z home with G53** (most industrial controls, Mach4, LinuxCNC):

```json
"blocks": { "homeZ": ["G53 G0 Z0"] }
```

**A machine whose tool change is a macro you call** (Fanuc custom macro: `G65`
passes T to the macro as #20):

```json
"blocks": { "toolChange": ["G65 P9000 T{T}", "G43 H{H}"] }
```

**Tools changed by hand, with a message on the control's screen** (LinuxCNC
`MSG`):

```json
"blocks": { "toolChange": ["(MSG, Put in T{T} {TOOL} {DIA} dia)", "M0"] }
```

**A spindle that takes time to come up, and a dust shoe**:

```json
"blocks": { "spindleOn": ["M64 P0", "S{S} M3", "G4 P3"], "spindleOff": ["M5", "M65 P0"] }
```

**No G28 at the end; park at the back instead**:

```json
"blocks": { "homeXY": ["G53 G0 X0 Y0"] }
```

## Sharing a post

**Export...** in Post Processors writes the `.gcpost` file, and
**Import...** reads one. Send your post to someone with the same control.
Once it has run right on yours, send it to GarageCAM's makers with **Help >
Send a Suggestion** too, so it can become a built-in post for everyone.
