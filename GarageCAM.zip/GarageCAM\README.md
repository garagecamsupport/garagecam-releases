<img src="docs/logo.png" width="96" alt="GarageCAM logo" align="right">

# GarageCAM

CAD · CAM · NC for the Sienci AltMill (grblHAL) with Vortex rotary 4th axis.

![GarageCAM: the Toolpaths ribbon, the operations manager and the viewport](docs/garagecam.png)

See [CLAUDE.md](CLAUDE.md) for the project brief and roadmap.

## Prerequisites

| Tool | Notes |
|---|---|
| Visual Studio 2022 Build Tools | "Desktop development with C++" workload (MSVC x64, Windows SDK) |
| CMake 3.24+ | |
| Ninja | |
| vcpkg | Cloned and bootstrapped at `C:\dev\vcpkg` |
| Qt 6.9.3 (msvc2022_64) | Installed to `C:\Qt` via `aqtinstall` |

Qt is installed separately rather than through vcpkg: the vcpkg `qtbase` port
builds Qt from source, which takes many hours. OCCT comes from vcpkg via the
manifest in `vcpkg.json`.

To reinstall Qt on a fresh machine:

```powershell
python -m pip install aqtinstall
python -m aqt install-qt windows desktop 6.9.3 win64_msvc2022_64 -O C:\Qt
```

## Build

Point `QT6_DIR` at the Qt CMake package directory, then configure and build:

```powershell
$env:QT6_DIR = "C:\Qt\6.9.3\msvc2022_64"
cmake --preset release
cmake --build --preset release
```

The executable lands in `build/release/GarageCAM.exe`. `windeployqt` runs after
the link step, so it is runnable in place.

## Layout

A ribbon across the top (Home, Wireframe, Surfaces, Solids, Transform,
Toolpaths, Planes, View) and a manager on the left with **Toolpaths**, **Solids**,
**Levels**, **Planes** and **Recent** tabs. The **Solids** tab lists each solid with its
level, faces and size: double-click picks it in the graphics, and its menu renames it,
shows only its level or deletes it. Right-click anything in the manager for its
menu; double-click a toolpath to edit it, a level to make it main, a plane to
draw on it, or **Properties > Stock setup** to set the block. The status bar
shows how many entities are selected, the main level and the active
construction plane.
**Change Level...** (on the graphics' right-click menu once something is
selected, and on the Home tab) moves what is selected onto another level, or
copies it there leaving the original where it is (each copy a shape of its
own): pick the level from the list, or a new one with its number and name,
and tick *Show that level* so what goes there can be seen.
A level's right-click menu also has **Show Only This Level**, **Show All
Levels** and **New Level**, and **Workholding**: import the vise jaws, clamps or
fixture plate onto a level of their own and mark it, and what is on it is never
taken for the part (stock from model, holes and floors picked off solids, Auto
Pockets and Auto Drill, Verify's compare and Horizontal Area's floors leave it
out), while 3D paths still stay above it and the model check names any cut
into it as a cut into the workholding. Workholding is drawn in amber.
**Select Everything on This Level** picks what is on it (showing it first if it
was hidden), and **Hide All But the Main Level** clears the view down to where
new geometry goes. **Level sets** show and hide levels together, a fixture's
or one setup's: **Put in a Level Set...** names the set a level is in (one
there already, or a new name; empty takes it out), shown in the list's Set
column, and **Show / Hide Set** and **Show Only Set** work on all of its levels
at once (the main level stays shown). Under the list, the main level can be
typed in: a number makes that level main, made new if there is none, with its
name and set beside it. **List** shows all levels, those used, those named, or
either (the main level always), with how many there are, shown and used.
The **Planes** tab marks with G, C, T and W the plane the view looks along,
the construction plane, the tool plane and the WCS; a click in one of those
columns moves that one to the plane (G turns the view to look straight at it).
The **Recent** tab lists the commands used lately, newest first; double-click
one to run it again.

**Help > Shortcuts** lists every key the program has, read off the commands
themselves rather than a note that might be out of date. **Help > About** says
what GarageCAM is and what it is built on.

**Settings > Look** (or the File page's Settings) picks how the window is
drawn: **Graphite**, the dark look (dark panels round the model, a dark title
bar on every window, orange for the tab in use, the button Enter presses and
whatever is ticked or selected), or **Daylight**, light grey panels with blue.
Everything outside the 3D view takes its colours from the one chosen, icons'
outlines and the NC editor's code colours included; the view keeps its own
background setting. The look is set as GarageCAM starts, so choosing the other
one offers a restart that opens the same job again.

## Viewport controls

| Input | Action |
|---|---|
| Middle drag | Orbit |
| Shift + middle drag | Pan |
| Wheel | Zoom at cursor |
| Left click | Act with the current tool; in Select, pick an entity |
| Left drag (Select) | Window select; Shift adds to the selection |
| Right click | End the current run, keeping the tool active; with nothing running, the graphics menu: Z depth and level for new geometry, Zoom Window, Unzoom 80%, Fit, the views and the Gview list, Cplane From Solid Face, Select All, Delete (with something picked), Measure, Analyze and the display switches |
| Esc | Drop what is half done; again, end the command and go back to selecting (wherever the keyboard is in the window, unless a field is being typed in) |
| Click a number field | Its whole value is picked, so typing replaces it |
| Space (while drawing) | Type the next point: `1.5, 2`, `x1 y2 z-1/4`, `@dX, dY` from the last point, or `@length<angle`; after a circle's centre, `r1/4` or `d1/2` for its size; fractions and sums such as `1+3/8` work. The point, and the line or shape it would finish, show as you type. Starting to type a number opens the box too |
| Alt+1 … Alt+7 | Top, Front, Back, Bottom, Right, Left, Isometric (as the active WCS sees them: with a plane of its own as the WCS, Top looks down its Z) |
| Alt+S | Solids shaded or wireframe |
| Alt+X | Solids translucent (see-through) or not |
| Alt+T | Toolpaths shown or hidden (they still play back) |
| Alt+O | Manager shown or hidden |
| F9 or Ctrl+G | Axes |

**Light Background** on the View tab switches between the light grey-blue
background with dark blue wireframe (the default, as most CAD programs open)
and the dark one with white wireframe. It is kept between sessions.
**Translucent** (Alt+X, View tab, and the right-click menu) draws the solids and
surfaces see-through, so the toolpaths, wireframe and holes behind and inside
the part show; it is kept between sessions too.

Menus, dialogs and panels have GarageCAM's own look in the same greys and
blue: right-click and drop-down menus with roomy rows, a rounded highlight
and rounded corners with a soft shadow (Windows 11), rounded buttons with the
one Enter presses in blue, boxes that edge blue when typed in, slim scroll
bars and dark tooltips.

**Section View** (View tab, Ctrl+Shift+X) cuts the view at the construction
plane, at its Z depth, taking away what is above and filling the cut faces in
colour, to see inside a part or a verify result. Change the Cplane or the Z in
the status bar to move the cut; **Flip Section** keeps the other side.

## Units

GarageCAM works in **inches** unless you tell it otherwise. Everything inside
it — geometry, toolpaths, the saved job — is held in millimetres, and inches
exist only at the two edges: what is shown on screen, and what is posted to the
machine. That way nothing in between can ever mix the two.

- **Settings > Units on Screen** switches every box, table, readout and message
  between inches and millimetres. It is your own setting, kept between jobs.
  Switching it moves nothing; the same part is just described in the other
  unit.
- **Post Options > Units** decides what the program is written in, `G20` or
  `G21`. It belongs to the job and has to match what the controller is set to.
  The setup sheet is written in the same unit as the program it goes with.
- The starter **tool library** is inch cutters with inch feeds. An exported
  library says on its first line which unit it is in, so it reads back right
  whichever way the program is set; a library with no such line is read as
  millimetres, as every one written before this was.
- **STL files never say their unit**, and a DXF may not. GarageCAM asks which
  it was drawn in, showing the size it would come in at either way, because a
  wrong guess is a part 25.4 times off.

## Wireframe

Geometry is drawn on the active construction plane. Endpoints, midpoints and
arc centres snap within 12 pixels, shown by a yellow marker.

While a drawing command runs, its settings show in the **function panel**,
a tab where the Manager sits, brought to the front for the command and handed
back to the Manager when it ends: the Line's type, length and angle; the
Circle's diameter; the Rectangle's width and height; the Arc's radius and
angles; Fillet's radius and Chamfer's lengths; Offset's distance and copies;
Parallel's distance, Modify Length's change, Arc Tangent's and Arc Endpoints' radius, Line Bisect's length; and,
for the commands that only take clicks (Line Tangent, Perpendicular, Circle
Tangent, Arc and Circle by 3 points, Spline, Point), what to click. A number
typed there is used for every pick until it is changed, with no box asking
for it each time. The chaining panel shows there too while chains are picked.

Every command run from a panel or a window has **OK**, **Repeat** and
**Cancel**. OK keeps what it did and closes; Repeat keeps it and starts the
command again for another; Cancel takes back everything it did since it
started (or since the last Repeat) and closes. That holds for the drawing
commands (Line, Arc, Trim, Break, dimensions...), the commands that pick on a
solid (Curve One Edge, Curve All Edges, Fillet or Chamfer Edges, Surfaces from
Solids, Remove Faces, Hole, Push-Pull, Blend, Plane from Face), Dynamic, and
the windows that make or change something (Polygon, Ellipse, Bolt Circle,
Hole Grid, Text, Rounded Rectangle, the primitives, Helix, Spiral, Hatch,
Rectangular Array, Distribute, Nest, Roll, Change Level, New Plane, Bounding
Box, Break into Pieces, Shell, Extend, Offset, Thicken and Fillet Surfaces,
Trim to Plane). Those windows **show what they make as soon as a field is
left**, and make it again as fields change. **Translate, Rotate, Mirror and
Scale** run in the function panel beside the view the same way: the selection
moves as soon as a number is typed and left (X 1.0, then a click into Y, and
it is there), what is selected can be changed while the panel is open, and
Repeat keeps the move and moves the next selection the same way. Esc takes a
transform back. **Curve All Edges** takes the faces clicked, or with none
clicked (OK straight away) every edge of every solid as before. Picking a
solid's edges or faces no longer takes wireframe lying on them (a circle drawn
on a hole's edge) by mistake.

**Deleting geometry an operation uses** asks first, naming the operations:
**Do Not Delete**, **Delete**, or **Only Delete Entities Not Used in
Toolpaths** (what an operation's chains, islands, holes, points, boundary and
surfaces are made of).

| Key | Tool | Points |
|---|---|---|
| S | Select | Click to add to the selection (click again to drop), or drag a window; Esc clears. Ctrl+A selects all. |
| L | Line | Start, then end; each line starts with a click of its own (tick **Multi-line** to keep going from the last point). Freeform still snaps exactly horizontal or vertical, along the Cplane, when the line comes within 10 pixels of it (the end shows the snap marker; not when the end is on a point or typed); hold Shift to leave it free. The Line panel (function panel) makes it horizontal or vertical, starts it from its middle, and holds a typed length or angle. |
| R | Rectangle | Two opposite corners, square to the active plane. Its panel holds a typed width and height (both set: one click places it) and anchors it at its centre. |
| C | Circle | Centre, then a point on the radius. With a diameter typed in its panel, one click places it. |
| A | Arc | Centre, start, end. Counter-clockwise; hold Shift for the other arc. With a radius typed in its panel, with start and end angles, one click places it at its centre. |
| O | Offset | Set the distance, copies and copy or move in the Offset panel, then click a chain and click the side to offset it to (each copy that far again from the last; inward copies stop when the next would not fit). **Slot** (the usual offset-chains slot) needs only the chain: an open one gets both sides and a half circle round each end, one closed slot twice the distance wide; a closed one a band, out and in. |
| T | Trim | Click the piece to keep, then the entity to trim against; one that stops short of it is run on to meet it. The arrow beside Trim has **Trim 2 Entities** (click both on the sides to keep: a corner, each trimmed or run on), **Trim Many** (select the entities first, then click the one to trim them to and the side to keep), **Break Many** (the same, broken where they cross it), Divide and Modify Length. |
| F | Fillet | Set the radius in the Fillet panel, then click two entities near each corner, pair after pair; untick Trim to keep them whole. |
| Shift+X | Chamfer | Set the two distances in the Chamfer panel, then click two straight entities near each corner. |
| H | Chain | Click an entity to follow it end to end. |
| Shift+Q | Spline | Click the points it goes through, then Enter or right click. |
| Shift+W | Divide | Click the piece to take out, between the entities that cross it. |
| Shift+K | Break | Click an entity where it should be split in two. |
| Shift+J | Join | Makes selected lines in line, or arcs on one circle, that meet or overlap, one again. |
| Shift+O | Curve One Edge | Click edges of a solid or surface to copy just those as wireframe. |
| Ctrl+W | Curve All Edges | Every edge of the selected solids, on a level of its own. |
| | Curve Slice | Where the Cplane, at the Z depth, cuts through the selected solids and surfaces (or all showing): the part's outline at that height, a hole coming back as one circle. |
| | Silhouette Boundary | Under the arrow beside Curve Slice: the outline of the selected solids and surfaces (or all showing) seen straight down the Cplane, laid flat at the Z depth — what a contour round the whole part follows. Holes right through come back as their own outlines. |
| | Curve Intersect | Also under Curve Slice's arrow: select two solids or surfaces, and the curves where they meet become wireframe. |
| Page Up / Page Down / F2 | Zoom in, zoom out, zoom out to half |
| F1 | Zoom window: drag a box round what to fill the view with |
| Alt+F2 | Unzoom to 80% |
| F3 | Repaint |
| F4 | Analyze (also Shift+A) |
| F5 | Delete (also Del): the selected geometry, or the operations picked in the manager when it has the keyboard |
| Alt+U | Undo (also Ctrl+Z) |
| Alt+Z | Levels manager |
| Analyze > Analyze Chain | Check the selected chains for pieces too short to matter, doubling back, wireframe lying on wireframe, and ends that nearly meet (the gaps a chain stops at) |
| Analyze > Analyze Toolpath | Click a toolpath: which operation and move it is, the kind of move, where from and to (and an arc's centre and radius), its feed and tool |
| Ctrl+C / Ctrl+V (graphics) | Copy the selected wireframe and points, paste them where they were (into this job or another); Home > Copy Image puts the view on the clipboard as a picture |
| View tab | Zoom Window, Unzoom 50%/80%; Show Grid, Snap to Grid and Grid Spacing (a grid on the Cplane: clicks with no point near land on its nearest crossing) |
| Shift+D | Measure | Two points; reports the distance and dX/dY/dZ, in 3D. Snaps to the ends, midpoints, centres, quadrants and crossings of wireframe and to the corners, edge middles and hole centres of solids, so it goes from drawn wireframe straight to the model; where a top corner sits over a bottom one it takes the one nearer the eye. |
| Shift+A | Analyze | Click an entity, or an edge of a solid, for its type, size, ends and level; a wireframe entity opens **Entity Properties**, where a line's ends, length and angle (the length and angle move the end) or an arc's centre, radius or diameter and start and end angles are typed over to change it (entity properties, as other CAM software has them). **Area** (under the arrow beside it) gives the area, perimeter and middle of each closed chain selected; **Angle** the angle between two selected lines, or with nothing selected, between two lines clicked, wireframe or edges of a solid; **Length** the total length of the selection. |

**Point** (Wireframe tab, Ctrl+.) places points where you click, snapping to
ends, midpoints and centres. Select points (the Points mask helps) and press
Drill or Spot Drill to drill them straight away, with any circles selected
alongside. **Points at Centres**, **Points at Ends**, **Points Along** (a
number of them, evenly by length) and **Points at Crossings** (wherever two of
the selected entities cross or touch, once each) make points from the selected
wireframe; they drop down from the arrow beside **Point**.

**Arc 3 Points** and **Circle 3 Points** draw through three clicks, **Circle 2
Points** across a diameter from two. **Line Closest** draws the shortest line
between two entities selected first. **Parallel**
copies a line (or an arc, concentric) a distance to the side clicked.
**Perpendicular** runs a line from a point square to a line or an arc (a line
taken as running on past its ends). **Line Tangent** touches an arc and a second
arc or a point, on the side each was clicked. **Arc Tangent** is an arc of a
radius touching two lines or arcs (or one and a point), in the corner the clicks
were near, leaving them untrimmed; **Arc Endpoints** runs between two clicked
ends at the panel's radius, taking whichever of the four such arcs (either
side, the short or the long way round) is nearest a third click; a radius too
small to span the ends becomes a half circle. **Line Bisect** halves the angle
between two lines from where they cross (even past their ends), between the
arms they were clicked on, at the panel's length; two parallel lines give the
line half way between them. **Circle Tangent** (under the arrow beside
**Circle**, with Circle 3 Points) is the circle touching three lines, arcs or
points, such as the circle inside a triangle. All of them work flat in the
Cplane. **Close
Arc** makes arcs whole circles; **Break at Crossings** breaks the selected
wireframe wherever it crosses itself. **Hide** (Alt+E, Home tab) puts the
selection out of sight for now without deleting it; **Unhide All** brings it back.

**Fillet Chains** rounds every corner of the picked chains at one radius. The
entities are trimmed where they are and only the corner arcs are new, so an
operation already on the chain follows the rounded shape. **Chamfer Chains** does
the same with a straight cut, the same length back along each side of every
corner.

**Change Length** (its own button on the Wireframe tab, and under Trim) type
a distance and Extend or Shorten in its panel, then click lines and arcs near
the end to change: each is made that much longer or shorter there (an arc goes
further round its circle), the end nearest the click as it looks on screen. **Line by Angle** types a line in from
a start point, a length and an angle on the construction plane. **Helix** types
in an exact helix up the Cplane's Z: centre, base Z, radius, pitch, turns and
which way it winds — a thread's path, or a helical ramp to draw round a bore.
**Spiral** goes out from a start radius by a horizontal pitch
each turn and up by a vertical one, each changing evenly from its first to its
last value over the turns: flat with no vertical pitch, a spring or a scroll
with both, drawn as one smooth spline.

**Colour** (Home tab) colours the selected wireframe from a palette, and new
wireframe is drawn in the colour picked last; Default follows the background.
Colours are saved with the job.

**Delete Duplicates** (Home tab) removes wireframe lying exactly on top of
other wireframe, keeping one of each: imports and Curve All Edges often leave
doubles that stop a chain closing. **Small Arcs** (Home tab) finds
the arcs under a radius (and, if given, under a sweep) on the levels showing,
and selects or deletes them: the slivers an import or an offset leaves.

**Undelete** (Home tab) brings back what the last Delete took, without undoing
anything done since; again for the delete before that. Entities come back
with their own ids, so an operation chained on them builds again by itself.

**Break into Pieces** cuts the selected entities into a number of equal
lengths. **Rounded Rectangle** is typed in: width, height, corner radius and
where it sits, or an obround with the ends fully round, or a **single D** (a
circle with one flat: the width its diameter, the height from the flat to the
far side) or a **double D** (two flats, the height across them).

Polygons (any number of sides, across corners or across flats, with corner
radii), ellipses and arcs of ellipses, bounding boxes of the selection, and
**text** in any font on the machine — sized by cap height, sitting on the
baseline you give it, or wrapped round an arc (across the top reading
clockwise, or along the bottom reading left to right, the baseline point then
the arc's centre) — are typed in rather than clicked, under *Type in*.
Lettering comes out as outlines: engrave down the middle with a V bit, pocket
them out, or profile round them. **GarageCAM Single Line**, at the top of the
font list, is lettering of its own drawn as single strokes (capitals, digits
and common marks, true arcs for the round parts), for engraving serial numbers
and labels along the line with a V bit or a drag point. While chaining, Ctrl+A picks every chain
showing, so a line of text is one operation rather than forty clicks. They are
built on the active construction plane, so a polygon drawn on Front stands up.

Transform (select first): Translate, Rotate, Mirror and Scale, each as a move
or as copies. They work on imported solids too, which is how to bring an
off-origin STEP part to the origin. Rotate, Mirror and Scale take their centre
typed or clicked (**Pick the Centre**), Translate its move typed or as two
clicked points (**Pick From and To Points**): the dialog steps aside for the
pick and comes back filled in. Everything is in the construction plane: Delta
X runs along the Cplane's X, a centre is measured from its origin, Mirror's
axes and Rotate's are its own, so on a part stood up on Front, Delta Y is up.
Nothing is filled in to start with: every distance starts at 0.
**Move to Origin** moves the selection so the point clicked lands on X0 Y0 Z0.
**Translate to Plane** carries the selection from one plane onto another (moved
or copied), keeping where it sits on it: a profile drawn on Top stood up on
Front. **Stretch** takes a window (two corners) and a move (from, to): what lies
wholly inside moves, and lines with one end inside stretch to follow.
**Geometry Nesting** lays parts out on sheets: select the parts (each closed
outline is a part, with whatever lies inside it), give the sheet size, the
space between parts, the margin and how many of each, and copies (or the
originals) are set out in rows on as many sheets as it takes, turned a quarter
turn where that suits, with the sheets drawn on a "Nest sheets" level. Parts
are nested by their **true shape** (each outline laid on a fine grid, grown by
half the spacing, and tried turned 0, 90, 180 and 270 degrees, placed where it
keeps the sheet most compact: triangles pair up and an L tucks into another) or,
as a choice, by their boxes.

**Distribute** spaces the selected shapes out along X or Y: each closed
outline with what is inside it, and each run of joined entities, is one shape.
Even gaps or even centres keep the first and last where they are; a set gap
puts each that far after the one before. Operations on them follow.

**Rectangular Array** copies the selection in rows and columns: instances,
spacing and angle for each of two directions in the Cplane, the selection
being the first of them.

**Dynamic** (Shift+G) puts a gnomon of handles on the selection instead.
First it is placed: the gnomon follows the mouse, snapping to the ends,
middles and centres of wireframe and to the corners, edge middles and round
edges' centres of solids (the snap marked in yellow), and a click puts it
down there: the point the selection is held by, moved from, turned and scaled
about. Enter (or a right click) leaves it in the middle of the selection.
Then drag an arrow to slide along that axis, a ring to turn, a knob to scale,
a square to slide in that plane, or the ball to take it anywhere, snapping to
points (so a corner picked first lands exactly on another). Slides step by
0.01 in (0.1 mm) and turns by a degree; hold Shift to drag freely. A small
panel shows what the drag has done so far, and the numbers can be typed over
to make it exact. **Place Gnomon** puts it somewhere else at any time, the
geometry staying where it has got to; with *Arrows move the gnomon only*
ticked, the arrows move the gnomon instead and a click off the handles puts
it on the point clicked. Move or Copy, and copies repeat the whole move again
each time. Enter or right click applies, Esc drops it.

**Project** (Shift+U) carries the selected wireframe down the construction
plane's Z onto the selected surfaces and solids (all that are showing, if
none is selected), or flat onto a depth. Each piece lands where it first meets
the shape and breaks where it runs off it. The depth can be typed, or
**picked**: the box steps aside, a point is clicked (it snaps to wireframe and
to the corners, edge middles and hole centres of solids), and the box comes
back with that point's height along the Cplane's Z.

**Roll** wraps flat wireframe round a bar on the rotary: X stays along the
bar, flat Y goes round it, for a diameter you give. Draw the engraving flat
above the part, roll it on to see it where it will be cut, and **Unroll** it
flat again. It is the same roll that wrapped toolpaths use.

The **selection bar** at the right of the quick access row holds a quick
mask: Everything, Wireframe, Lines, Arcs and Circles, Splines, Solids or
Surfaces. With a mask set, a click, a window and Select All pick up only that
kind of geometry, so drawing a window over a part takes just its circles for
drilling. **All**, **Invert** (among what the mask allows), **Level** (everything on
one level) and **None** sit beside it.

Chaining walks outward from the clicked entity, stops at branches rather than
guessing a direction, merges co-circular arcs, and never runs through geometry
on a hidden level.

**Bolt Circle** types in a ring of holes: centre, pitch circle diameter, hole
diameter, how many, and the angle the first one sits at. Each hole is drawn as
a circle of its own size on the construction plane, so one Drill operation
takes the lot by diameter. A spread of 360 divides the whole way round;
anything less puts a hole at each end of the arc.

**Hole Grid** does the same for rows and columns: where the first hole goes,
how far apart across and up, how many of each, and an angle to turn the whole
grid about its first hole. A fixture plate is one dialog and one Drill
operation.

### Drafting

The **Drafting** tab puts dimensions and notes on the drawing for a print:
**Linear** (Ctrl+Shift+D) measures straight between two points, **Horizontal**
and **Vertical** only along the Cplane's X or Y, each from two clicks that snap
to ends, midpoints and centres, then a third for where the dimension line sits;
**Radius** and **Diameter** take an arc or circle and where the leader goes;
**Angular** takes two lines and where it goes, measuring the angle on that
side from where the lines meet (even past their ends); **Point Dimension**
labels a point (snapped to the feature) with its X and Y from the WCS origin,
at the end of a leader;
**Note** places text; **Leader** points at something (click the point,
snapped to the feature, then where its words go, and type them): an arrow,
a line out to a short landing and the words, the arrow and words keeping
their size on screen at any zoom. The values are written in the shop's units, like
everything else. Dimensions live on levels, save with the job, select and
delete like other entities, and are annotation only: nothing ever cuts them.

**Hatch** fills the closed shapes selected with rows (spacing, angle, and a
second set square to the first for cross-hatch); a shape inside another is
left as a hole, and one inside that filled again. Unlike the dimensions the
rows are ordinary lines on the current level, so an Engrave or a Contour with
compensation off can cut them: a filled engraving.

## Surfaces and solids

The **Surfaces** tab builds surfaces from wireframe: extrude, revolve, ruled,
loft, sweep, flat boundary, draft and net. The **Solids** tab builds solids the same way
(extrude, revolve, loft), and then adds, removes and intersects them, rounds
every edge at a radius, or hollows one out into a tray.

Both pick chains a click at a time: click a chain to add it, click it again to
drop it, and press Enter or right-click when the list is complete. The order
matters for a loft or a sweep, and the picks are numbered by colour. Every
result is checked for valid geometry before it reaches the document, and
surfaces are built from copies, so the wireframe they came from is untouched.

Surfaces that already exist can be worked on too. **Surfaces from Solids**:
with nothing selected, click the faces wanted (each is marked) and Enter, and
each becomes a separate surface on a level for its solid; with solids selected
first, every face of them. **Untrim** takes the trim off a surface, back to the whole surface
it lies on; **Extend** grows surfaces past their edges by a distance;
**Offset** copies them along their normals; **Flip Normals** turns them
round. **Primitives** (block, cylinder, sphere, cone, torus) are made as
surfaces on the Surfaces tab and as solids on the Solids tab.

On the Solids tab, **Fillet Edges** and **Chamfer Edges** round or bevel the
edges clicked one by one (they light up as they are picked; Enter or a right
click finishes and asks for the size), or every edge of any solids selected
whole first. **Sew** joins selected surfaces that close a volume edge to edge
into one solid, turned to face out; a gap is refused, with the number of open
edges, rather than made into a solid with a hole in its skin. **Thicken**
grows the selected surfaces into a solid of a thickness, along
their normals or half each side.

**Hole** drills into a solid square to the face clicked: plain, counterbored
or countersunk, to a depth with a drill point (180 for a flat bottom) or
through all. It goes where the face is clicked, or at each point and circle
centre selected beforehand. **Remove Faces** takes faces out of a solid and
heals over them: click every face of a fillet, chamfer, hole or boss, then
Enter or a right click, to machine or measure the simpler part. **Push-Pull**
moves a flat face out (adding material) or in (taking it away) along its
normal. **Sweep** runs a closed profile along a path chain into a solid.

**Trim to Plane** keeps what lies on one side of the construction plane.
**Trim to Chain** cuts surfaces with a closed chain, looking down the
construction plane's Z, keeping inside or outside it. Either can **split**
instead, keeping both sides as two surfaces. **Fill Holes** makes a new
surface in each hole, on the surface the hole is in; **Remove Holes** closes
them up in the surface itself. **Fillet Surfaces** rounds the corners where the
picked surfaces meet: they are joined along the edges they share into one
surface, with a round of the radius given in each sharp corner (edges already
smooth are left alone). **Blend** bridges two surfaces: click an edge of each,
and a surface runs across between them, leaving each tangent to it all along
the edge (a cubic across, exactly, however the edges curve), its sides straight
between the edges' ends. It always leaves a face outwards, off it, even from
an edge inside an L-shaped face that faces back towards the rest of it.

**Draft** pushes closed chains up the Cplane's Z like an extrude, with the
walls leaning at an angle: positive leans out (a mould's draft), negative
leans in, and the top is exactly at the height asked for. **Net** stretches a
patch across chains that close a loop between them, pulled through any other
chains picked inside the loop.

3D toolpaths machine surfaces exactly as they machine imported solids.

## Levels and planes

Every entity is on a level. Each STEP import and each Curve All Edges
gets its own level, and each DXF layer becomes a level, so a solid can be
hidden once its edges are pulled off. Hidden levels are not drawn, snapped to,
or chained through. A level with geometry on it cannot be deleted. The main
level, where new geometry goes, always stays shown: make another level main
(double-click it) to hide this one.

### 2D and 3D

The status bar has a **2D/3D** button and a **Z** depth, as a CAD program
keeps them. In 2D everything drawn lands on the Cplane at that depth, snapped
points included: snap to the corner of a solid and the point drops square onto
the Cplane at Z. Curve One Edge and Curve All Edges come flat the same way, so
a block gives its outline once rather than twelve edges. Dynamic keeps to the
Cplane in 2D: only the X and Y arrows, the XY square and the Z ring are
offered. In 3D a snapped point keeps its own depth, the depth is only where
unsnapped clicks land, and Dynamic moves every way. Handles the view sees edge
on are hidden until the view turns. In both, the ball at the middle of the
gnomon drags the selection anywhere, snapping to points. The choice and the
depth are saved with the job.

### Planes

Planes work the way a CAM system keeps them, each set on its own from the
status bar:

- **Gview** is only which way the model is looked at.
- **Cplane** is the plane geometry is drawn on.
- **Tplane** is the plane new toolpaths are programmed in.
- **WCS** is the plane that is the machine's own Top (Top, unless changed).
  Each operation keeps the WCS it was programmed against, as in other CAM software: for
  a second setup (the part flipped), make a new toolpath group, set the WCS and
  Tplane to Bottom, and program it; the first setup's operations stay as they
  were and the group posts with no A move, in the flipped part's coordinates.
  **New Setup, Part Turned Over** on a group's right-click menu does all of
  that at once: a group "..., turned over", and the WCS, Tplane and Cplane
  turned over about the X of the WCS the group was on (Bottom, from Top).
  Chaining an edge off a solid takes the flat face beside it square to the
  Cplane, else the Tplane, else the view, so the Cplane left on a side face
  does not get in the way of picking holes from below.
  A part modelled standing up (the Spacer, the Smash Plate) is programmed
  lying on a face without moving the model: Planes > From Solid Face on the
  face that will be up, then set the Tplane and WCS to it. **Stock Setup**
  then reads and fits the block in the WCS (its margin on the face that is up,
  its sizes as it is clamped; the manager shows it the same way), **Auto
  Drill** and **Auto Pockets** look down the WCS for holes and floors (and
  turn the A axis about the WCS X for its sides), and **Verify** cuts the
  block in the WCS and lays the result back on the model.

The **Planes** tab lists every plane with **C**, **T** and **W** columns;
click in one to move that job to the plane, or right click for Set as Cplane,
Tplane, both, or WCS, and **Edit Origin and Angles**. Any plane's origin can
be moved, typed, picked in the view (it snaps to ends, midpoints and
centres), or put with one click on the stock's top middle, a top corner or its
bottom middle, as the part sits on the machine (where program zero usually
goes). **Move It on the Model (Gnomon)** puts the plane's gnomon in the view:
click its ball (the origin, bright when held) and then a point, an edge or a
face, and the origin goes there; click an arrow and then a point or an edge,
and the plane slides along just that axis to it. So X0 can come from one side
of a part and Y0 from another, past a rounded corner. Enter or a right click
takes it, Esc leaves it. The six standard planes always face the same way, and planes of
your own can be turned about their axes. Clicking the axis triad in the
bottom-left corner of the view is the quick way: it sets the Cplane, Tplane
and Gview together, or only the Cplane, and lists the ways of making a new
plane.

New planes come from the model on the Planes ribbon: **From Solid Face**
(click a flat face; the plane lies on it, facing out, its X along the model's X
where the face allows, else along the face's longest straight edge, so a bar
standing on end lays its length along the machine's X), **From 3 Points**
(origin, along X, and the Y side), **From Geometry** (the plane a selected arc
or flat chain lies in), **From Line Normal** (a selected line is its Z, from
its start), **From View** (square to the screen), and **Rotated
Plane** (turned from one already there).

**Toolpaths run on their Tplane.** Each operation keeps the Tplane it was
made on (its Planes page can change it), and is built in that plane as if it
were Top: draw on the front face of a part and machine it there. Heights are
measured along the Tplane's Z, starting from where the picked geometry sits.

- A Tplane that faces the way the WCS does (Top with its origin moved) moves
  program zero to its origin and nothing turns.
- A Tplane turned about X (Front, Back, Bottom, or Top turned about X) indexes
  the A axis to face it: Front is A90, Back A-90, Bottom half a turn. Program zero
  stays on the rotary centreline, at the WCS origin, where the machine's work
  offset is.
- A Tplane that faces along X (Right, Left) cannot be reached by turning A,
  and an operation on it says so rather than guessing.

The backplot draws each path where it really cuts. Operations made before
planes existed keep running on the machine's Top exactly as before, and a
plane an operation is programmed on cannot be deleted from under it.

## Toolpaths

Every operation is built from geometry and parameters, and rebuilt whenever
either changes; a 2D operation whose own geometry, tool, stock, planes and
settings an edit left alone keeps its moves rather than being built again (a
line drawn elsewhere no longer rebuilds every pocket on the job), while rest
machining and transforms, which read other operations, always are. Picking a
2D operation starts chaining: click each chain it
should machine, click one again to drop it, then Enter or right-click to set
the operation up. Six profiles on a sheet are one operation, not six. Drag a window
while picking to take every chain lying wholly inside it at once. A chain
shows a green arrow where it starts and (open) a red one where it ends,
pointing the way it runs; where a chain meets a branch, arrows show the
ways on to click (see the chaining panel below). A **chaining
panel** sits beside the view while picking: switch it to **Area** and a click
inside a region takes its boundary and the islands directly inside it (what a
pocket wants); switch it to **Partial** to take a piece of a chain: click the
first entity near the end to start from, then the last entity, and the piece
runs between them by the fewest entities, through branches a whole chain stops
at (the first entity shows yellow until the last is clicked); switch it to
**Solid face** to chain straight off a solid: click a flat face square to the
Cplane, and its outline (with its holes as islands) is copied to a "Solid
chains" level and picked. A pocket or dynamic mill chained off floors like
this takes its depth from the lowest floor picked. A contour chained off a solid's top
edge goes down to where that wall ends (a hair through when the wall reaches
the bottom of the stock), on the side the part is not (outside round the part,
inside round a bore or a pocket's wall), across a chamfer or round on the top edge to the wall
below it and past one at its foot (one that faces down, along the part's bottom
edge; not the cone where a counterbore steps down to a smaller hole). It stops
short where any of the part stands beside the loop lower down (the other leg
of an L laid on its side, a round bulging out under a strip), found by cutting
the part across every millimetre down. A contour chained on such a broken edge (the
top or bottom loop of a chamfered part) would run in from the wall by the
break's width, so the walls' own outline is put in and cut instead: the walls
cut across at every height their outline can change and put together (all of
them round the outside, only what they share round a pocket or bore), so a
hole in a wall never notches it and a lower block's chamfer on a stepped part
never pulls it in.
A **Chamfer** chained on the
top loop of a chamfer that is in the model cuts that chamfer as drawn (a
model chamfer): the walls' corner at the top face is the chain, the width is
how far the loop runs in from the walls, the side is worked out (outside round
the part, inside a hole's chamfered or countersunk mouth), and the manager
shows the width and
where the tip goes;
and a hole picked off a solid for drilling, circle,
thread or spot milling brings every other hole of that size in the part with
it, the depth set to where the hole ends (right through when nothing of the
part is under it, even with its far end chamfered) and the top to where the
hole starts, down in a counterbore or on a step (with a feed plane just above
it, so the tool rapids down through the counterbore rather than feeding air). A circle picked at the top of
a chamfered or countersunk mouth is wider than the hole: the hole's own circle
is put in and machined instead, so the wall is not cut away. When the tool the
operation would start with is wider than the hole, the library's best fit is
taken (a drill of the size, or the biggest under it; for milling round, the
biggest end mill with room) and the status bar says so. On a Tplane of its
own (a side of the part) all of this is worked out along that plane's Z, and
the heights start clear of the stock as it stands on that side. **Last** picks again the
chains the previous operation was chained with; Unselect Last, Clear, Done and
Cancel are there too. To change
which chains an operation machines later, double-click its Geometry line in
the manager (or right click it, Edit Geometry): its chains come up picked, to
be dropped or added to. **Set Start Point** on the same menu picks where a closed
contour or chamfer starts (and its lead in goes in): the nearest point on the
path to the click, which snaps.

For a **Contour** or **Chamfer**, each chain picked carries a pink arrow out
of the middle of its first entity: the side the tool will cut on. A closed
chain's side is outside or inside whichever way it runs (Compensation Left is
outside, Right inside: a hole's ID is inside), an open one's left or right of
the way it runs. **Tool side ... (flip)** in the chaining panel turns it to
the other side, and the operation takes the side shown.

The **chaining panel** comes up beside the view whenever chains are picked
for an operation, with what they are being picked for at the top. **Mode**
switches between **Wireframe** (what is drawn in the job) and **Solids**
(chaining straight off the model). Wireframe picks by **Chain**, **Single**
(just the entity clicked, as a chain of its own running from the end nearer
the click), **Partial**, **Point** (a point there already, or the place
clicked, snapped to an end, centre or crossing, made a point; points go to a
drilling or circle milling operation as its holes), **Window**, **Polygon**
(click corners round the chains, then the first corner again, or Enter, to
close it), **Area** and **Vector** (click points along a line, then the last
point again, or Enter, and every chain the line crosses is taken); Solids
picks a solid's edge **Loop**, its **Edges** (a click on an edge chains
along the solid's edges end to end, with the same branch arrows as
wireframe; the edges are copied to the "Solid chains" level while picking,
and only those a chain keeps stay), a **Partial** loop (click the edge the
piece starts on, near the end to start from, then the edge of the same loop
it ends on), a flat **Face**, **Points**, or, with a
click on a flat face, its **Cavities** (every hole and pocket sunk into it,
counter-clockwise: all, only through ones, or only blind), its **Bosses**
(every boss standing on it, clockwise), its outer **Open** edges (where the
part falls away beyond them, clockwise: a top's free edges, a step's open
sides) or its outer **Shared** edges (where the part goes on up beyond them:
a floor against a wall, counter-clockwise). **Ctrl+click** a hole's edge (in
Loop, or Chain with no wireframe there) takes every hole that size, on faces
facing the same way, at any depth, nearest first: a boss's edge, every boss
that size; a pocket's or a slot's edge, every one just like it, however it
is turned (loops already copied to wireframe are used again, not copied on top
of themselves); in Face, every flat face shaped like the one clicked (identical
floors, say), each with its holes. Start, End, Dynamic, Choose and Reverse work on chains picked off a
solid too, and a click on a loop picked already drops it (or, with Choose on,
chooses it); Back, Adjust and Next are for Edges, which branches. Esc drops a
polygon or vector half clicked. **Window** sets what a dragged window or a
polygon picks: chains wholly **inside** it (the default), **inside +
crossing** its edge, **crossing only**, wholly **outside** it, or **outside +
crossing**.
For a hole operation (Drill, Spot Drill, Circle Mill, Thread Mill) a window
also takes the solid's holes whose mouths it holds, facing the way the tool
comes, in either mode: no clicking each hole's edge on a solid model.

A clicked chain runs from the end of the entity nearer the click, and goes
on end to end until it closes, ends, or meets a **branch** (more than one
way on). **3D** (the default) counts everything that meets the chain, so
on a wire box it stops at each corner where an edge goes down: arrows show
the ways on, red the one **Next** takes and blue the others; click an
arrow, or the line itself, to go that way. **Back** steps back an entity,
**Adjust** makes the next way on the red one, **End chain** stops it there.
**Cplane** keeps to the plane of the first entity clicked, so a box's top
chains round in one click. **Shift+click** chains only as far as each next
entity runs on smoothly (within 5 degrees), taking the one smooth way at a
branch: a slot's lines and arcs all the way round, one line of a zigzag.
**Dynamic** (the toggle beside them) puts the start anywhere along the
chain picked last: an arrow follows the cursor along the chain (green where
the start would go, red the end), and a click or Enter puts it there; or
press on the start or end arrow and drag it (or click it, and it rides
along with the cursor to the next click). Over a snap point off the chain
(an end, a middle, a centre), the arrow goes to the point of the chain
nearest it. Esc leaves the chain as it was. A closed chain then starts
there (the operation's start point, so the cut and its lead in go in
there); an open one is broken there and starts there, or, past its middle
(or with its end arrow dragged), ends there. Dynamic turns itself off once
the arrow is put down. The start and the end move on or back an entity
with the four buttons under them. **Wait** (beside End chain) is for
Partial: with it on, a piece once picked waits, and each entity clicked
after takes it on from its end to that entity, by the fewest entities and
back over its own where that is the way, until End chain. A T chained along
its bar, back to the middle and down its stem is cut in one go without
lifting; with the tool to one side it rolls round the end where the chain
turns back and comes back along the other side, and an operation that would
cut across the chain where it turns (the far side of the T's stem) says so
and is not made. A picked chain shows thick yellow to
orange, with a green arrow where it starts and (open) a red one where it
ends, both pointing the way it runs; a closed chain shows only its start
arrow. **Reverse** runs the chains the other way (with the tool on the
line, and for engraving, that is the way it cuts). **Choose** (beside
Dynamic): while it is on, a click on a picked chain makes it the one Start,
End, Dynamic, Reverse and Unselect work on (it shows light blue), so the
third chain of a window pick can be turned round on its own. **Last**, **Unselect**
and **Clear** pick the last operation's chains again, drop the last chain,
or drop them all. **Similar** (Chain Similar) picks every other chain in
the drawing shaped like the one picked last, however it is turned or
wherever it is, each running the same way round from the matching corner:
identical ones, or the same shape at any size and mirror images too, as
Options says. The panel counts what is picked, and **OK** (or Enter, or a
right click in the view) sets the operation up.

**Options** (the gear at the panel's foot) is the Chaining Options:
**masks** (only lines, arcs or splines; only some levels or colours: the
rest are passed by as if not there, for this session), which chains a
window or polygon takes (**every chain**, **closed only** or **open only**,
and a **section angle**: a sharper turn ends a chain), the order chains
taken together go in (**next closest** from where the window was begun, or
**inside to outside**, **outside to inside**; open chains **one way**, each
from its end nearer where the last began, or **zigzag**, nearer where the
last ended), **reverse inner chains** (a chain inside another runs the
other way round to it), **area: everything inside the boundary** (islands'
islands too), which way **closed chains run** (counter-clockwise by
default, seen down the Cplane's Z; a clicked one runs from where it is
clicked unless that is turned off, or at a point entity lying on it when
**Start at a point** is ticked), what **Chain Similar** takes (identical or any size, mirror images, only on
the sample's level or in its colour), **ignore
depths** (in 3D: ends join where they meet seen down the Cplane's Z, whatever
their depths; lines standing straight up are passed by, and the chain is laid
flat at the depth of the end it starts from, as copies on the Flat chains
level where it is not flat already), and the
**chaining** and **plane tolerances**. All but the masks are kept between
sessions.

**Chaining straight off a solid**, the way solid chaining works in other CAM software:
while picking chains, a click on an edge of a solid where there is no
wireframe takes the loop that edge belongs to, the outline or a hole of the
flat face square to the Cplane beside it. No silhouette to make first. An
edge with no such face beside it (the edge of a chamfered top, a wall) takes
the flat loop running nearest it seen from above, which round a chamfered top
is the outline under the chamfer, the part's full size. The loop is copied to
wireframe on the Solid chains level, so the operation keeps it.

### 2D

| Key | Operation |
|---|---|
| K | Contour, with outside/inside compensation, lead in/out, holding tabs, climb or conventional (or, on the line, the chain run either way), and **Ramp** (sink continuously round a closed profile, one lap a step down, then a level lap at the bottom: no step marks on the wall) |
| P | Pocket: rings from the centre out (constant overlap spiral: rings that would leave floor standing, down the middle of a narrow pocket or out in the corners at a big stepover, are closed up until they do not, with a note), zigzag rows, one-way rows, or a true spiral (one continuous cut that eases out from ring to ring, no step-overs; rings where the pocket splits), or high speed (the roughing rings' corners rounded so the tool sweeps round them; kept sharp, with a note, in a corner too tight to round without leaving floor), or a morph spiral (inside the first roughing ring, rings that change a little at a time from its shape to the pocket's spine, the line down its middle, so each is one loop and none is left as a little loop in a corner or on the far side of a neck, joined from the middle out into one continuous spiral as a true spiral is (a ring too unlike the next is cut as a ring): a dumbbell pocket that rings from the wall cut with five lifts was cut with one and less travel; round islands too, the rings coming in from the walls and out from the islands alike, cut as rings there rather than one spiral). **Trochoidal loops** (any method; off, where the tool would be buried, or all along the roughing): small loops, each a little on from the last, where a roughing cut would take more than its stepover at once (rings from the middle out start with a slot the tool's width), only where they fit inside the roughing, never in the finish stock or by a wall; loop radius (a quarter of the tool) and spacing (half that) can be set. In a 60 x 20 pocket the tool went buried for 54 mm of its cut instead of 224 (what is left: each loop run's first move in, and the outer rings' corners by the walls), for about three times the travel |
| Shift+Y | Dynamic Mill: constant small bite at full depth |
| Shift+F | Facing, at any angle, one way or zigzag |
| Shift+P | Peel Mill: trochoidal loops along a slot, full depth, thin bite |
| Shift+L | Slot Mill: down the middle of an obround slot, then out to each wall |
| Shift+N | Blend Mill: passes that morph from one picked chain into another |
| E | Engrave on the line |
| Shift+V | V Carve: letters and shapes, deeper where they are wider, with a V bit |
| Shift+H | Photo V Carve: a picture carved as lines of varying depth |
| Shift+C | Chamfer with a V bit, from a width and tip offset |
| D | Drill every hole of the picked diameter (or only the holes picked), nearest next, with pecking and dwell |
| Shift+S | Spot Drill: sink a cone in the top of every hole, to centre or countersink it |
| Shift+B | Circle Mill: helix down every bore of that diameter, from the middle out when it is wide |
| Shift+T | Thread Mill: one helical lap cuts a whole thread, internal or external |
| Ctrl+Shift+M | Manual Entry: your own G-code, posted where the operation sits |

### 3D and rotary

| Key | Operation |
|---|---|
| Ctrl+Shift+1 | Surface Rough: z-level roughing over the visible solids |
| Ctrl+Shift+2 | Parallel Finish: parallel passes along the surface |
| Ctrl+Shift+3 | Waterline: constant-Z passes round the part |
| Ctrl+Shift+Y | Hybrid Finish: waterline on the walls, parallel on the flats |
| Ctrl+Shift+4 | Scallop Finish: passes spaced evenly along the surface |
| Ctrl+Shift+5 | Pencil Finish: traces the corners where the ball touches two faces at once |
| Ctrl+Shift+7 | Project: follow a picked chain over whatever shape is under it |
| Ctrl+Shift+8 | Radial Finish: passes out from the middle like spokes |
| Ctrl+Shift+9 | Spiral Finish: one pass winding from the middle out to the rim |
| Ctrl+Shift+H | Horizontal Area: every flat floor of the model facing up, pocketed at its own height (plus any floor stock), highest first. Before a floor's passes are kept, every point of every cut is checked against the model with the real cutter shape; a floor the tool cannot reach without touching something, such as one under an overhang, is left out and the operation says which. |
| Ctrl+Shift+0 | Rotary Rough: come in a step at a time from the surface of the bar |
| Ctrl+Shift+6 | Rotary Finish: the part turns under the tool, which follows its shape |
| Ctrl+Shift+F | Flowline: passes that follow the picked surfaces' own directions |

### Running the program

| Key | Command |
|---|---|
| Ctrl+B | Backplot player |
| Ctrl+R | Regenerate all |
| Ctrl+Shift+V | Verify: cut the program into the stock |
| Ctrl+P | Post to a grblHAL `.nc` file |

### What the operations do

**Several chains in one operation** are cut one after another, and how they
lie inside each other counts the way the material does: a chain inside an odd
number of the others picked (a letter's counter, a window in a plate) is an
island to a pocket, dynamic mill or V carve rather than a shape cut on its
own, and a profile or chamfer cuts it on the other side from the rest, out of
the material between them (the manager says how many it turned round). A
pocket or dynamic mill whose tool cannot get into one of its shapes cuts the
others and says how many it left.

**Facing** rows run at whatever angle is asked for, so the cut can follow the
long way of a part that is not square to the table; they run off each end by
the tool's radius and however much more you want. One-way facing keeps every
row cutting the same way round, lifting to come back, which is an even finish
for more time; **one pass** runs once down the middle of a face no wider than
the cutter. **Move between cuts** joins zigzag rows the way other CAM software does: a
**high speed loop** (a half circle out past the end of the row, at depth, so
the cutter never stops dead or lifts), **linear** (straight across at depth),
or **rapid** (up, over and down), with a feed of its own for the links. The
boundary picked is taken as the stock, as other CAM software takes it. The **across
overlap** is how far the cutter reaches past the sides (half the tool puts its
centre on the edge), the **along overlap** how far past the ends once clear,
both as a distance or a share of the tool; rows are spread evenly so the last
overhangs the far side exactly as the first does, and the **approach start
distance** and **exit end distance** run the first row on before it and the
last one off after it. With nothing picked, Facing faces the whole top of the
stock block, down to the top of the part.

**Dynamic Mill** clears with a constant bite at full depth (worked out from the
operation's own heights, in equal steps only where the flutes do not reach;
Auto Pockets does the same, from the faced top). The material still
standing is kept on a fine grid, and at every step the tool turns until the
sliver it takes is the stepover, no more: it spirals out from a helix entry,
follows the edge of what is left, and when a pass runs out of material the
next starts from ground already cleared, linked at depth where the way there
is clear. Parts of the pocket nothing reaches from where it is are opened with
a helix of their own. A pass round the walls at size finishes. Cut again on an
independent grid, a 60 mm square pocket's heaviest millimetre was 1.5 times the
stepover (at the last corner of the wall pass), against more than five times
for a plain pocket. A pass never doubles back on itself while some way within
120 degrees of straight on still bites: beside a wall that is what keeps it
running along the last strip in one go instead of shuttling across it a hair at
a time (on a test core, turns that double back went from 1 in 8 to 1 in 900).
**Minimum toolpath radius** (Cut Parameters, Dynamic Mill and dynamic 3D
roughing) is the tightest a pass may turn while it cuts, at the tool centre:
each step turns no more than that radius allows, and where a pass would have
to turn sharper (doubling back at a wall, into a corner) it ends there and the
next starts afresh, so the machine never has to stop for a hairpin at full
depth. In a 40 x 30 pocket with a 6 mm tool, a radius of half the tool made
190 shorter passes where there were 12, with the sharpest cutting turn 4.6
degrees a step (from 170), 7% more time by the plain estimate (which ignores
the slowing hairpins cost the machine), and the same left in the pocket for
the wall pass.

After the machining regions are picked, Dynamic Mill asks for the rest the way
other CAM software's **chain options** do. **Avoidance regions** are closed chains the
tool keeps out of, machined round wherever they lie; **air regions** are
openings inside the machining region that are cut already, so nothing is cut
there and the tool comes down through them instead of spiralling in. An
**entry point** (a point picked with the regions by the chaining panel's
**Point**, or with **Select...** in the chain options) is where the first helix
goes in, at a pre-drilled hole say: centred on it, or as near it as a helix as
big as anywhere else would have fits, never squeezed into a corner. Where
there is no room to spiral down anywhere (a slot barely wider than the tool)
it takes a **profile entry**: the wall pass ramps in along its own
shape at the ramp angle (by the distance really travelled, so never steeper
round a corner), lap after lap, no more than the entry pitch a lap. Where the
dynamic passes left a patch they could not get into, the wall pass ramps in
the same way rather than plunging into it. The
machining region is cut **Stay inside** (like a pocket) or **From outside**:
taken as the stock, with the tool coming down beyond it and working in, round
the avoidance regions, which is how a core is roughed with the stock as the
machining region and the part as the avoidance region. Each wall pass climbs
round the wall it follows, the boundary's or an island's. Pick nothing for the
machining region and it is the **stock block**, cut from outside: pick the
part's silhouette as the avoidance region and that is a core roughed. An
avoidance region or island drawn at another height (a silhouette lies at the
part's bottom) is brought onto the machining region's plane, and a closed chain
inside an island (a hole through the part) is left alone with it rather than
machined. Programming the owner's Mount 4 this way, the post's model check found
both (the part cut 0.5 in into, and its holes milled); both are fixed and the
same program now posts clean.

**Skip pockets smaller than** (Roughing page, Pocket and Dynamic Mill): a
pocket with no room anywhere for a circle that wide (islands left standing) is
left out, for a smaller tool to do later. Picked with others, the rest are cut
and a note says how many were left; picked alone, the operation is refused
with the reason. Open pockets, the stock block and dynamic cuts from outside
are never skipped.

Between passes across ground already cleared, the tool rides a **micro lift**
(0.01 in off the floor to start with) at a **back feed rate** of its own, so it
does not rub the floor on its way, and it can **lift right out** for any move
longer than twice the tool. The same goes for dynamic 3D roughing.
The **first pass feed** slows the first lap round each helix entry, where the
tool goes from the entry hole into full engagement, to a share of the feed.
Where a step has to take more than the stepover (into a corner, along a last
sliver), the feed comes down in step with how much more (never below 40%,
in twentieths so the F word does not change on every line), keeping the load
on the cutter even; it can be switched off. Cut **from outside**, an **approach
distance** starts the first cut of each depth that much further
out along its own line, clear of the stock, so the tool is up to feed before
it meets it (only as far out as the tool may go, so never into an avoidance
region). The **cut order** says where each new pass starts once
one runs out of material: **nearest the tool** (air, the shortest moves
between passes), **smallest pieces near it first** (material: when what is
left has come apart, the scraps by the tool are finished before it moves on,
so it does not come back for them) or **as found** (none).

**V Carve** cuts letters and shapes the way a chisel would: the further the cut
is from the edge of the shape, the deeper it goes, so the corners come out
sharp and the groove tapers. The tip of a cone `t` in from an edge has to sit
`t / tan(half angle)` down for the flank of the bit to touch that edge exactly,
so the path is the shape itself at the surface, then the shape offset inwards
a little and cut a little deeper, and so on until the offsets close up in the
middle. Counters inside a letter are carved into rather than machined round.
If the shape is wider than the bit can reach, or deeper than the depth set for
the operation, it says so and holds the bottom flat. **Clear the flat bottom
with** a flat end mill (a flat-bottomed carve, the way sign makers cut wide
letters): on making the carve, a pocket with that tool goes in before it, kept
off the walls by the depth times the tangent of half the V angle, and the V bit
then cuts only the walls and the corners at the bottom the flat tool cannot
reach. Change the carve's depth later and the pocket's stock to leave wants
changing with it.

**Photo V Carve** (Shift+H) carves a picture. Choose any image file (a phone
photo is fine; colour does not matter, only how dark each part is) and place
it on the job by its corner and width. Lines run across it at the spacing and
angle you set, and the V bit sinks deeper, so cuts wider, where the picture is
darker: from the depth on white down to the operation's depth on black. From a
step back the grooves read as the picture. Contrast (gamma) keeps the light
tones cleaner, and Invert carves the light parts instead, for dark material.
The picture is kept inside the job, so the file travels on its own. Where the
darkest grooves would be wider than the line spacing it says so, because they
run together into flat dark hollows. The **Dots** style carves it as a
halftone instead: the V plunged at points the spacing apart (every other row
half a spacing on), each cone as wide as the picture is dark there and none
on white, the tool hopping just over the top from one to the next.

**Slot Mill** machines an obround slot the way the shape asks for: down the
middle first, where there is always room to ramp in, then out to each wall in
turn on a racetrack round the centreline. It cuts along the slot instead of
sweeping across it the way a pocket would, and the last pass on each side is
exactly on size. It checks the chain really is a slot — two straight sides and
a half circle of the same size at each end — and says what it found if it is
not: a plain circle is sent to Circle Mill instead.
**Finish passes** take the last of the wall at the bottom: the roughing
racetracks stop that much short of it, and the finish passes step out to size
at the final depth.

**Blend Mill** machines the ground between two chains with passes that start as
the first and end as the second, each a little further across than the last. It
is for the web between two edges that are neither parallel nor the same shape —
a tapering slot, the ground between two curves — where a pocket would cut across
the shape instead of along it. Pick both chains: the one to start at and the
one to end at. A chain drawn the other way round is turned to match rather than
left to twist the blend into a bow tie. It cuts between the chains, not to
them, so leave stock on and finish the edges themselves.

**Point** (the point toolpath, beside the hole operations) takes the
tool through points picked with the chaining panel's **Point**, in the order
clicked, from the clearance height and back up to it: rapid to the first and
feed on to the rest, all at rapid, or all at feed. It is for getting round a
clamp or parking the spindle out of the way (before a manual tool change on
Grbl, say), and its moves are checked against the model like any other.

**Thread Mill** cuts a thread with a helical lap round the hole or the boss:
one cutter does every thread of its pitch in any diameter that will take it.
Give it the pitch; the depth of the form follows from it unless you set your
own. Which way it runs is not a free choice, so it is worked out rather than
asked: the hand of the thread fixes the handedness of the helix and climb
milling fixes which way round the hole the tool travels, and between them they
decide whether the cut starts at the bottom and climbs or starts at the top and
descends. It comes down the middle of a drilled hole, or well outside a boss,
and arcs onto the thread rather than being driven at it. Roughing passes work
out to size, with a spring pass if you want one, and every circle of that
diameter on a visible level is threaded, the way drilling takes every hole.
The rest of the usual thread mill options are there too: **active teeth** (a
multi-tooth cutter, its tip the lowest tooth, climbs only far enough for the
top tooth to reach the top, though always a whole turn), a **start angle**
(where round the hole it goes in), an **allowance** (overcut: an internal
thread opened, an external one closed, by that much on the radius), and
**Cut** top to bottom or bottom to top when you would rather choose the way
along it and let climb or conventional follow (the note says which).

**Tapered threads** (pipe threads for air fittings: NPT, NPTF and BSPT taper
1 in 16 on the diameter, 1.7899 degrees a side): give the taper and the circle
picked is the thread's size at the top; the path draws in by the taper going
down a tapped hole, or out going down a male end, and the form defaults to a
pipe thread's 0.8 of the pitch. An arc cannot change its radius on the way
round, so a tapered helix is written as short straight moves within the
tolerance (a 1/8 NPT port, 27 a inch, cuts 10.24 mm across at the top and
0.625 mm smaller 10 mm down).

A **standard thread** can be picked from a list instead of typing the pitch:
UNC and UNF from #4-40 to 1/2", metric coarse M3 to M12, and NPT from 1/16"
to 1/2". It fills in the pitch (and the taper for pipe threads) and shows the
major diameter and the usual tap drill.

**Spot Drill** sinks a cone into the top of every hole of the picked size: a
dimple to stop a long drill wandering, or a countersink for a screw. Give it
the width across the top and the depth follows from the angle of the tool —
a 90 degree tool sinks half that width, a 60 degree one further. Left at zero
it spots the hole to its own size. A spot wider than the tool is refused, and
so is a cutter with no point on it.

**Manual Entry** is an operation that is nothing but lines you type: a stop for
an inspection, a probe cycle, a machine command GarageCAM does not write
itself. They are posted exactly as typed, where the operation sits in the list,
with no tool change or spindle command wrapped round them — and since nothing
in them is read, they are not back-plotted and not cut in Verify. The operation
says so itself.

**NC Program** (Home tab, Import > NC) brings in a G-code program from
anywhere — gSender macros, another CAM system, one written by hand — as an
operation. It is read back into moves (G0 to G3 with centres or R, in XY or,
as the lead arcs other CAM software puts on a facing pass often are, in XZ
or YZ (G18, G19), G4, G20 and G21, G90 and G91, feeds, and the G73, G81, G82,
G83, G85 and G89 drilling cycles), so it
back-plots, and Verify cuts it into the stock and compares it with the part like
anything made here: a way to prove an old program before running it. It posts
exactly as it came in, and afterwards the program states its own units and
modes again and calls the next tool whatever it is. Anything it cannot place
(moves in machine coordinates, a B axis) is listed as a
warning, never guessed at. A move in X and Y made before any Z is known (at
the start, or straight after a tool change sends Z home) is drawn at the
height the program next takes Z to, or the highest it has been if that is
higher, not dragged across the stock at Z0.

A program that turns the part on the 4th axis (A words, or the letter the
job's post uses) comes back the way GarageCAM draws its own wrapped and
indexed work: every point turned about X with the part (Z measured from the
axis), the tool leaning out from the axis as the part has turned under it,
and a move that turns as it goes followed round the axis in steps a couple
of microns from the true curve, so it back-plots round the bar and Verify
cuts it on every side. A machine set Reversed reads it turning the other
way, as it posts. Its feeds are what the control makes of them: degrees
beside millimetres (or inches) as grblHAL times them, or G93's inverse time.
Where it sends Z home before turning (G28 Z, or G53 Z), the tool is taken
up 50 mm over the highest the program goes to anywhere, so the part's corners
swinging round under it are not shown as a rapid through the stock. The
editor's tool marker leans with it. A program GarageCAM posted reads back
cutting exactly what its operations do: on the owner's parts, Rotary Rough
and Finish posted and read back remove the same to within a few cubic
millimetres in hundreds of thousands.

A program with tool changes comes in as one operation
per tool, each run with the job's tool of that number (asked for when the job
has none), so Verify cuts each stretch with the right cutter; a program with one
tool asks which tool it runs with.

**Transform** (Ctrl+Shift+T, Toolpaths tab) is an operation made of copies of
others: tick the operations above it to copy (they must share a tool and a
Tplane), then place the copies in a **grid** (places and spacing along X and
Y), **round a point** (places, the angle between them, or spread evenly), as
a **mirror image** in a line along X or Y, or **indexed round the A axis**: the
same moves cut again with the part turned, for flats or slots spaced round a
bar. A grid can put **each copy on its own work offset** (G55, G56, ... after
the original's G54): one vise or fixture to a place, every copy posted in the
original's own coordinates on its offset, while the backplot and Verify still
lay them out at the spacing given (more copies than G59 allows is refused).
Each indexed copy is posted as an operation of its own (up to clearance,
`G0 A…`, then the moves), and the backplot and rotary verify show every copy
where it lands on the part. A program that indexed A ends with A back at 0
(after Z is home), so the next one starts square. The originals still cut where they
are; the transform adds only the copies, which follow their sources whenever
those are rebuilt — change the pocket and every copy changes with it. Each
operation keeps an id of its own, so reordering the list does not lose what a
transform copies (though a transform must stay below its sources). A mirror
image cuts the other way round, so climb milling becomes conventional; the
operation warns about it.

### Getting in and out

A pocket enters on a helix rather than plunging, at its own ramp angle. Where
there is no room to spiral — a ring round an island, or a slot barely wider
than the tool — it ramps down along the pass instead, and only plunges if
helical entry is switched off. Where an offset level splits into separate
islands, each island gets its own entry and is cut in full. Closed chains
standing inside the boundary are machined round, not through. Once down, a
pocket stays down: each ring runs on from the one beside it at the feed when
the step across keeps inside the wall pass and clear of every island, and a
level's rings are taken nearest first, so a plain pocket goes in once per
depth (a test pocket went from 57 rapids to 5).

**Island facing** is for islands lower than the top of the pocket: give the
height their tops stand at, and above it the whole pocket is cleared, islands
and all, facing their tops; below it the pocket goes round them to the depth.

The **Entry** page has the rest of the usual entry motion: **helix**,
**ramp** along the pass or **plunge**; the largest and smallest helix radius;
what to do where no helix fits (ramp, plunge, or leave it uncut and say so);
a **Z clearance**, so each entry starts that far above the cut so far rather
than at it; and an entry feed rate of its own. A **tapered helix** narrows to
a quarter of its radius on the way down (as other CAM software does, 95% of the tool
at the top to 25% at the bottom), never steeper than the ramp angle, then opens
back out to the full radius at the bottom with a light bite each half turn; the
**entry pitch** caps how far it drops in one turn; and a **dwell before the
cut** waits at the bottom for the spindle. Dynamic Mill's Entry page has the
same taper, pitch, feed and dwell for its helixes.

The **cutting method** (Roughing page) is the usual set: **constant overlap
spiral** (the rings), **zigzag** or **one way**, with rows at the **roughing
angle**. Rows run inside the boundary the roughing stops at, split round
islands; zigzag runs on into the next row at depth wherever the step across
stays inside, one way lifts and comes back. A row started fresh ramps in along
itself at the ramp angle. A ring at the roughing boundary then cleans up what
the row ends left, and the finish passes follow. On a test pocket round an
island, zigzag and one way at 0 and 30 degrees all cleared the floor without
touching the island or the walls; zigzag took 29 rapids to one way's 69.

An operation keeps the chains it was made on, and a pocket the islands it
found: geometry drawn later that touches a chain (a copy of the outline) or
stands on the floor (text to engrave) does not change the cut. A chain is
walked again from where it was picked only once one of its entities has been
trimmed or deleted, and islands are looked for afresh when one of them has, so
a redrawn boss is never lost. A drill working every hole of the picked size
keeps the holes there were: a circle of that size drawn later is not drilled
until the holes are picked again. **Edit Geometry** picks them anew.

A contour with no lead-in **ramps down along the path** rather than plunging on
it, at the ramp angle given.

**Leads** can be an arc, a straight run square to the cut, or both. The arc
arrives tangent to the path so the tool is already moving the right way when it
touches the work; the straight part before it keeps the entry mark off the part
altogether, and on its own it is a square lead in. A closed profile can also
**overlap**: carry on past where it started before it leaves, so the mark the
tool made going in is cut away going round.

The **Holding tabs** stand up from the final depth to their height, and every
pass below their top goes over them, so a tab taller than a stepdown keeps its
full height. The tool stays up for the tab's width plus its own diameter, so the
tab that is left is as wide as asked (round a test profile, four 5 mm tabs left
20.05 mm of tab). Tabs can be **ramped** over at an angle instead of stepped
straight up and down, and given a **maximum spacing**, which adds tabs to a long
profile where the number asked for would leave them too far apart.

Every pass of a profile puts its tabs at the same places: roughing and
finishing side passes, and tapered levels, are each a different length, so
their tabs are kept to the points where the pass at size puts them, and every
tab reaches from the part right out to the stock. (Spread by each pass's own
length, the tabs on an outer pass used to land somewhere else, leaving nothing
holding the part.) A ramp down to depth stops short of the first tab instead
of cutting it off from above.

Tabs can go **at points picked** instead of being spread evenly: Pick
points... on the Tabs page, click where they go, then Enter, and each tab goes
where the profile passes nearest to a point (on every pass, side passes and
levels alike). **Which shapes** limits tabs to shapes no bigger than a size
across X and Y: the small parts that would come loose, not the big ones held
down anyway.

**Enter on the first depth cut only** and **exit on the last depth cut only**
put one lead in at the top and one lead out at the bottom: round a closed
profile the tool stays down between depths and ramps along the path into each
one after the first.

**Plunge after the first move** runs the lead in's line above the work and
goes down at the start of its arc; **retract before the last move** comes up
at the end of the lead out's arc and runs its line above the work.

A first contour in a job starts with leads the usual way: a tangent
line and a quarter arc in and out, each the tool's diameter; later contours take
the last one's. The **Lead In/Out** page sets the entry and the exit side by side, the way
other CAM software does. Each has a line, **perpendicular** (square to the cut) or
**tangent** (along it), with a length in distance or as a share of the tool and
a **ramp height**; an arc with its radius, **sweep** (how far round it turns
onto the cut) and **helix height**; and the **start or end of the contour
adjusted**, carried on straight past its end or stopped short. Ramp and helix
heights start the line and the arc above the cut, so the tool comes down along
them rather than plunging, and climbs back up them going out. Over both:
enter and exit at the **midpoint** of closed contours, a **gouge check** that
draws a lead in (and says so) until no point of it comes closer to the part than
the cut itself, overlap, and a feed of its own for the leads.

Drilling pecks either with a full retract each time, which clears a deep hole,
or with a chip break that stays down. The **first peck** can be its own size,
the **peck clearance** sets how far above the last bottom a full-retract peck
rapids back down to, and the **chip break retract** how far a chip break backs
off. The **bore / ream** cycle feeds back out
as well as in, so a reamer or boring bar does not rapid up the finished wall.
Going right through can **allow for the
point of the drill**: the end of a drill is a cone, so the hole is only full
size once the point is that much further down. Tick it and the depth grows by
the length of the point plus however much you want through the far side, and
the operation says what it worked out.

Holes are taken **nearest next**, **as found**, or in a pattern the way
other CAM software sorts them: **rows** (along X) or **columns** (along Y), zigzag or
all one way, starting from the corner nearest the hole picked first, or
**round their centre** from the hole picked (a bolt circle). Drilling, spot
drilling, circle milling and thread milling all sort the same way.

Leads, compensation side and cut direction are all decided from the part's
own geometry, not from the order OCCT happens to store an offset in; tests
sample every move, leads included, and check the cutter never enters the
part. With M3, climb runs clockwise round an outside profile and
counter-clockwise round a pocket.

### Finishing to size

A contour, a chamfer or a pocket can take **finishing passes**: so many, so far
apart. Roughing then stops back by however much they will take, so the last
pass is a light cut at size rather than the same cut again. A contour can leave
them to the final depth, which is what a wall cut in several steps usually
wants; a pocket finishes its wall on every depth, because its rings are cut
that way anyway.

A contour can also take **roughing passes** (Side Passes page): so many, so far
apart, out beyond the main pass and cut before it, outermost first and each
down through every depth, to clear a wide band round a profile. Spacing wider
than the tool is called out, since it leaves rings standing.
The **pass order** can instead be **by depth**: at each depth every roughing
pass and then the main one (and the finish passes, when they are taken at
every depth), before going down, so the side load stays one spacing at one
step down. **Direction: zigzag** cuts the passes of an open chain back and
forth, climb then conventional, with no run back to the start between them;
a closed chain is left one way, as it ends where it began.

The **Depth Cuts** page sets the **depth cut order** for an operation on more
than one chain: **by contour** (each chain down to full depth in turn) or **by
depth** (every chain at one depth before any goes deeper, so a sheet of parts
is never left with one cut right through while the rest are still held), and
**keep tool down**: a closed contour with leads goes from its lead out straight
on to the next depth's lead in at the feed, wherever that crossing stays as far
from the part as the cut does, instead of lifting between depths.

**Tapered walls** (Depth Cuts page, contour): each depth cut is set further out
by how far it is below the top, so the wall leans by the taper angle with the
part wider at the bottom. A flat end mill leaves the slope as small steps
standing outside it; nothing is cut into it.

The Cut Parameters page has a **contour type** list, the way other CAM software's
contour has: 2D, 2D chamfer (the chamfer operation), ramp, remachining (rest
machining), oscillate and **dynamic**. It sets the same options found elsewhere
on the pages, and follows them when they are changed there. **Dynamic** (a
dynamic contour) takes the band of stock standing beside the wall (**wall stock
to remove**) off with the dynamic engine: a light, even cut at full depth (as
far as the flutes reach), round the outside of a part coming in from beyond
the band and keeping off the part, inside a bore or pocket from the open
middle; then the wall is cut at size. No tabs: it clears the wall, it does not
cut the part free.

The **Cut Parameters** page also has **roll cutter around corners** set to
**All**, **Sharp** (only corners sharper than 135 degrees are rolled; gentler
ones are cut to a point, the way they are drawn) or **None**, and **tip comp**:
the depth is where the **tip** goes, or where the **centre** of a ball or
corner radius goes (the tip that much lower).

Two **corner radii** sit with them (closed chains). The **internal corner
rounding radius** rounds the path where it turns into the material, so the
tool is never buried in a corner; the corner is left for a smaller tool, and
the path is never nearer the part than before. The **external corner break
radius** takes the part's outside corners off to that radius as the cutter
rolls round them. If breaking would take away more than the corners (a rib
narrower than twice the radius), the operation refuses rather than cutting it.

**Oscillate** (Depth Cuts page, contour): the tool rides up and down along
each depth cut, **linear** or **smooth**, from the depth up by the oscillate
distance and back once every wavelength, so the whole length of the flutes
does the work instead of one band. The wavelength is evened out so a whole
number of waves goes round and each pass ends back at its depth; a level lap
at the bottom takes off the crests, so the floor comes out flat. Passes that
ride over tabs stay level.

**Onion skin** (Depth Cuts page, contour; for sheet work on a
router): every part in the operation is cut down to a thin skin short of the
bottom, so the sheet still holds them while the heavy cutting goes on, then
each is cut free on a last pass at size through the skin, at a feed of its own
if one is given.

The **Tolerance** page has an **arc filter** for every operation that cuts
along a path: posted as the post options say, **off** (straight lines only),
or **at the operation's own tolerance**, with a **smallest** and **largest arc
radius**; arcs outside them stay as lines.

Below it, **arc feed** (contour, pocket, circle and slot milling) adjusts the
feed on every arc so the edge of the cutter, not its centre, moves at the
programmed feed: slower round an inside curve, by no more than the percentage
given, and faster round an outside one only as far as allowed (none unless
set). A 10 mm tool in a 30 mm bore runs at two thirds of the feed at the wall.

A new operation starts from **the last one of its kind in the job**, the way
other CAM software does: its cut parameters, heights, leads, tabs and the rest, so a
second pocket is set up like the first. What it was cut on, its chain
direction, and the plane and work offset of the setup being programmed are
not carried over. A job opened again remembers the same way, from its own
operations. In a job with none of its kind yet, it starts from **your
defaults** when there are some: **Save as Defaults** in the operation dialog
keeps its settings for that kind in any job (a usual tool, stepover, leads,
finish passes), and **Forget Defaults** goes back to GarageCAM's own. Heights
set as absolute Z belong to the part they were set on, so the new part's own
stand; incremental ones come along.

**Circle Mill** takes a **start angle** (where round the bore it goes in) and
**finish passes**: the roughing rings stop that much short of the wall, and
each finish pass at the bottom goes down through the middle, out onto the wall
on a half circle so it meets it going along it, once round, and back on a half
circle. A **circle diameter** mills a bore that size at points
picked with the chaining panel's **Point** (twice the tool to start), or in
place of the size of the circles picked.

**Edit Geometry** on a Dynamic Mill re-picks its machining chains and then
opens its **chain options** again, with its avoidance and air regions and
strategy as they were, to change them before it is rebuilt.

**Pocket finish passes at the final depth only** (Side Passes page): above
the bottom the cut stops at the roughing wall, and the finish rings take the
whole wall in one cut at the bottom.

A pocket can be **split into a roughing and a finishing operation**
(an additional finish operation, Side Passes page): tick **Make an
additional finish operation** and on OK the pocket cuts only its roughing,
stopping the finish allowance short of the walls, and a copy cutting only the
finish passes (and spring passes) goes right after it, ready to be given the
finishing tool. **This operation cuts** (all of it, the roughing only, or the
finish passes only) says which part any pocket takes.

A **finish feed rate** (Side Passes page) runs the finish and spring passes of
a contour or a pocket at a feed of their own, the chip load a light cut wants,
leaving the roughing at the cutting feed. **Lead arcs on and off** (pockets)
brings each finish pass onto the wall and off it on a quarter arc from the
cleared side, tangent to it, so the start leaves no mark; where an arc would
come nearer a wall than cutting at size does, that pass goes straight on as
before.

**Thin wall** finish passes (Side Passes page): each depth is
roughed first, then its finish passes are taken down to it from the depth
before in the number of steps given, so a thin wall never stands tall against
a heavy finishing cut. Between steps the tool comes in off the wall to the
roughing wall's loop (cleared below), changes height there and links back
out, never plunging onto the finish ring. Not with finish passes at the final
depth only.

Every operation can **run its tool at its own feeds**: feed rate, plunge rate
and spindle speed, each left at zero to take the tool library's number. The
same cutter can rough hard and finish gently without being entered twice, and
what the operation carries is what gets posted.

Its **Tool Manager...** button opens the tool manager to make a new tool or
change one, and comes back to the operation where it was.
The Tool page shows the **feed per tooth** and the **surface speed** (SFM, or
m/min in millimetres) beside the feed and spindle speed, worked out from the
tool's flutes and diameter. Change the feed per tooth and the feed follows;
change the surface speed and the spindle speed follows, the chip load held.
**Fit the feed to the material** (Tool page, any mill operation cut from
above): the operation is walked through the stock as the operations before it
leave it, a short piece at a time (half the tool), and each piece gets the
feed that takes material as fast as the operation's usual cut (the median of
its pieces, width times depth): slower into a slot or a corner, faster in a
light cut or through air, never under **never slower than** (40%) nor over
**never faster than** (125%; 100% only ever slows it), nor faster than the
job's machine goes along X and Y ($110 and $111, when known). Plunges, ramps and
helixes keep their feeds, and the moves go exactly where they went (pieces
left at the same feed are one move again). It needs the stock set up, and an
operation with it is built again whenever one before it changes. A 60 x 40
pocket alone: its slot down the middle and its corners slowed, 133 s instead
of 123; the same pocket after a bigger cutter roughed it, mostly faster, 108 s
instead of 123; every fitted feed in the posted program, fitted in 17 ms.

**Spring passes** (Side Passes, contour) go round again at size after the
finish passes, taking off what the cutter sprang away from; a pocket's spring
passes go round its walls again at the bottom. With several chains,
**finish after roughing all contours** roughs every chain first and then goes
back round them all with the finish and spring passes. The **finish depth
cuts** can run at a **feed of their own** (Depth Cuts page). Rest machining can
work out what is left from **all the operations before** or **only the one just
before**, the way remachining usually asks, or (contour and pocket) from
**a roughing tool of a given diameter**: what that tool would have left cutting
the same operation, the corners it could not reach, with no earlier operation
needed.

**Rest roughing across planes** (3+2): a Surface Rough on a Tplane, or after
work done from another side, reads what is left from a Verify of every side
(the earlier operations cut into the stock as it stands in the model, leaning
and turned as they were) looked at along its own plane, where the stock need
not be square: rough the top, then rest rough from the front or from a plane
leaning 45 degrees, and each cuts only what the top left. Seen from a side,
what is left can be a skin standing in front of a hollow, so each level cuts
only material in its own stepdown, and the part's own walls (and the stock
left on them) are never taken for material. The test suite roughs a block's
rebated edge from the top and rest roughs it from the front (422 mm of cutting
where roughing again is 3738) and from 45 degrees (737 against 21093),
nowhere in the part.

**3+2 Rough** (Toolpaths, 5-Axis) is a Surface Rough from several planes in
turn, as one operation: tick the planes on its **Planes** page (the order is
the priority; Up and Down move them). Each is roughed as an operation on that
Tplane would be, taking only what the operations before it and the planes
above it left; its heights come from where the stock stands facing it, the
retract and clearance as far above it as the Heights page has them above the
top. The post, Verify, the backplot and the machine simulation get it as an
operation on each plane, the machine turned to face each one. It needs a stock
block. The test suite roughs a block's rebate from Top and a slot under it
from the Front: the Front's share cuts 900 mm where roughing from it alone
cuts 4216, and the whole verifies on every side nowhere in the part, both
cleared.

**Find Planes** (on the same page) finds them on the part: the WCS's top first,
then each time the direction the machine can face (no further from the top
than *Tilt up to*, tried every so many degrees) that reaches the most of the
part's surface none before it reached, until another would add under a
hundredth of it or there are *at most* planes. A point of the surface is
reached from a direction when it faces that way (a wall along it counts, as
the side of the cutter takes it) and nothing of the part stands over it; what
the part stands on is left out. Planes the job lacks are made (3+2 Plane 1,
2...), and all are ticked in the order found, saying how much the top alone
reached, how much they all do, and how much nothing the machine can face can.
On the test block it finds the top and then the Front (the top reaches 92%,
with the Front all of it); a block with only a pocket in its top gets the top
alone.

### Cutting only what is needed

Any operation can be told to **cut only what earlier operations left**. It
simulates them against the stock block first, the same way Verify does, and
keeps only the stretches where something the cutter would touch is still
standing: run the same pocket again with a small tool and it cleans the corners
the big one could not reach instead of cutting the whole pocket a second time.
It ramps into each stretch along the path, from just above the material that is
really there rather than from the top of the block, and says how much cutting
is left out of how much there was. Stretches too short to ramp into are
plunged, and it says that too. Roughing in 3D does the same thing a level at a
time, so a smaller tool cleans the corners a big one could not reach.

Any operation can also be **limited to a boundary**. Select a closed chain
before starting a 3D operation and it machines only what falls inside it: the
pocket in the middle of a plate and nothing else. Keep what is outside instead
and it is what steers a path round the clamps. **Tool containment** says where
the tool may go against it: its centre on the boundary, the whole tool kept on
the kept side, or its centre reaching a radius past it, with an **additional
offset** on top. Roughing ramps
into each stretch it keeps; a finishing pass comes straight down onto the
model, which is where it was already resting.

### Doing it more than once

Any operation can be **repeated**: so many copies, each moved in X and Y or
turned about the origin. A sheet of the same part is one operation.

Any operation can also be **mirrored**, about a line across X, up Y, or both,
which is how the opposite-hand part gets cut without drawing it twice:
duplicate the operation in the manager and mirror the copy. Reflecting a path
turns it inside out, so the arcs are turned round with it and the operation
says plainly that a climb cut has become a conventional one. Mirrored both
ways is a half turn, which changes neither.

Each operation can run in a **work offset of its own** (G54 to G59), or in
whatever the program starts in. Two of the same part in two vices is one
program with two offsets; the post writes each change once, where it belongs.

### 3D

3D operations machine every solid and surface on a visible level. They drop a
model of the cutter onto a triangle mesh of the part, so a flat and a ball mill
leave what they really would. Stock to leave is held by growing the cutter and
lifting the tip by the same amount, which keeps the allowance even on a wall as
well as a floor. **On floors** (under *On walls*) can leave a different amount
on floors: the cutter is grown by the walls' amount and its tip lifted by the
floors', so a floor keeps exactly the one, a vertical wall the other and a
slope something between (on a test pocket: 0.5 on the walls with 0.2 or 0.8 on
the floor, and a ball leaving 0.3 and 0.1). It reads *The same as on walls*
until set. Roughing clears the whole stock block when one is defined, not
just the part's footprint, and ramps into each level instead of plunging. After
the rows at each level it **goes round the walls** there, so the stock left
for finishing is an even skin rather than the steps the rows stop in (on by
default; a test part shows less than a third of the proud stock beside a boss).
Between rows it stays down and steps across at the feed when nothing of the
part is in the way, and with a stock block it leaves out rows that only graze
the outside of the block, so a level is usually one ramp in rather than one
per row. **Step-up passes** (off to start) add levels that far apart between
the stepdowns, cutting only the terraces the stepdown left on gentle slopes:
on a 15° test ramp the tallest terrace went from 2.35 mm to 1.05 mm with
0.5 mm step-ups (the rest is the flat end mill's own wedge on the slope).
**Cut on each flat floor** adds a pass at the height of every flat face of the
model big enough to matter, plus the stock on floors, cutting only what the
stepdown below it does not reach. Without it a floor between two stepdowns
keeps up to a stepdown of stock (2.5 mm on a test pocket with a 2.5 mm
stepdown); with it, the stock asked. On for new roughing operations, in rows
and dynamic alike.
**Cut each pocket to the bottom before the next** (rows only, off to start)
takes a part with separate pockets one pocket at a time, all the way down,
instead of every pocket at each level before the next level down. A pocket's
lower levels are cut only once the levels over them are, its walls right after
each of its levels, so the tool never bites deeper than a stepdown. On a test
tray with three pockets the tool went between pockets twice instead of 34
times, taking off the same material.

**Dynamic roughing** (Roughing: Dynamic) clears each level with the same
constant light bite as a Dynamic Mill, at full depth, instead of rows that bury
the whole cutter wherever they meet a wall. At each level the tool may stand
wherever the cutter clears the model, and what it cuts is the stock wherever
the part's own top is below the level. It comes down outside the block and
works in from the side where it can, helixes in where it cannot, stays down
between passes when the way is clear, and finishes each level round the walls.
Step-ups come after the level below them, so only the terraces are left for
them. Use a small stepover (10 to 20 %; choosing Dynamic drops a rows-sized
stepover to 15 %) and a deep stepdown. On a test boss it held the bite under
twice the stepover at every level and took off as much as rows do.

Sampling adapts: where two samples disagree by more than the tolerance the path
is refined between them, so a steep wall cannot be stepped over. Waterline
finds each crossing by bisection rather than interpolating a height map, which
is what keeps it off the walls. Measured on test parts: a ball mill stays
within 0.003 mm of a sphere, waterline within 0.001 mm of a vertical wall, and
roughing leaves exactly the allowance asked for. Waterline passes **climb** by
default (clockwise round a boss, anticlockwise round a cavity); untick Climb
milling for conventional. Wherever a ring joined point to point would cut
inside a bend (round a sharp outside corner a ring is an arc of the cutter's
radius, and its chords cut the corner), a point is put in out at the true
crossing; before, every such chord was a few thousandths into the wall and had
to be lifted over the top of the part (1080 lifts on a test boss, now none).
Spiral and scallop passes are refined between their points the way parallel
passes are, and the model check uses a cutter a hair smaller than the real one,
so a pass running exactly tangent to a wall is not taken for a gouge: every 3D
finish round a test boss now needs no cut lifted at all.

**Z limits** (3D finishing) cut only between a highest and a lowest Z. The
moves are kept as built and cut short only where they cross a limit, and each
piece is joined to the next up at the retract.
Surface Rough takes them too: its levels run only between them, the first
stepping down from the top limit, with everything above it taken as cut
already (said so, so it is checked in Verify).

**Slope limits** split a part between two finishes, the usual steep-and-shallow
pair: give Parallel finishing *Cut slopes up to* 45° and Waterline *Cut slopes
from* 45°, and the parallel passes stay on the flats and gentle slopes while the
waterline rings only the walls. The slope is measured from the cutter's own
height map, so it is the slope the tool sees. Passes broken by a limit are
joined over the surface only when the hop is short and itself inside the
limits; otherwise the tool lifts.

**Waterline levels**: **cut from the bottom up**, and **add cuts on shallow
areas**: where a gentle slope leaves one level's loops further out than the
**largest gap** from the level above, a level is added halfway between, and
again, down to the **smallest stepdown** (on a 14 degree cone with 1 mm
steps, the widest band went from 4 mm to 1 mm). **Each feature all the way
down before the next**: the loops of a boss or a hole, level under level,
are cut top to bottom before the tool goes on to the nearest next one, and
where features meet lower down (two bosses standing on one plate) the loops
round both are cut after both. On two bosses on a plate the rapids across
went from 260 mm to 62 mm, the cut the same. **Add a level on each flat
floor** (Waterline and Hybrid; on for new ones) puts a level just over every flat
face the tool rests on, plus the stock on floors, so the foot of each wall
standing on it is traced whatever the stepdown: on a boss standing on a plate
between two stepdowns the stepdowns alone never reached its foot, and the
added level runs all the way round it. Undersides and floors too narrow for
the tool get none, and nor does a floor a level already runs just over.

**Pocket spiral from the outside in** (Roughing page, constant overlap
spiral): the rings are cut from the roughing wall in, the finish rings still
last, and the helix goes down just inside the outer ring rather than in the
middle, so there is no full-depth slot out to it.

**Gaps** (Cut Parameters, 3D finishing): a gap between one cut and the next no
wider than the **gap size** is crossed with the tool kept down instead of
lifting to the retract height, either **following the surface** or **up to the
higher end, across and down**. Waterline always goes up, across and down, so a
loop never follows the surface off its level down a wall; a crossing that
would run into the model lifts as usual. Each closed loop starts at its point
nearest where the tool finished the level above, so going down a level is a
short step and the seams line up; with **Ramp down to the next level along the
loop**, the step is a ramp down along the loop at the ramp angle instead of
straight down, and the ramped stretch is cut again at the level at the end, so
no mark is left where it steps.

**Hybrid Finish** is that pair in one operation: everything at least as steep
as *Waterline on walls steeper than* (45° to start) gets waterline passes at
the stepdown, and everything flatter gets parallel passes at the stepover. The
walls are cut first, top down, then the flats, so the parallel passes run up
to walls that are already finished.

Parallel passes run at any **pass angle**: 0° along X, 90° along Y, or across
the part at 45° so they never run straight along a feature's edge. Turned
passes are clipped back to the area, so they never run out past the part.
**Zigzag** links each pass to the next along the surface; **one way** lifts
back and cuts every pass in the same direction, so the cutter climbs (or
conventional cuts) the same way across the whole part.

**Rest finishing**: tick Rest machining on Parallel, Waterline or Hybrid
Finish and it goes only where the operations before it, cut into the stock
the way Verify cuts it, left material more than *Rest: material thicker than*
proud of the model (0.05 mm to start). Finish with a big ball, then rest
finish with a small one: on a test pocket the small ball cut a third of what
finishing everything again would, and took the big ball's fillets in the
floor corners down to its own. It needs a stock block, like rest roughing. On
a Tplane, or after work from another side, it reads what is left the way rest
roughing across planes does, looked at along its own plane: rest finishing
from the front after a rough from the top goes over the rebate the rough left
and not the face it never touched (1488 mm of cutting where finishing
everywhere is 3312), and from 45 degrees, where the block is not square to the
plane, 1776 against 4601.

A **bull nose** is a tool type of its own: give it a corner radius in the Tool
Manager and 3D operations drop the real shape — flat under the middle, rolled
round the corner — so it leaves what it really would, and Verify cuts the stock
with the same shape. No corner is a flat mill and a full corner is a ball, and
both come out of the same maths.

A **tapered ball mill** is one too, for 3D carving: its diameter is the ball at
the tip and its angle the included angle of the taper (twice the angle each
side), widening up the flute length. 3D operations drop the ball and the cone
above it (the cone held inside a stack of thin discs a hundredth of a millimetre
proud of it, so it can only ever stand off), Verify and the model check cut
with its true shape, and the backplot draws it. 2D operations refuse it: its
sides lean out and would cut the walls.

A **corner rounding mill** (a roundover bit) rounds edges over, a cutting
board's say. In the Tool Manager its diameter is the full width above the round
and its corner radius the round it cuts; the pilot at the tip is the diameter
less twice the radius. Pick it in a **Chamfer**: the pilot rides the wall
(the tool's centre the pilot's radius off the chain, outside or inside) and
the round goes the width down it, all of the tool's round for a full round over
or less for the top of one; wider than the round is refused, and the tip offset
(a V bit's) is not used, since any lower its shoulder would cut a step into the
top. Both Verifies, the model check and the backplot cut and draw its real
shape, hollow round and all; tilted on a plane, where the verify's rays cross
it slantwise and can go in at the pilot, out of the round and in again at the
shoulder, it is the same stack of cones through its profile whichever way a ray
runs. A Fusion library's radius mill reads in as one. 3D operations do not take
it. The test rounds a plate's outline over from outside and a hole's rim from
inside with a 1/2 inch, 1/8 radius bit: cut, it is the plate with those edges
filleted 1/8 in the model to 0.003 mm, verified on every side and from above,
and the same on the plate tilted 30 degrees and cut on its own plane.

**Scallop Finish** spaces its passes evenly along the surface rather than in
plan, so the ridge left between them is the same height on a wall as it is on a
floor. The spacing is measured with a distance field grown out from the
boundary, so the passes follow the shape of the part instead of one fixed
direction.

**Stepover by scallop height.** Parallel, Scallop, Radial, Spiral, Flowline,
Hybrid and rotary finishing can space their passes by the ridge they leave
instead of by a distance: set *Or by scallop height* under the stepover and
the passes go as far apart as leaves ridges that high on a level floor. A ball
of radius R steps 2√(h(2R − h)); a bull nose steps its flat end plus the same
chord of its corner. The dialog shows the spacing that comes to with the tool
picked, and the operation notes it when built. A flat end mill leaves no
ridges to set, so it keeps the stepover given. Up a steep wall parallel-style
passes are further apart along the surface, so the ridges there stand higher;
Scallop finishing, spaced along the surface, keeps them as low up a slope as
on top.

**Pencil Finish** runs the corners where the ball touches two faces at once —
the line a fillet would sit on. It is what cleans out the internal corners a
finishing pass rides over, and it is usually the last operation on a mould.
A corner is wherever the ground the ball rests on folds sharply up beside it
(the ball starting up a wall), not only at the bottom of a valley: a drilled
hole's point meeting its side, and a counterbore whose floor is narrower than
the ball (the hole through it lets the ball down a hair beside the corner).

**Radial Finish** lays its passes out from the middle of the part like the
spokes of a wheel, which is how anything turned about a point is finished — a
dish, a knob, a round lid — because the passes then run the way the shape does
instead of across it. Spokes crowd together near the middle and open out at the
rim, so the stepover is their spacing at the rim, where it is worst, and the
operation says as much. **Spiral Finish** covers the same ground in one pass
that winds out from the middle without ever lifting, so nothing is left where a
pass ends: nothing ends until the whole of it does.

**Flowline** finishes surfaces along their own lines: select them (or a
solid, whose largest face is taken), and the passes run the way each surface
was built — along a swept or lofted shape, round a fillet, down a blade —
rather than straight across it in plan. Surfaces that meet edge to edge are
followed as one: a round-over all round a board, which comes as straight runs
and corners, is cut with each pass a loop round the lot, stepping down to the
next without lifting. *Passes run* picks which way they go (for several, along
the run of them or across it); *Start from* puts the first pass at the top
edge (cutting from the top down) or the bottom; *Cutting* is zigzag, one
way, or a **spiral**: round surfaces that close on themselves (a round-over
all round a board) one continuous cut, a whole loop at the first pass, then
each loop easing across to the next as it goes round, then a whole loop at
the last, so there is no step down (and no mark) where each loop would start
(a board's round-over: 10 turns, never more than 0.2 mm down between points,
the ball a radius off all eight faces); and passes along a wall climb cut it unless *Reverse* is ticked. The
tool sits where it touches the surface at each point followed (a ball's
centre a radius out along the surface's normal), so the passes keep the same
spacing down steep parts too; the stepover is measured where they are
farthest apart, so nowhere is left wider than asked, and the whole cutter is
kept off every surface showing. The *Surfaces* page has the surfaces followed
(*Select...* picks them again in the view: click them, then Enter) and
**surfaces to avoid**, which the tool keeps off by the distance given (on top
of the stock to leave), lifting over them. Every 3D finish has surfaces to
avoid on its *Surfaces* page (Parallel, Waterline, Scallop, Radial, Spiral,
Flowline, Project and the rest; not the rotary ones): pick a clamp, a tab or
a face that is already finished, and the passes ride over it that far off
instead of cutting it. The test suite runs each of the first five over a
floor marked to avoid and checks none comes nearer it than asked.

**Every 3D path is checked against the model before it is kept.** Each
straight cutting move is walked along its length, a tenth of the cutter's
radius at a time, with the real cutter shape; where it would dip into the
model between the points the tool was placed at (a pass crossing the corner of
a part, say), points are added so it rides over instead, and the operation
says how many were lifted. The test suite cuts a filleted, pocketed part with
every 3D path and verifies each against the model for gouges. (Project is
allowed exactly the depth it was asked to cut into its surface and no more;
the rotary paths are checked by rotary verify.)

**No rapid moves on a slant**, in any operation: one that rises goes straight
up first, one that falls goes across first, so every rapid crosses at the
higher of its two heights. A second test cuts a plate with facing, pocket,
dynamic mill, contour, drilling and circle milling, and verifies each against
the part for gouges and for rapids through material. An operation whose
geometry makes the modelling kernel fail comes back as one that could not be
built, with the reason, rather than taking the program down.

**Project** takes a flat chain and follows it over the model: a name on a
curved handle, or a groove that follows a dome. The chain is walked in XY and
the cutter dropped at each step, so the path rides the surface the way a
finishing pass does. Stock to leave holds it off the surface, and a negative
number sinks it in — -0.3 engraves three tenths deep. A chain that misses the
model altogether is refused rather than dragged along the floor.

Tools carry what is **above the cutting edge** as well: the flute length, the
shank diameter and the holder. The drop cutter keeps the cutter itself off the
part, but nothing else on the tool is kept off by the maths, and on a deep
pocket or a narrow slot it is the shank or the collet that actually hits. Every
operation is checked against the visible model and says how far in the shank or
the holder would be, and where. A 6 mm cutter on a 12 mm shank will not go down
an 8 mm slot, and it says so before the tool finds out.

### Stock and verify

The **File** button opens the File page over the whole window: **Info** (the
job at a glance), New, **Open** (browse, or the recent jobs), Save, Save As,
**Save Some** (only the selected geometry, as a job of its own), **Import**
(with **Merge**: another job's geometry brought in onto levels of the same
name), **Settings** (machine, post options, units), **Help** and Exit. The
arrow at the top, or Esc, goes back to the job.

The manager lays a job out as a CAM system does: the **Machine Group**, its
**Properties** (Machine, Post, Tool Settings and Stock Setup, each opened with a
double-click), the geometry, and the **toolpath groups** holding the operations with their
total time. A group is a setup: flip the part, and the operations for the back
go in a group of their own. Right-click a group to **post it on its own** (with
its own setup sheet), write its **Setup Sheet** on its own (opened in the
browser, to check or print before posting), rename it, make it the one new operations go into, or
start a new one; right-click an operation to move it to another group. Post
G-code on the ribbon still posts the whole job.

The **insert arrow** in the tree marks where the next new operation goes. Right-click
an operation and choose **Insert New Operations Below This** (or Above) to put
new work in the middle of a program; several made in a row stay in order and
the arrow moves on past each. Right-click the arrow to move it up, down or to
the end. A rest operation put in there only counts what is above it, and rest
operations further down are built again to count it.
Operations can also be **dragged** to a new place in the list (several at once
when they are picked together): dropped on an operation they go before it in
the top half of its line and after it in the bottom half, and dropped on a
group they go to its end, into that group.

The row of buttons over the list works on what is picked in it, as well as
regenerate, backplot, verify and post: **select all operations**, **show / hide**
(or **show only**) and **post / skip** the selected ones, **lock / unlock** them (a locked operation
is kept as it is, not built again when geometry or tools change, and its
parameters cannot be edited until it is unlocked, so a long 3D path stays put),
and move the **insert arrow** down, up, or to just below the selected operation.
**Alt+T** shows or hides every toolpath. What is picked in the list stays picked
while it is worked on.

**Edit Common Parameters** (right-click one or more operations) changes the
same things on all of them at once: tick the clearance, retract, feed plane,
top of stock, depth, stock to leave on walls or floors, coolant, feed, plunge
or spindle speed, give the value, and each operation is built again with it.
**Chain Manager** (right-click an operation) lists its chains in the order they
are cut (the one chosen in the list shows selected in the view): cut one
earlier or later, remove one, turn one round (**Reverse**: an
open chain then cuts on its other side), or go to Edit Geometry to add or
re-pick.
**Copy** and **Paste** (Ctrl+C, Ctrl+V in the manager, or right-click) copy
operations to the clipboard and put them in at the insert arrow, in this job or
another GarageCAM; pasted into a job without their chains, they say so and
take new geometry with Edit Geometry. Their tools go with them: in a job where
the same number is another cutter, they go onto that job's own tool of the
same kind and size, or the tool is added under a free number (the status bar
says which), never onto whatever that job keeps under the number.
**Export to an Operations Library...** (right-click) saves the operations
picked, with their tools, to a .gcops file; **Import from an Operations
Library...** (right-click, or Toolpaths > Import Ops) brings them into any job
the same way, ready for their geometry: a set of operations proven on one
part, reused on the next.
An operation's right-click menu is laid out like an operations manager's: its
own edits (parameters, geometry, chains), **Edit Selected Operations** (common
parameters, tool, feeds, cut direction, name, start point), **Groups**, the
clipboard, **Insert Arrow and Order**, **Display** (backplot, Expand All,
Collapse All down to one line an operation), posting and lock.
Right-click a group to **sort its operations by tool** (fewer tool changes,
otherwise in the order they were), and operations to **recalculate feeds and
speeds** from the tool library, clearing their own numbers. **Renumber Tools**
(on the group menu) numbers the job's tools from a start by an increment in
the order the operations first use them, so the changer rack loads in order.
**Work Offset...** (on the group menu) puts every operation of a setup on one
work offset: two vises on the table, the first setup on G54 and the part
turned over on G55, posted as one program; the setup sheet says which.
**Make Start Holes** (right-click operations) drills a hole wherever the
selected operations feed down into the part after a rapid, as deep as they go,
so a cutter that should not plunge goes down a hole instead. It offers the
smallest drill in the library at least as wide as the widest cutter, puts the
points on a "Start holes" level and the drilling in before the first of them.

**Stock Setup** (Toolpaths tab, or Stock Setup under Properties) defines the
block: corner to corner, by its size, or **Size from**: **From Model** fits it
round the visible geometry with a margin, **From Selected** round what was
selected (a rectangle drawn for the block, say), and **Pick Corners...** steps
aside for two opposite corners to be clicked in the view (they snap to ends,
middles and centres and the model's corners), the block being the box between
them (two at one height keep the thickness, the top at that height). It is
drawn as an outline or as a see-through solid.

**Solid model** stock is a solid of any shape: a casting, a plate with holes
already in it, a part cut in an earlier setup. Choose one of the job's solids:
its own shape is the stock, drawn as it is, and Verify (and rest machining)
starts from it, nothing over its holes and its own underside under it; the box
round it sets the top of stock and bounds roughing as a block's does. It is
taken out of the model unless asked not to, so it is never mistaken for the
part, and it is kept in the job.
The block is drawn in the viewport, sets the default top of stock for new
operations (or, once a facing operation has taken the top down, the faced
height), bounds 3D roughing, and any operation whose retract sits inside it
is refused.

**Round stock** is the other kind: a bar on the rotary, lying along machine X
on the A axis centreline, which is where the post puts it when it wraps a path.
Give it a diameter and the two ends. A block's rules do not apply to it —
nothing is measured down from a table top — so top of stock, the retract check
and roughing bounds all leave it alone.

**Verify** cuts the whole program into the block and shows what is left, as a
solid: the cut top, the walls and the floor (or the bar with its ends capped),
standing in for the stock while it shows. It
reports the volume removed and the lowest point cut; with a model loaded it
also reports the worst gouge into the part and how much material is left on it,
and colours the block by it: **red** where the cut went into the part, **green**
where it is on the part to a thousandth of an inch, **blue** where material is
left on (darker the more there is, up to 2 mm), and plain stock colour where no
part is under it. Material left standing inside the part's outline, such as in a
hole drilled undersize, counts as left on. The part shows as wireframe while
the block is up, so the two do not fight where their faces meet.
A rapid that would run into material still standing is reported as a crash —
material already cut away is not, so peck drilling back down its own hole is
fine. A long straight feed is swept exactly, the whole shape of the cutter's
end carried along the line, rather than stamped in at steps; that is exact
and, with a big cutter, many times quicker (a rest finish after a full 3D
program on the tallest owner part went from three minutes to six seconds).

The block is seen from above and from below, so it holds what is cut straight
down and straight up: an operation on a Tplane that only moves program zero
(or turns it on the table) is cut where it really is, and one on a plane facing
straight down, the part turned over for its **second setup** (WCS and Tplane
Bottom), cuts the block's underside, so both setups verify together: the
counterbores from below meet the holes from above, a hole cut through from
either side is open, and the underside is compared with the part as well. One
indexed round the A axis onto a side (a Tplane turned about X to a side, or a
typed index angle) comes at the block from the side.

**Verify on every side.** A program with operations that come at the block
from the side (3+2 on a trunnion, a Tplane turned onto a side) or lean the
tool (5-axis) is verified on every side instead: the block is held as runs of
material along rays in X, Y and Z, every cutter is taken out of each ray it
crosses, leaning as the program leans it, and the cut surface is drawn from
those runs. Side grooves, undercuts and walls leaning over what is under them
show as they are, and the comparison with the part is measured exactly where
the rays cross the cut surface: red into the part, green on it, blue left on.
A rapid that runs into material on any side is a crash, and the block can be
watched being cut as the backplot plays. A solid stock, and the part it is
compared with, are cast onto the rays watertight: where a ray lands on the
edge two of the model's triangles share, it crosses there once, never none
(each triangle once worked out its own sums, a ray on a shared edge could be
missed by both, and the rest of that ray came out inside out: the owner's
cutting board read 9.8 mm into itself before anything had cut it).

**Machine simulation** (tick **Machine** in the backplot): the AltMill is drawn
round the work and moves with the tool as the program plays: the gantry
along Y on its side plates, the X carriage along the beam, the spindle head
up and down, with the tool and its holder under the nose. The built-in
AltMill is its main parts as the machine's own model measures them, coloured
as the machine is: the table's crossbeams, Y extrusions, end plates and
motors and the spoilboard; the gantry's side plates, beam, rails, ballscrew
and motor; the X carriage on its four blocks with the Z axis plate, rails and
motor; the Z carriage on its blocks with an 80 mm spindle in its clamp mount,
bolted low on the plate. With a tool changer it has the changer's spindle
instead (a square body under a tall black cover, flat on the Z plate) and the
racks across the back of the table, six holders to a rack standing in their
forks (drawn close enough from the maker's pictures, so not checked
against). The moving parts are see-through so the cut shows
beneath them. The work sits in the middle
of the spoilboard; a job on the rotary sits on a rotary there (headstock and
chuck at one end of the bar, tailstock at the other), and the whole machine
turns with the part on screen, the way the tool comes at it. Ticking it runs
the whole program on the machine first, a few millimetres at a time, and
lists anything that would run into something: the gantry beam or the
carriage into stock too tall to pass under, the head, the tool or its holder
into a clamp (the solids on workholding levels), the chuck or the headstock,
the head down into the spoilboard (a tilting head lying over low, say: the
tool itself may cut into it, as a through cut does),
each with the operation and the time into the program, to play the backplot
to and see it. A machine other than an AltMill is drawn as a gantry router
sized from its definition's travels ($130 to $132). The machine definition can
set the work somewhere else on the table (Work at X and Y, from the middle of
the spoilboard).

**Your own machine model**: Machine Definitions, Simulation model, **Load
Model...** reads the machine's own CAD (STEP, IGES or STL: the maker's model
or your own) and lists its parts by their assemblies, saying which axes each
one travels along: still (the **frame**), Y (the **gantry**), X and Y (the
**carriage** along it), all three (the **head**), or any other mix for a
machine built another way. A mill whose table moves the work ticks the axes
the table moves in: its table then travels X and Y, the saddle Y, the head Z
and the column stays still, and the simulation keeps the work still and
moves the rest of the machine round it, so the column is checked against
tall work as it comes at it. It guesses from the assemblies and names (a Z axis assembly
rides with Z but for the plate and rails it rides on; the plate and bearing
blocks along the gantry go with X; the bearings and nuts under the gantry in
the Y axis's own assembly go with the gantry), and an assembly's choice sets
everything in it. Screws and anything smaller than the size given are left
out, and so are the electronics, controller, VFD, e-stop, sensors and
levelling feet (choose any back in). Which axis is up in the model can be
said. The spindle nose and the middle of the spoilboard's top are found (a
part called a spoilboard, or the biggest thin board on the frame), and a
model without a spindle (machine CAD often comes without one) has one drawn
in, bolted to the front of the Z plate: a round one in a clamp mount, or the
tool changer's spindle when the machine has a changer, its size up to you
(changing which guesses the nose again). A machine with a tool changer can
have its racks drawn in too, across the spoilboard's middle with the pockets
at the Y given (first guessed under the nose, right when the model has the
gantry at the back as machines are usually drawn); a model with racks of its
own leaves that unticked. While the list is open the view shows the model
coloured by what moves each part, and what is drawn in as it will look. The
model is
kept with the definition as light meshes, read at once; every part kept is
checked for collisions against the work and clamps by its own outline, and
the machine's frame never counts (its moving parts ride on it). **Built-in**
goes back to the plain one.

Verify also **plays**: the same cut is stepped through in time, so the block
opens up under the tool as the program runs, at whatever point on the timeline
the backplot slider is sitting. Right-click the graphics while it shows for
**Save Verify Result as STL...**: the cut block as a mesh (millimetres, as STL
files are read), to look at in another program or keep with the job.

**Verify on round stock** cuts the wrapped operations into the bar instead. The
flat height map cannot do this: on the rotary the same piece of surface comes
round under the tool again and again, and depth is measured out from the
centreline. So the bar is held as a map of radius over X and A — exactly what
the post writes — and the cut is reported as how much came off, how far in the
deepest cut went, and how far the A axis turned in total. A rapid that would
drive the tool through material still standing is reported the same way it is
on a block. Operations that are not wrapped are cut too, with the bar indexed
to their A angle (from their Tplane, a typed index, or none) and held still: the
cutter comes straight down its own Z, and each piece of the bar's surface in
reach is cut in along its radius for as far as it lies inside the cutter. A
groove from Front lands on the side that faced the spindle, not on top. A
5-axis operation's tool leans the way it does on the machine, and the rapids
of operations that are not wrapped are checked against the bar too. When the
job also comes at the bar from the side (an index to a Tplane, 5-axis), it is
verified on every side instead, the wrapped operations rolled round the bar as
A turns the part, so a cross hole or a pocket's straight walls show as they
are.

### Rotary

Any operation can be **indexed**: give it an A angle and the post turns the
part there — lifting to clearance first — before the operation runs, then leaves
it at that angle for any operation that follows at the same one. The geometry is
programmed flat, the way the face presents once it is turned. The backplot draws
it where it will really be.

**Other machine layouts (3+1, 3+2).** **Rotary axes** in Machine Definitions
sets how the machine turns the part:

- 3 axes;
- a 4th axis along X (A, as the AltMill's Vortex) or along Y (B);
- a trunnion table, A or B tilting with C turning on it;
- the head-table and head-head 5-axis layouts.

Each axis has limits and can be reversed. An operation on a turned Tplane is
cut with the part turned by the table's axes to face the spindle:

- on a 4th along Y, B turns for a plane square to Y;
- on a trunnion, both axes turn together for any plane they can reach, a
  plane leaning two ways included (`G0 A-54.7356 C-45`).

Of the ways to get there, GarageCAM takes the one that turns least, inside
the limits; a plane past the limits is refused, saying so. The program's zero
is where the rotary axes cross. Z goes home before turning, and every axis
turns back to 0 for an operation on Top and at the end.

**Auto Drill** finds holes on every side the job's machine can turn up:

- on a 4th along X, the sides square to X, as it always has;
- on a trunnion, the ends of a block too (`B90 C0`), each side on a plane of
  its own named by its angles.

A side past the rotaries' limits (the underside on most trunnions) is left
out, or offered as a second setup with the part turned over.

**3+2 by the control.** Tick **3+2: the control tilts the work plane
(G68.2)** in Post Options, and an operation on a turned plane is written in
the plane's own coordinates. The control is told the plane (`G68.2 X Y Z I J
K`, `G53.1`, and `G69` after) and turns its own rotaries, so tilting-head
machines work too. Without it, a plane only a tilting head can face is
refused.

The AltMill's A along X works exactly as before. Nobody has run the other
layouts on a real machine yet, so their programs are posted with **Not Proven
Yet** (see [docs/MACHINE-DEFINITIONS.md](docs/MACHINE-DEFINITIONS.md)).

**5-axis simultaneous** (Toolpaths > 5-Axis) tilts the tool as it cuts:

- **Swarf** cuts a drafted or twisted wall with the side of the tool, leaning
  along the wall between its top and foot chains. Instead, pick the wall's
  face (Solids, Face): its outline is split at its four corners, and the
  higher side is the top.
- **Curve 5-Axis** runs the tip along a chain on the part, square to the
  solid under it, leaning forward if asked. Pick several chains (lettering on
  a curved face) and it does each in turn, in and out along the tool, with a
  rapid between: straight across where that stays out of the part, and out
  and round it (a cylinder about X, or a sphere round the work, the tool
  pointing out) where it would not, as between chains on opposite sides.

Both check the shank and holder where the lean puts them as they are built.

Swarf's side is worked out from the solids showing unless you set it: the
tool goes on the side away from the part. **Wall in bands up to** cuts a wall
taller than the flutes in bands, the top one first, the tip raised up the
tool for each, so the flutes do all the cutting. **Side passes** step in from
the stock to the wall a **side step** apart, the outermost first, so the tool
isn't taking the whole width at once. A wall with ends is come
at along its line from past its start and left past its end. A wall all the
way round (a drafted boss) is ramped into over a first lap from its top, then
cut once more round at depth. Swarf also warns:

- when the tool is in the part (it is on the wrong side of the wall);
- when the wall (or a band of it) is taller than the flutes, so the shank
  would rub.

Each point gets the machine's rotary angles:

- the way that turns least, inside the limits;
- an endless C carrying on past 180 instead of winding back;
- C left where it was when its angle makes no difference;
- big swings cut into 2 degree steps.

**Holes at any angle in one Drill.** Tick **Each hole along its own axis**
(Drill, Holes) and pick the holes' circles, whichever way they face: each is
drilled with the tool along its axis, the heights taken from its mouth along
the axis as they are from the top of stock in Z, and a hole found in the
solids goes to its own depth (out of whichever end is open). Between holes
the tool goes straight out, round a safe cylinder about X (when every hole is
square to X, so an A rotary turns the part: radial holes on the Vortex in one
operation) or a sphere round the stock, pointing out all the way, and back
in. Holes square to X are drilled in order round the bar; otherwise each
next hole is the one facing nearest the way the last one did.

**Any 3D toolpath can be cut 5-axis.** Its parameters have a **Tool Axis
Control** page: set **Output format** to 5-axis and choose how the tool
leans:

- to the cutting direction, by a lead angle and a side tilt;
- away from a point, or towards one;
- along a fixed direction;
- from the surface's normal where the ball touches the part, by a lead
  angle and a side tilt measured from that normal, so the ball cuts off its
  centre the same on a steep wall as on a flat. A move touching nothing (a
  link, a lift) takes the lean of the cut next to it;
- upright, tilted only where the holder would hit: wherever the shank and
  holder clear the work the tool stays upright, and where they would not it
  tilts just far enough to clear (up to the most lean allowed), whichever way
  clears, eased in before and out after at no more than 2 degrees a
  millimetre so the rotaries swing smoothly. A short tool can then finish
  beside a tall wall its holder would otherwise hit.

**Most lean from upright** caps the lean. **Lean round X only** takes out
any lean along X, for a machine whose one rotary is an A along X (the
AltMill's Vortex), which turns the part instead: 4-axis. It needs a ball
end mill. The ball's centre stays exactly where the 3-axis path put it, so
the ball touches the part just where it did, whatever the lean. It then cuts
off its tip instead of its dead centre, and the holder leans away from steep
walls. Wherever the lean asked for would put the flutes, the shank or the
holder into the part, anywhere along a move, the tool leans less there,
round the ball's centre along the same heading, just far enough to clear,
and the leans round it come down to meet it at no more than 2 degrees a
millimetre; the operation says how many points it leant less. Each part of
the tool is checked exactly: everything within its radius of its stretch of
the axis kept that far from the part.

With **5-axis: the control keeps the tool's tip (TCP)**, the program gives
the tip on the part between `G43.4 H#` and `G49`, for any layout. Without it,
GarageCAM works out where a turned table carries the tip, fed in inverse time
(G93). The table turns about each axis where it runs: through the work zero,
or where Machine Definitions says **its centre from the work zero** is (a
trunnion's tilt axis below the part's top, say). Before posting, the machine
check makes sure every direction can be reached, and that the axes stay
inside their travels. The backplot leans the tool, and **Verify** cuts with it leaning
**on every side** (see Stock and verify). Posted as **Not Proven Yet**.

**On a 4th axis along X** (the AltMill's Vortex) these run 4-axis
simultaneous when the tool only ever leans about X. A drafted wall running
along X is like that: A leans the part, and X, Y and Z follow where the
turned part carries the tip. A wall across X needs the tool leant about Y,
which only a 5-axis machine can do: the machine check says so, and the post
leaves that operation out. On round stock, Verify cuts the bar with the tool
leaning too.

Any 2D operation can instead be **wrapped** round the A axis. The flat path is
rolled onto the stock diameter: X stays along the rotary axis, flat Y becomes A
degrees, and Z is measured from the rotary centreline. Arcs are cut into chords
first, because an arc does not survive being rolled up.

**Way round** (on the Rotary page) says which way A turns as flat Y grows.
**A turns with Y** is the default, the way GarageCAM has always posted wrapped
paths. On a machine whose A turns the usual way (Machine Definitions: A90 tips
the front face, towards you, up to the spindle) that carves a drawing as its
mirror image, and **A turns against Y** reads as drawn (and wraps geometry
unrolled off a modelled bar back onto the place it came from); on a 4th axis
turning the other way, as many are mounted, it is the other way round. Index a
program to A90 and run it in the air to see which way yours turns. The
backplot, machine simulation and Verify show the cut where the posted A puts it
on a machine turning the usual way, on the same side as an operation indexed to
that A, so a mirrored drawing shows mirrored. A machine whose A axis is
**Reversed** in Machine Definitions is told the other way for wrapped paths
too, as it is for indexed ones. Rotary Rough and Finish cut the model where it
is, whichever way round.

Feed rates are corrected per move: grblHAL measures a mixed move with degrees
sitting beside millimetres, so each line carries the feed that gives the right
speed at the radius actually being cut. A full circumference comes out as
exactly one turn. A depth that would cut past the centreline is refused, and
the backplot shows the path rolled round the stock, tool and all.

**Rotary Finish** is the continuous version: the part turns under the tool
while the tool follows its shape, so a round part finishes without the flats
that indexing leaves. Each angle is worked out by turning the model there and
dropping the cutter on it, so a flat and a ball mill again leave what they
really would; the path is written as a wrapped one, which is what gets the feed
rates right.

**Rotary Rough** is the same cut a step at a time: it comes in from the surface
of the bar one stepdown at a time until it reaches the shape, so a shaft can be
turned out of oversize stock before the finishing pass follows the part itself.
Passes that would only cut air — where the level above already came in that far
— are left out. Where the cutter hangs off the end of the part it holds the
radius it had at the end rather than following the rim down, because resting on
the edge of a part is not a cut and diving to the floor there would be.

### Turning (lathe)

The **Turning** tab programs a lathe, on the job's round stock: the bar
along X, its end at the largest X, the chuck towards -X. The part's
**profile** is its top half drawn on Top, with model X along the spindle and
model Y the radius.

**Held in the chuck** (Stock Setup, round bar) is how much of the bar's back
end the jaws hold, and **Stop short of the jaws** how far in front of their
faces turning stops: roughing and finishing go no further back, a groove,
thread or part-off that would is refused, and Verify calls any tool that
reaches past the jaws' faces outside the bar a crash into the chuck. Left at
none, the jaws are taken to be just behind the bar's back end. **Tailstock
up** puts a centre in the bar's front end (a 60 degree point, its body as
wide as given): facing, drilling and boring that end are refused, and a tool
that reaches the centre is a crash. Posting a turning program cuts the bar
through first: a rapid through the bar, or a tool into the chuck or the
tailstock, is shown as a crash before the file is written.

| Operation | What it does |
|---|---|
| **Face** | Squares the end from outside the bar to past the centre, a cut at a time |
| **Rough** | Takes the outside down to the profile in passes towards the chuck (or, Passes: across the face, facing in towards the centre for a flange or a disc), each stopping at the profile and leaving stock to finish, then runs once along the profile so what is left is even |
| **Finish** | Runs the insert's nose round the profile, a nose radius off it, from the face to the jaws |
| **Groove** | Plunges a blade between two walls to a diameter, pecking if asked; with **Then finish round the walls and floor**, the plunges leave the stock to leave and one pass goes down the front wall, along the floor and up the back. Cutting **the bar's end** instead (a face groove, an O-ring groove), a face grooving blade lying along the spindle plunges back into the face between an inside and an outside wall diameter, from the outside wall in, and the finish goes down the outside wall, across the floor and up the inside one; it is posted for the blade's outer corner |
| **Thread** | Cuts in passes along the flank (29.5 degrees), the depth growing so each pass takes an even chip, then spring passes; several **Starts** cut each depth for every start, each begun a pitch further along, every pass going the lead (pitch times starts) a turn |
| **Drill** | Drills on the centreline, pecking the chips out |
| **Cut Off** | Parts the piece off, leaving a pip if asked |

Each operation has:

- a spindle at a **constant surface speed** (G96, capped at a top rpm) or at
  the tool's rpm;
- feeds **a revolution**;
- coolant and a comment.

**Boring.** Rough and Finish can cut **the inside of a bore** instead (Cuts:
inside). **Bore** and **Bore Finish** on the Turning tab start them that
way. Pick the bore's profile: its wall, and its floor if it has one. A
tube's whole outline (as Profile From Solid draws it) can be picked for both:
it is split at the foot of its front face, turning taking the outside and
boring the bore.
Boring opens out the hole that is there already, which is the lathe drill's
earlier in the job unless another size is given. With no hole it is refused.

- Roughing goes in along the spindle a depth of cut further out each time,
  then lifts towards the centreline to come back out.
- It then runs once along the bore.
- The finish runs the nose along the bore from its mouth back.
- The insert points out, so the post writes its tip a nose radius above the
  nose's centre.

**Groove** and **Thread** can cut inside a bore too:

- An inside groove goes in along the bore, plunges the blade out into the
  wall to its diameter and backs off toward the centreline. It works out
  from the hole there already, as boring does.
- An inside thread's major diameter is the outside of the thread, where the
  last pass reaches. The passes go out from its minor along the flank and
  back off toward the centreline between them. It has to start in front of
  the bar's end.

Lathe tools are made in the Tool Manager: a **turning insert** (its corner
radius is the nose), a **grooving blade** (its diameter is the width) and a
**threading insert**. A drill drills.

A turning insert's **Angle** is its included angle: 80 for a C insert, 55
for a D, 35 for a V, 60 for a T. Anything else counts as 80. Its **Lead** is
the holder's lead angle, from the way it feeds (towards the chuck) round to
the insert's leading edge: 95 for most 80 degree holders, 93 for 55 and 35,
107.5 to back-turn, 62.5 or 72.5 for a neutral holder. Left blank it is the
usual for the insert: 95 degrees for an 80, 93 for the rest. The Tool
Manager draws the insert at its lead, with what it clears.

Its back edge trails behind the nose, so it can only follow a profile down
toward the chuck so steeply: 180 less the lead and the insert's angle (5
degrees for an 80 at 95, 32 for a 55 at 93, 52 for a 35 at 93). Where a
profile falls more steeply than that, Rough and Finish follow only what the
insert can reach: down at its clearance angle from the top of the fall until
it meets the profile again. What is under that line is left on, and they say
how much, for a narrower insert or a groove to take off. Inside a bore the
same goes for where it opens out towards the chuck. An insert and lead that
come to 180 or more leave nothing clear behind, and are refused.

Led at under 90 degrees, the leading edge leans over what is ahead of the
nose: it can climb a shoulder rising towards the chuck no steeper than the
lead, so Rough and Finish rise at the lead from the shoulder's foot and say
what is left in the corner; and it cannot come down the bar's end square, so
they keep to a cone in front of it (face the end with a tool led at 90 or
more).

The backplot shows the insert in the turning plane. **Verify** turns the bar:

- each tool's shape is taken out of the bar's half section along its moves,
  in order: an insert as its own rounded rhombus with its body above it, a
  blade's width, a drill's width;
- what is left is turned round and coloured against the part, red into it,
  green on it, blue left on;
- a rapid through material still standing is a crash, and says where.

Threads are a helix, so they are left out of it and named.

A turning operation on a machine defined as a mill is caught before posting:
pick or make a lathe (Machine Definition, Kind: Lathe). A new operation of
another kind starts from its own numbers rather than the last one's:

- a finish takes the profile to size;
- a thread starts three pitches off the part's end, on the bar's diameter;
- a cut-off goes right through behind the part.

A program with turning in it is written as a **lathe program**:

- **Axes.** X across, on the diameter (G7 where the control needs telling), Z
  along the spindle, arcs in G18 with I and K.
- **Reference point.** Each point is where the tool was touched off: an
  insert's imaginary tip, a blade's front corner, a threading or drill point.
- **Code.** G96 with G50 or `D` for the top rpm, G95 or G99 feeds, threads
  as G33 K or G32 F, tools as T0101 or T1 M6.
- **Threading cycle.** A post can write a thread as the control's own G76
  instead of every pass (`latheThreadCycle` in its file): Fanuc's two-line
  G76, or the one-line G76 of LinuxCNC and grblHAL. The passes, the infeed
  along the flank and the spring passes come from the same thread settings.
- **Roughing cycle.** A Fanuc post can hand roughing along the spindle to
  the control's G71 (`latheRoughCycle`): the depth of cut, the retract and
  the stock to leave go in the cycle, and the part's outline (the tip's path
  to finish it, from the face back to the jaws) follows it between the P and
  Q line numbers. Boring, the cycle starts in the drilled hole, the stock
  across is less than nothing, and the outline runs from the bore's mouth in
  as far as the hole. A Finish after it over the same outline with an
  insert of the same nose radius (nothing left on) is written as G70 on the
  G71's lines, its feed on their first line. An outline that dips back the
  other way is written out pass by pass, unless the post allows G71 type II
  (Roughing as: G71, and type II where the outline dips), which takes it as
  long as it only goes back along the spindle, nothing left along it.

The NC Editor reads a lathe program back in the turning plane: any program in
G18 with no Y in it, Z along the spindle, X on the diameter (or the radius
after G8), its arcs and thread passes and all. Its cycles come back as the
control cuts them: a G71 a depth of cut at a time along the spindle, as far
as the outline its P and Q name left U and W proud (each dip of a type II
outline cut in turn), out at 45 degrees and back, then once along the outline
so left; a G70 as the outline; a G76 pass by pass down to the thread's root
(Fanuc's two lines, or the one of LinuxCNC and grblHAL). The test suite posts
a rough as a G71 and a finish as G70 on its lines and reads them back: no pass
nearer the outline than the 0.2 left, the finish on the outline to a micron,
and Fanuc's G76 pass for pass the operation's own.

**Import NC Program** brings a lathe program in as an operation per tool, and
those are turned like any other: in the backplot, in Verify (on the bar,
against the part, with the chuck and tailstock) and in the crash check before
posting. With a turning insert, what the program says is its imaginary tip, so
each move is taken back to the nose's centre, a nose radius along and across;
which way the insert points is read from how it lifts off the cut to go back
(away from the centreline outside, towards it boring). A drill on the
centreline lies along the spindle as it does in a Lathe Drill. Each piece read
at a tool change carries the modes in force before it: the plane, the units,
diameter or radius, feed a minute or a revolution. A feed a revolution (G95),
and a thread's lead (G32 F, G33 K, G76), is read as a minute's worth at the
spindle's speed: S, or under G96 the surface speed round the diameter being
cut, up to its limit (G96 D, or G50 S), so run times come out right. The test suite posts a
tube's whole program (turning, drilling, boring), reads it back and verifies
it: the same as the operations, nowhere in the tube.

The **Fanuc Lathe**, **LinuxCNC Lathe** and **grblHAL Lathe** posts are built
in, and every lathe block can be rewritten in Program Blocks. A machine
definition's **Kind** says it is a lathe. Nobody has run turning from
GarageCAM on a real lathe yet, so it is posted with **Not Proven Yet**.

### Backplot, setup sheet and tools

Toolpaths rebuild whenever their geometry changes. One that can no longer be
built is shown in red in the manager, and posting refuses to run until it is
fixed or switched off. A toolpath can be hidden from the backplot, or skipped
when posting. Each operation in the manager opens to show its tool, its
geometry, its depths and anything it wants to warn about. Ctrl or Shift click
selects several: the right-click menu then regenerates, posts, changes the tool
of, duplicates, hides, skips or deletes them all at once. **Post This
Operation** (or **Post These**) writes a program of just those.

Selecting operations in the manager puts **arrows along their cuts** the way
they run, one to a place however many depths overlap there, so climb or
conventional can be seen at a glance. **Reverse Cut Direction** on the
right-click menu turns climb into conventional and back (on the line, with no
side to climb on, it runs the chain the other way), and the arrows turn with it.

Once posted, the program opens in the **NC Editor** (turn that off, or open any
other program, from the arrow beside **Post G-code**). Words are coloured by
what they do, lines are numbered, Ctrl+F finds, and it saves back. With **Show
in Graphics** on, the program as written is drawn over the job (rapids
dashed) and the tool stands where the line the cursor is on leaves it, so a
hand edit can be checked before it goes to the machine. Its zero is the WCS's,
so a program for a part laid on its side is drawn on that side, and one posted
for a setup turned over is drawn under the part.

The **Backplot** panel plays the program back with a tool body in the
viewport, showing each move as the G-code it posts as. Space plays or pauses,
the arrows step a move, Home and End jump. Times use the machine's own axis
rates once they are entered under **Settings > Machine**.

Posting also writes a **setup sheet** beside the program: a picture of the job
as the graphics show it (set the view and what is shown before posting), the
stock, the tools
to have ready and what each one is used for, every operation with its depths
and time, and anything that needs attention; and the **setup**: the WCS and
which way up the part goes (as modelled, turned over, or laid on a side), where
X0, Y0 and Z0 are on the stock as it sits, and any A indexing. Plain HTML, so
it prints.

The **tool library** can be exported and imported as CSV from the Tool Manager,
so the cutters you own live outside any one job and can be edited in a
spreadsheet. **Import...** also reads a **Fusion 360 tool library** (its exported
.json): flat, ball and bull nose end mills, chamfer and engraving mills (as V
bits of twice their taper angle) and drills, with their numbers, sizes, stick-out
and first preset's speed and feeds, inches made millimetres; kinds GarageCAM has
no cutter for (taps, saws) are left out and counted. **Feeds...** works every tool's feed out from chip load — spindle
speed times flutes times chip per tooth, for the material being cut — and where
the machine cannot hold that feed it says what to slow the spindle to instead
of rubbing. They are starting points, not gospel.

### Posting

The post emits inches (`G20`) or millimetres (`G21`), absolute, feed per
minute, `G54`, and lifts to clearance in Z alone before any XY positioning. Arc
centres are incremental `I`/`J`. Every entry rapids to the retract height and
feeds from there, so retract must be above the stock; that is checked. With a
**feed plane** set (Heights page, off to start, absolute or above the top of
stock), the rapid comes on down to it and only the last stretch is fed; it is
never put below the top of stock, so a rapid cannot reach material.

**Use clearance**: at the start, the end and between pieces (as always), only
at the start and end of the operation (between chains, holes and loops the
tool travels at the retract height), or off (the retract height everywhere).
It is only done where the retract is above the stock, the model and every
cut; otherwise the clearance stays, and the operation says why.

Every height on the Heights page has a **Pick...** button, the way other CAM software's
height buttons work: the dialog steps aside, you click a point in the view (it
snaps to ends, centres and the corners of solids), and it comes back with that
height set to the point's Z, measured along the operation's plane. Esc keeps
the number typed.

**Reference points** (Heights page): an operation can **come in from** one
point and **go out to** another, typed or picked off the view, to keep clear
of a clamp or come off by the door. The moves to and from them go up first
and down last, never on a slant.

Straight moves that lie on a circle are **fitted back to arcs** before posting,
within a tolerance you set, which shortens the file and stops a curve arriving
at the machine as a thousand short segments. A run of moves is only fitted when
every point sits on the circle *and* the bulge of each chord is inside
tolerance, so a square corner is never rounded off. Wrapped paths are left as
chords, because an arc means nothing once it is rolled round the A axis.

**Post Options** are saved with the job: the unit, work offset G54 to G59,
coolant, a spindle warm-up dwell, whether tool changes and M3/M5 are output at
all (gSender can run the spindle itself), and where the machine is sent when
the program ends.

They also cover the things a controller asks for rather than the cut:
**numbered lines** (N10, N20, ...), which is what grblHAL quotes back when it
stops on one and what an operator restarts from; an **optional stop** before
each tool change, so a first part can be looked at without editing the program;
and a **tool change position** in machine coordinates, so the spindle comes
somewhere reachable and clear of the work before the tool comes out. Comments
and blank lines are never numbered.

**Turning** in Post Options says how a lathe program is written: X on the
diameter or the radius, the code that sets diameter mode, feeds a revolution
or a minute, how the top rpm goes with G96, thread passes as G33 or G32 (or
the whole thread as a G76 cycle), and tools as T0101 or T1 M6.

**The posted program** is laid out like the programs proven on the owner's
AltMill ATC: a list of the tools at the top (number, diameter, corner,
deepest Z, type), then G90 G94 / G17 / G20 or G21 / G28 G91 Z0 / G90. Each
tool goes in with T M6, S M3, G17 G90 G94 and the work offset, then moves over
the start point in X and Y and only then comes down to clearance: never down
in Z before it knows where it is. Between tools: M9, M5, Z home. At the end:
M9, Z home, X home, then Y home, each on its own (the AltMill's tool rack
sits at Y home, and X and Y together would cut the corner through the
keep-out zone round it and alarm), M30; Post Options > When the program ends
> After Z home has X and Y together, Y then X, X only or Y only for other
machines. Words that have not changed are left out (X
alone when only X moves, no G1 on every line), which roughly halves a 3D
program and reads back to exactly the same moves.

**Accepting a warning**: an operation with a warning shows orange in the
manager, with the warning listed under it. When the warning is what you meant
(a contour cut right through with no tabs, the part held down some other
way), click the warning line and choose Accept: it stays listed, greyed and
marked accepted (and so on the setup sheet), but no longer turns the
operation orange. Click it again (or right-click it) to be warned again. The
acceptance is kept with the job; if the warning changes word for word (other
numbers, another cause) it is raised afresh.

**Cuts Into the Model**: each 2D operation is cut against the solids showing
as soon as it is made or edited, and one that goes into the part shows as a
warning in the manager straight away (a contour chained along the top of a
chamfer, say, runs inside the wall by the chamfer's width). Before a program
is written, every operation that
will be posted is cut on its own into a block round the solids showing, and
any that goes more than 0.05 mm into the part is listed with how far and
where, with Post Anyway or Cancel. How far is the gouge's real size: a wall
shaved back by half a millimetre reads half a millimetre, with how deep it
looks from above (the wall's whole height) said beside it; Verify reports it
the same way. 3D paths are already held off the model as
they are built; this is for 2D work, which knows nothing of the solid: a drill
bigger than the hole, a spotting cone too wide for the counterbore it goes
down, a pocket drawn past the part. Engraving that the solid was not modelled
with shows here too. An operation on another side (indexed round A or on a
Tplane) is checked with the part turned to that side; only wrapped paths are left
to Verify. Any 2D operation that cuts more than 0.6 mm below the bottom of the
stock block says so as it is built: that is cutting into whatever the stock
sits on (a drill breaking through is left out; it is meant to).

**Drill with canned cycles** (off unless ticked) writes drilling and spot
drilling as one cycle line and a list of holes: G81 for a plain hole, G82 with
a dwell, G83 for full-retract pecking, G73 for chip breaking, and G85 (G89 with a
dwell) for the bore / ream cycle, which feeds back out of the hole rather than
rapiding up the finished wall. Each has G98
so the tool comes back up to clearance between holes exactly as the spelled-out
moves do, and G80 after. The holes are read back off the moves themselves, so
the program matches the backplot; an operation whose holes differ in depth, or
that pecks with a dwell (no standard cycle does both), is written out move by
move instead. grblHAL runs canned cycles; plain Grbl does not.

**A file for each tool** posts each run of operations on one tool as a file of
its own, named in running order (`PART_01_T1.nc`, `PART_02_T2.nc`, ...), for
changing and zeroing the tool by hand between files in gSender. A tool used
again later gets another file in its place in the order.

### Machine definitions and post processors

The first time GarageCAM starts on a computer it asks three things: the
machine (a Sienci AltMill with the ATC and the Vortex, an AltMill with tools
changed by hand, or another machine by name with its travels, a rotary and a
tool changer if it has them), the control it runs (which post: grblHAL, Grbl
1.1, LinuxCNC, Mach3 / Mach4) and the units on screen; it sets up the machine
definition from that.

Like a CAM system's machine definitions, each machine GarageCAM posts for is
a **machine definition** of its own (Settings > **Machine Definitions**, or
double-click Machine in the manager's Machine Group): a name and description,
the **post processor** it is posted with, what it has (a **rotary axis**, an
**automatic tool changer** and how many **slots** its rack holds, **flood** and
**mist** coolant), and what it can do: the fastest each axis moves ($110 to
$113, the A axis included), how fast each gets up to speed ($120 to $123) and
the junction deviation ($11), how far each travels ($130 to $132) and the
spindle's range ($30, $31). With the accelerations of X, Y and Z known, run
times are **planned the way grbl plans them**: each move run up to its feed and
slowed again for the corners and short moves after it, each corner taken as
fast as the junction deviation allows, arcs as the short chords the control
cuts them into. A 3D finish of thousands of short moves can take several
times what its feed alone says, and the estimate now says so (200 square
steps of 0.5 mm at 100 mm/s with 500 mm/s²: 9.8 s, not 1), and playback and Verify
run on the same clock. An operation the corners slow by more than half
again (and half a minute) says so, with what lets it keep its speed.
Without them every move is taken at its feed, as before. Those are grblHAL's own settings, so rather than
typing them, type `$$` in gSender's console, copy what it lists and use
**Read from $$**. Each definition is kept as a `.gcmachine` file; **New**,
**Delete**, **Import** and **Export** make another, drop one, or take one to
another computer (a friend's machine set up once and sent over). The AltMill
starts set up: twelve tool changer slots and the Vortex rotary.

A job keeps the name of the machine it is for, and opening it makes that
machine current, so its time estimates and checks are that machine's own.
Picking a machine for a job puts the job on that machine's post. Before a
program is written it is checked against the machine: a spindle speed the
spindle cannot run, a feed an axis cannot reach (the Z plunge, or a wrapped
cut that would spin the A axis faster than it goes), more travel than the
machine has, a tool the tool changer has no slot for, an operation that
turns a rotary axis the machine has not got, or coolant it has not got. On
a lathe, a thread goes along one pitch a turn whatever that comes to, so a
pitch and rpm that would need Z faster than it goes is told, with the rpm
that fits: a thread cannot be slowed part way without spoiling it.
grblHAL clamps the speeds and feeds without a word, so the cut would not be
the one planned; GarageCAM lists all of it and asks before posting. A
setting left at zero is not checked rather than checked against a guess.

**Post processors** (Settings > **Post Processors**) keep post settings under
a name, as `.gcpost` files: GarageCAM's own **grblHAL** post is built in (as
proven on the AltMill, and never changed or deleted), and any number more
can be made from a job's settings (**New From This Job**), copied, edited,
deleted, imported and exported; **Use for This Job** posts the job with one.
Besides everything in Post Options (units, work offset, arc fitting, line
numbers, canned cycles, a file per tool, spindle warm-up, coolant, the tool
change position, where the program ends), a post says what the control
takes: tool changes as **T# M6**, as a **stop (M0)** that names the tool to put
in by hand, or not at all; arcs as **I/J** or as **R** (an arc over 170 degrees
in even pieces, since R cannot tell the long way round); comments in
brackets or after a **semicolon**; how many **places** after the point; the
**rotary axis letter** (A, B or C); lines of its own at the **start** and
**end** of every program (a probe call, a dust shoe macro); a **tool length
offset** with each tool (G43 H#, G49 at the end) for a control that keeps
tool lengths in a table; **cutter compensation** (G41/G42 D#, G40) for one
that has it; **%** at each end and a **program number** (O#)
for a control that wants them; a **point on every coordinate and feed**
(X1. not X1: a Fanuc-style control reads a number without one in its
smallest steps, so X1 would be a ten-thousandth of an inch); **dwells in
milliseconds** (G4 P500, as Fanuc reads P); the **next tool called up** after
each change (T# M6 then T next, so a carousel fetches it while this one
cuts); and **rotary cuts in inverse time** (G93, F one over the minutes each
move takes, G94 after), timed the same way by every control that has it.
Besides grblHAL, posts laid out for **Grbl
1.1** (no tool changer: a stop at each tool change saying which tool to put
in), **LinuxCNC** (G43 H#, canned cycles, cutter compensation), **Mach3 / Mach4** (%, O0001,
G43 H#, canned cycles, cutter compensation) and **Fanuc / Haas** machining
centres (%, O1000, N numbers, points on every coordinate, the next tool
called up, G43 H#, wear comp, canned cycles with millisecond dwells, rotary
moves in G93) are built in for other machines; they follow those
controls' usual layout but have not been run on one yet, so the first
program from each wants proving out with care. The program's heading names
the post it was written with.

Nothing in a post is locked away. **Program Blocks** (in Post Options) are
the pieces of program a post writes in several places, and each can be
written the control's own way:

- the program start;
- Z up out of the way (G28 for grbl, G53 for most industrial controls);
- the tool change, spindle on and off, and coolant off;
- what is said again after each tool change;
- turning the rotary;
- X and Y at the end, and the program end.

Each block is filled in with words such as `{T}`, `{NEXT_T}`, `{S}`, `{TOOL}`,
`{DIA}`, `{WCS}` and `{HOME_Z}`. A live preview writes a whole program from a
made-up job as you type. A post is a plain `.gcpost` text file; **Open
Folder** shows them all. The guides in `docs/` say how to write one for any
control:

- [docs/POST-PROCESSORS.md](docs/POST-PROCESSORS.md): every setting, block and
  word;
- [docs/MACHINE-DEFINITIONS.md](docs/MACHINE-DEFINITIONS.md);
- [docs/FOR-AI-ASSISTANTS.md](docs/FOR-AI-ASSISTANTS.md): rules and a checklist
  for an AI assistant asked to write a post or machine definition.

The guides come with every copy, and **How Posts Work...** opens them.

**Proven or not.** A post is proven once its programs have run right on a
real machine; the built-in grblHAL post is proven on the AltMill. Posting with
anything not proven yet brings up **Not Proven Yet**, with how to run the
first program safely (in the air first, then single block with the overrides
down). At a later start GarageCAM asks how it ran. Besides posts, what has
not been run anywhere yet is asked about the same way: turning, the G76 and
G71 cycles, 5-axis cutting on each machine layout, the control's tilted work
plane, and the part turned by rotaries other than an A along X.

**Help > Report How a Program Ran** sends a test result to the suggestions
inbox: what was run, on what machine and control, and whether it came out
right. A post that ran right stops warning on that computer, and a post of
your own records what it was proven on (**Proven On...** in Post Processors).
Changing a proven post makes it unproven again.

A contour's **compensation type** is the usual set: **computer** (the path is
worked out here and the control is told nothing), **off** (the tool centre on
the chain), **wear** (the path worked out here, and G41 or G42 with the tool's
D offset told the control too, so its wear offset can fine-tune the size:
G41 climbing, G42 conventional), **reverse wear** (the other code) or
**control** (the program sends the tool's centre on the chain, the stock to
leave and side passes still out from it, with G41 or G42, and the control
offsets it by the whole radius in its tool table; the backplot, Verify and the
model check still show where the tool really goes). It comes
in on the first move across of each cut and goes off with G40 after; a
lead-in with a straight line at least the tool's radius long is wanted (a
warning says so otherwise). On a control with no cutter compensation (grbl)
the path posts as worked out, with a note; and a control path that could not
be worked out is never sent as the computed one with G41/G42 (the control
would offset it twice).

**Always prove a program out** — air cut, then foam or wax, then material.

## Updates

Each published release has a version number, one step on from the last
(0.1.1, 0.1.2, ...), shown in Help > About, in Settings > Updates and in the
offer of a newer one. A copy handed round can keep itself up to date. **Settings > Updates** takes
an **update address** (given by whoever hands GarageCAM round) and whether to
look there each time GarageCAM starts. When a newer build is out, it says
so with what changed: **Later** leaves it and carries on (it asks again at
the next start); **Install** fetches it, GarageCAM closes (offering to save
first) and an **Updating GarageCAM** window waits for it to close, unpacks
the new build, copies it over (keeping anything else in the folder), checks
the new build really went in and starts it again, then closes by itself. If
a step fails (a file held open by another program, a broken download) it
says why in a message on top of everything, opens the unpacked new copy so
it can be copied over by hand, and writes every step to `update.log` in the
temporary GarageCAM-update folder. The copy has to sit in a folder of its
own that it can write to (unzipped into the user's own folders, not Program
Files). Releases are put out with `sh tools/publish-release.sh "what
changed" [OWNER/REPO]` after `tools/make-share.sh`: a public repository
holding only the latest zip and its `version.json`, never the source; a
copy built by make-share has the address built in.

## Licence

GarageCAM runs only with a licence. Without one (or with one that has run
out, been changed, or is for another computer) it opens only the licence
window: **Load License File...** takes the `.gclicense` file that was sent,
and **Quit** closes it. **Help > License...** shows who the copy is licensed
to, what kind (**Lifetime**, **Monthly**, **Yearly** or **Trial**) and until
when, and the computer's code, for a licence tied to one computer. A licence
that runs out is checked against the latest date GarageCAM has been run at on
that computer, so winding the clock back does not bring it back.

Licences are signed with a private key (ECDSA P-256 with SHA-256, through
Windows' own cryptography) and checked with the public keys built into the
program, so one cannot be made or altered without a private key. There are
two, both kept only on the owner's computer in `C:\GarageCAM Keys` (never in
the repository or a shared copy):

- the **owner key** signs any kind, and is the only one that can make
  **lifetime** licences;
- the **issuer key** signs monthly, yearly and trial licences only, each no
  longer than its kind allows (a month, a year, 30 days, with a week's
  grace). The program refuses a lifetime licence signed with it, or one
  running longer. It is there so that giving out paid licences can one day
  be handed to an automated system after payment, without that system ever
  being able to make lifetime licences.

On a computer with a key, **Help > Make a License...** makes one: a name, an
email, the kind and the date it runs out, and if wanted the code of the one
computer it runs on, saved as a file to send. With the owner key there it
signs with that (all kinds); with only the issuer key, Lifetime is not
offered.

The copy handed out is **sealed**: `tools/make-share.sh` builds it apart
(in `build/share`, with `GARAGECAM_SEALED`), and the owner's key signs the
program file's SHA-256 into `GarageCAM.seal` beside it, so only the owner's
computer can make one. A sealed copy that has been changed in any way says
so and will not run. The licence (and the seal) are asked again every ten
minutes and before posting or verifying, each check built in on its own, so
there is no single place to change to get round them; a licence that runs
out while GarageCAM is open closes it, after offering to save the job.
Today's date is also taken from the internet when there is a connection, and
the latest date seen is kept in two places, so a clock wound back does not
bring a licence back. The shared copy carries no debugging symbols (they
would name every function); they are kept per build in
`C:\dev\GarageCAM-symbols` to read crash logs with, which give each place as
`GarageCAM.exe+offset`. Everything else (posts, machine definitions, jobs,
tool libraries) is plain files anyone can read and edit.

## Quick Start

**Help > Quick Start** (and the File page's Help) walks a first part through
from start to finish: bring the model in, set the stock and where zero is,
make the operations, check them in Backplot and Verify, post, and prove it out
in the air first, with the mouse and keys needed on the way. It also comes up
once after the welcome, the first time GarageCAM is started.

## Suggestions

**Help > Send a Suggestion** (or the File page's Help) is for whoever is
trying GarageCAM out: a **bug**, an **idea** or a **question**, which part of
the program it is about, what happened or what they would like, their name,
and (ticked by default) a picture of the GarageCAM window as it is. The
build being run and the computer's system go with it. Each is kept on that
computer. **Help > Suggestions** lists them, newest first, to read (with the
picture), mark (**New**, **Planned**, **Done**, **Won't do**) and note what was
decided; **Export to Send** makes one `.gcsuggest` file of them (the ones
picked, or all) to send to whoever keeps the list, **Import** brings such a
file in (any already there are skipped, so the same file can come twice),
and **Spreadsheet** writes them all as a CSV to go through together.

With a **suggestions inbox** they go to the owner by themselves: each one is
sent as it is written (and kept on the computer too), and any written with
no connection go at the next start; the list shows which have been **sent**.
The inbox is a Google Sheet: `tools/suggestions-inbox.gs` is pasted into the
Sheet's Apps Script and deployed as a web app (the steps are at the top of
that file), and each suggestion becomes a row (when, from, kind, what it is
about, the words, the build and system) with its picture saved in a Drive
folder and linked from the row, and Status and Notes columns to work through.
It takes only GarageCAM's posts and never the same suggestion twice. The
inbox's address goes in **Help > Suggestions** (Inbox), or is built into the
shared copies (`GARAGECAM_SUGGESTIONS_ADDRESS`).

## Files

`File > Save` writes a `.gcam` file: a one-line header carrying a format
version, then a BinTools payload holding wireframe and solids as two separate
compounds. It is written beside the old file and put in its place only once
complete, so a save cut short never leaves a job half written.

Closing, New or Open with unsaved changes asks to save them first. While there
is unsaved work, a recovery copy is kept every three minutes; if GarageCAM does
not close normally, the next start offers that work back.

`File > Wireframe from Solids` (Ctrl+W) explodes every imported solid into
wireframe edges, so STEP geometry can be chained and offset directly.

`File > Import IGES` reads the older format the same way: loose faces are sewn
into shells where their edges really do meet, what is left is healed, and
same-domain faces are merged as they are for STEP. Faces go in as a solid to
machine; edges with no face on them go in as wireframe to chain, which is what
an IGES file exported from a 2D drawing usually holds. Both counts are
reported.

**Holes from Solids** finds the drilled holes in the visible solids — putting
the halves STEP splits a bore into back together first — and draws a circle at
the mouth of each on a Holes level, with a count of the sizes found. Pick one
with Drill and every hole of that diameter is machined. Holes that do not run
down Z are counted and left, since the part would have to be turned first.
Only a bore that goes most of the way round (300 degrees or more) counts: a
fillet in an inside corner is a quarter of a cylinder, and a hole an edge cuts
through is a slot, so neither is drilled.

**Auto Pockets** (Toolpaths tab, under the arrow beside Pocket) does the same
for pockets: every flat floor facing up in the visible solids, below the top
and walled all the way round, gets its outline on a Pocket features level and
a pocket from the top of stock (or where a facing operation left it) down to
that floor, with the biggest flat end
mill in the library that fits. Bosses standing in a pocket are kept as islands;
a pocket inside a pocket gets its own, deeper operation. A floor open to a side
(a step down the part) gets a Dynamic Mill working in from outside the stock
down to it, keeping out of the part's cross-section just above the floor, so it
clears round the part and over the step; each is checked against the model and
dropped if it would touch the part. A round floor walled by one circle is the
bottom of a bore or counterbore, a hole, and is left to Auto Drill. Check each
operation before cutting.

**Auto Profile** (under the arrow beside Contour) cuts the part out of its
block. Every window going right through the visible solids (as the part sits on
the WCS) gets a Contour from inside, at its narrowest across the part's
thickness (between rounds or chamfers at top and bottom, under a step widening
it at the top), and then the part's outline, all of it seen from above at its
widest, gets one from outside: the windows first, so the part is still held
round its outline while they are cut. Each goes from the top of the block (or
the part's top, with no block) down through the part and on by the Contour's
break through, with the biggest flat or bull nose mill in the library (one whose
flutes reach all the way down before any that do not) that builds a
contour round the loop cutting nothing of the part. Tabs, depth cuts and leads
are the Contour's own (the last in the job, or your saved defaults); with no
tabs it says the part comes free on the last pass. A round opening is a hole
and is left to Auto Drill, a pocket that does not go through to Auto Pockets.
The loops go on a Profile outlines level. The test cuts a plate with rounded
corners, a triangular window, a round hole and a blind pocket out of a block:
the window then the outline, nothing of the plate gone, the block cut right
down outside it and in the window, the hole and the pocket left.

**Auto Program** (Toolpaths tab, beside Stock Setup) makes a whole first
program for the part as it sits in the stock on the WCS, in the order the work
goes: a facing from the block's top down to the part's (the widest flat or bull
nose mill; not when the setup faces already, or the block is no higher than the
part), then Auto Drill (the holes facing up; other sides are not asked about),
Auto Pockets, Auto Chamfer (while the part is still held all round), Auto Round
Over when the model has rounds drawn and a corner rounder their size is in the
library (a cutting board drawn with its edges rounded over), and Auto
Profile last, each with all its own checks and messages. It needs the stock set
up, and asks first when the toolpath group has operations in it already (it
does not look at what they cut). The status bar says how many operations each
step made.

**Auto Chamfer** (under the arrow beside Chamfer) deburrs the part: every sharp
edge round the flat faces looking up in the visible solids, the outline of a
top and the rims of the holes and pockets sunk into it, goes on a Chamfer edges
level, and for each height a Chamfer goes round the outlines from outside and
another round the rims from inside, with the job's chamfer mill (the V bit
nearest 90 degrees), as wide as the last chamfer in the job. An edge already
chamfered or rounded is not sharp, nor is a floor's corner where it meets the
walls round it, and a loop only partly sharp (a face stepping down one side and
up another) is left out and said. Each loop is first chamfered on its own and
cut into the part as it stands: a chamfer may cut only the loop's own face, no
further from its edge than the width and no lower than the chamfer goes down
the wall. One that cuts anywhere else (the tool's body down a counterbore
shaving its wall, into a pocket narrower than it at its floor, or its tip into
the floor of a recess shallower than it goes down: the owner's cutting board's
half millimetre foot recesses) is drawn but not chamfered, and said with how
far and where. Edges the model has chamfered already (a top's loop where every
edge is the top of the same bevel, a plane sloping down and out or a cone round
a curve, coming down onto walls standing straight up, as the owner's brace,
extractor and smash plate are drawn, 0.76 at 45 degrees) are cut as drawn, as
wide as they are drawn, by the V bit at their angle, picked first; they may cut
nothing beyond the model, and a bevel at another angle is said and not cut.
The owner-parts survey finds those on the three parts and cuts them nothing
into them, seen from above. The test suite chamfers a plate with a pocket
and a hole through it and compares it with the same plate chamfered 1 mm in
the model: nowhere into it, all of each chamfer cut but a little of the mitre
in the pocket's corners, which a turning cutter cannot reach; and the plate
chamfered so in the model has its three loops found and cut as drawn, 1 wide,
nothing into it, where a 60 degree bit says they are 45.

**Auto Round Over** (beside it) takes the same edges and rounds them over with
the job's corner rounding mill: the one it last rounded over with, or else the
one with the biggest round, all of its round down the wall unless the last
round over went less far. The loops go on a Round over edges level, and each is
checked on its own the same way. It also finds the edges the model has rounded
over already (a top's loop where every edge is the top of a convex quarter
round of one radius, a cylinder, a torus along a curve or a sphere at a corner,
coming down onto walls standing straight up, as the owner's cutting board is
drawn) and cuts them as drawn with the corner rounder that size, its pilot
riding where the round meets the wall; the rounder matching the most of them
is the one picked. Those may cut nothing beyond the model, and a round of
another size than any rounder is said and not cut. In the test, a plate's outline and a hole's
rim come out as the plate filleted in the model, to 0.003 mm, and on a plate
with a shallow recess and a counterbore as wide as the bit, the recess (the
pilot would go 2.7 into its floor) and the hole down the counterbore (the
shoulder would shave its wall) are left out and said; a plate and a block
rounded on every edge in the model (spheres at the corners) are cut to their
rounds, nowhere beyond and 0.03 at most left on, and rounds of 2 mm are said
and left for a 1/8 bit. The owner-parts survey (GARAGECAM_SURVEY_CHAMFER)
rounds over every part with a 1/2 inch, 1/8 radius bit and with a bit the
size of each round its model has, as well as chamfering it; before the rim
check it found a spacer's counterbore shaved 2.2 mm and the cutting board's
foot recesses cut 2.7 deep, and the board's own 1/4 inch rounds, top and
bottom, come out as drawn (nothing into it, seen from above).

**Auto Drill** (under the arrow beside Drill) goes a step further for holes:
it finds them, puts their circles on the Holes level, and makes the
operations. Holes the same size at the same heights are one group. A group a
drill in the library matches (within 0.02 mm) is spotted with the V bit or
chamfer mill nearest 90° and then drilled, pecking a diameter at a time when
it is deeper than three diameters and allowing for the point when it goes
right through. A group with no drill is circle milled with the biggest flat
end mill that fits; a bore more than twice the cutter is opened from the middle
out in rings, so no core is left standing.
Circle milling comes first, so a counterbore is open before the hole beneath
it is spotted; the drills follow, smallest first. Holes nothing in the library
suits are listed in the status bar. A hole at the bottom of a counterbore is
spotted only as wide as lets the spotting tool's cone down the counterbore
without touching its wall, and not at all when even a small spot would; the
test that found this showed a 2.6 mm gouge before.
A hole that comes out at its far end into the open, a counterbore bored up
from underneath say (the Mount 4 corners), counts as through: it is cut a
little past where they meet, so turning the part over finds no skin left.

Holes coming in from **underneath** (counterbores bored up from the bottom,
say) can instead be put in a **second setup**: Auto Drill's question offers
**Turn It Over**, which makes a toolpath group of their own ("..., turned
over") on a plane facing straight down that is also that group's WCS, so its
program is written for the part turned over in the vise, with no A move.
Verify cuts both setups into the same block (see Verify).

With the part on the rotary, Auto Drill also does the **sides**. Holes that
open toward a face the A axis can turn up (any face square to X) are offered
after a question, since it only makes sense with the part centred on the A
axis at the work zero: each such face gets a plane of its own (a standard one
is reused when it matches, Front or Back say), the holes on it are planned in
that plane's frame the same way, and the operations run indexed. Holes along X,
and holes that open no way out (a hole running into a bore inside the part, or
a counterbore bored up from underneath), are counted and left. On the owner's
air-cylinder parts every face's holes, checked against the part turned to that
face, came out clean. The operations are put in the order with the fewest tool
changes the holes allow: one goes alongside others with its tool unless
something before it works the same hole (a spot before its drill, a
counterbore before the hole through under it).

**Open pockets**: pick an open chain for Pocket (a U drawn round a slot that
runs out of the part, say) and the pocket is closed out past the line between
its ends, so the outer pass runs half a tool width beyond the open side and
the floor is cleared right up to it. The operation warns that the open side
has to be open to the air; nothing is assumed about what is there.

`File > Import DXF / SVG` (Ctrl+Shift+I) reads ASCII DXF: lines, arcs, circles,
polylines with bulges, splines, ellipses and block inserts, converted from
the file's units. Text, dimensions and hatches are skipped and counted. A file
that does not say its units asks whether it was drawn in inches or millimetres.

The same command reads an **SVG** (what Inkscape, LightBurn and most sign and
lettering programs write): paths (lines, cubic and quadratic Beziers, arcs),
rectangles (rounded too), circles, ellipses, lines, polylines and polygons,
through every group's and element's transform, sized from the page's width,
height and view box (96 to the inch when it gives no units), upright with the
page's bottom left corner at the origin. Circles and round arcs stay true
circles, so hole operations still know them; other curves come in as splines.
Inkscape layers become levels. Text, pictures and clones are counted and left
out: convert text to paths before saving.

**File > Export DXF** (and the File page's Export) writes the wireframe out as
an ASCII DXF every program reads (R12), in millimetres: what is selected, or
else everything showing, each level a layer. Lines, circles and flat arcs go
out as themselves (clockwise arcs turned round the way DXF wants), splines and
other curves as polylines within 0.01 mm, and points as points: for a laser, a
plasma table, or back into CAD. **Export STEP** and **Export STL** do the same
for the solids and surfaces (those selected, or all of them showing): STEP as
they are, in millimetres, for any CAD; STL as a binary mesh within 0.01 mm of
them, for a slicer or a viewer.

`File > Import STL` reads a mesh, ASCII or binary, and puts it on its own level
as triangles. That is all an STL holds: nothing in the file says which surface
any triangle came from, so it is kept exactly as it arrived rather than guessed
back into a solid. It can be surfaced — every 3D operation drops the cutter
onto those triangles — but not chained, filleted or booleaned. Its triangles
are saved with the document, so a mesh reopens as it went in. An STL has no
units at all, so it always asks which it was drawn in.

Large drawings are fine: a traced DXF of 106,000 entities loads in about 7 s
and 380 MB.

Toolpath *parameters* are saved, not the moves. Opening a file rebuilds each
path from the geometry, so a toolpath can never be posted from stale moves that
no longer match the chain they came from. If one cannot be rebuilt, you are
told which.

## Checking the UI

`GarageCAM.exe --demo` lays out a plate with a pocket and four holes, on three
levels, with a contour (leads and tabs), a pocket and a drill operation, so the
viewport and backplot can be checked without clicking anything.

`GarageCAM.exe --shots <folder>` renders every dialog, and the operations
manager with a job in it, to PNGs without putting anything on the screen. It is
how a layout is checked: the widgets are laid out exactly as they would be, and
nothing appears in front of whatever else is running.

`GarageCAMTests.exe` runs the headless checks: chaining, offsets, trims,
fillets, every toolpath type, gouge checks, 3D surfacing against known shapes,
surfaces and solids by area and volume, stock and verify, rotary wrapping, the
post, DXF import, file round-trips, undo, and chaining speed on a 20,000
segment outline.

If GarageCAM ever stops on a fault, it first writes what it was doing to
`%APPDATA%\GarageCAM\GarageCAM\crash-log.txt`: the fault (what kind, and what
an error nothing handled said), the last few dozen things done before it
(commands, buttons, windows opened and messages shown, with files named but
not their folders) and the stack, with function names and source lines.

The next start offers to send it as a **crash report**: what it was, when,
the trail and the stack, the build and the system, from the name on the
licence, with a box for what was being done. It goes to the suggestions
inbox as a row of the kind **Crash** (kept with the suggestions until it has
gone, like one written with no connection); **Show Report** shows all of it
first, the job and its files are never sent, and **Don't Send** keeps it
here only. Ticked, **Always send crash reports without asking** (also in
**Help > Suggestions**) sends them with no question. A shared copy's stack
has places but no names; `sh tools/crash-names.sh report.txt <build>` names
them from the symbols kept for that build. `GARAGECAM_CRASH_TEST=fault` (or
`abort` or `throw`) makes a build that is not a shared copy stop that way
after `GARAGECAM_CRASH_AFTER` seconds (20), to try it.

## Licensing

All dependencies are tracked in [LICENSES.md](LICENSES.md). Commercial-friendly
only: MIT, BSD, Apache, or LGPL linked dynamically.
